# SwipeKlar 1.1 auf deinem iPhone aktualisieren

**Korrigiertes Build-Paket:** Die Medienkarte ist in kleinere SwiftUI-Ansichten aufgeteilt, um den von Xcode gemeldeten Zeitabbruch bei der Typprüfung in `ReviewView.swift` zu beheben. Für diese Korrektur genügt es, die Quellcode-ZIP im vorhandenen Repository zu ersetzen und einen neuen Lauf zu starten. Die Workflow-Datei passt weiterhin.

## Was sich geändert hat

1. **Videos:** Alle drei Modi laden jetzt Fotos und Videos. Auf die Vorschau eines Videos tippen, um es zu öffnen und abzuspielen. Unter dem Video gibt es Start/Pause, eine Spulleiste, Zeitanzeigen und Tasten für zehn Sekunden vor/zurück.
2. **Zoom:** Fotos und Videos in der Detailansicht mit zwei Fingern vergrößern und verschieben. Doppeltippen vergrößert auf 2,5-fach bzw. setzt zurück. Maximal sind 5-fach möglich. Die Taste „Zoom zurücksetzen“ zeigt wieder die ganze Aufnahme.
3. **Darstellung:** Datum und Uhrzeit sind größer und stehen auf einer eigenen dunklen Fläche mit explizit heller Schrift. Typ und Videolänge sind erkennbar; die drei Startfelder haben dunklere Hintergründe für besser lesbare Beschriftungen.

Die drei Einstiege und der Ablauf zum Behalten bzw. Löschen bleiben bestehen. Das Öffnen oder Schließen einer Detailansicht trifft keine Entscheidung über die Aufnahme. Zoom- und Spulgesten in der Detailansicht lösen keine Behalten-/Löschen-Wischaktion aus. Bei eingeschränkter Fotofreigabe müssen die gewünschten Videos ebenfalls freigegeben sein.

## Bestehendes GitHub-Projekt aktualisieren

1. Die neue **SwipeKlar-Quellcode.zip** herunterladen und gepackt lassen. Der Dateiname muss exakt so lauten; gegebenenfalls einen vom Browser ergänzten Zusatz wie `(1)` entfernen.
2. In deinem bestehenden GitHub-Projekt **Code → Add file → Upload files** öffnen. Die neue ZIP hochladen, dadurch die gleichnamige Datei ersetzen und **Commit changes** auf `main` bestätigen.
3. Unter **Actions → SwipeKlar iPhone bauen → Run workflow** einen neuen Lauf auf `main` starten. Die vorhandene Workflow-Datei passt auch für Version 1.1.
4. Bei grünem Haken den Lauf öffnen, links **Summary** anklicken und unten unter **Artifacts → SwipeKlar-iPhone** den Download holen. Das heruntergeladene ZIP entpacken; darin liegt die neue **SwipeKlar.ipa**.
5. Die neue IPA mit Sideloadly über die bestehende App installieren. **Dieselbe Apple-ID und dieselbe Bundle-ID** verwenden. Die vorhandene App dabei installiert lassen, damit der lokal gespeicherte Fortschritt erhalten bleibt.

Die App meldet sich als Version **1.1**, Build **2**. Die ursprüngliche Bundle-ID und der lokale Fortschrittsschlüssel wurden beibehalten. Die sieben Tage gültige kostenlose Signierung und die Erneuerung über Sideloadly funktionieren wie bisher.

## Prüfung auf dem iPhone

- Ein lokales Video öffnen, pausieren, per Leiste zu Anfang/Mitte/Ende spulen und erneut starten. Bei pausiertem Video soll Spulen die Wiedergabe nicht starten. Zehn-Sekunden-Sprünge sollen an Anfang und Ende stoppen.
- Bei Foto und Video Pinch-Zoom, Verschieben, Doppeltipp und „Zoom zurücksetzen“ prüfen. Danach „Fertig“: Die gleiche Aufnahme und der bisherige Entscheidungsstand sollen sichtbar sein.
- Laufendes Video schließen oder die App in den Hintergrund schicken: Der Ton soll stoppen.
- Ein nicht lokal verfügbares iCloud-Video mit Netzverbindung laden; bei fehlender Verbindung soll eine verständliche Lade-/Fehleranzeige erscheinen und erneutes Laden möglich sein.
- Hoch-/Querformat, längere Videos und nach Möglichkeit Zeitlupe prüfen. Die Wiedergabe verwendet die von PhotoKit bereitgestellte aktuelle Fassung.
- Datum und Uhrzeit bei hellen und dunklen Fotos sowie im hellen iPhone-Systemdesign prüfen. Die dunkle Datumsfläche soll in allen Fällen helle, lesbare Schrift behalten.
- Eine gemischte Runde mit Fotos und Videos durchsehen und die Video-Kennzeichnung in der Löschübersicht prüfen. Zum Testen genügen entbehrliche Aufnahmen; Abbrechen der iOS-Löschbestätigung darf nichts löschen.

## Bisherige Prüfungen

Elf Swift-Logiktests bestanden. Swift-Syntax, Projektverweise, Datenschutz-Manifest und Ressourcen wurden geprüft. Die berechneten Textkontraste der Datumsfläche sind etwa 16,6:1 (Datum) und 11,7:1 (Zusatzinformationen); die Beschriftungen der Startfelder liegen an allen Gradient-Endpunkten über 4,5:1.

Für diese neue Version konnte hier kein vollständiger iOS-Build oder Gerätetest ausgeführt werden. Das erfolgt mit deinem nächsten GitHub-Lauf und den Prüfungen auf deinem iPhone. Die vorangegangene Version wurde vom Nutzer erfolgreich gebaut und installiert; das ersetzt nicht die Prüfung der neuen Medienfunktionen.
