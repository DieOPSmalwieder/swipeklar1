# SwipeKlar 1.5: Aufnahmeort, Randtippen, 2× Tempo und Abschlussbilanz

## Neue Bedienung

1. **Aufnahmeort:** Unter Datum und Uhrzeit erscheint der gespeicherte Ort mit Land. Fehlt die Ortsangabe, steht dort „Kein Standort“. Für einen lesbaren Ortsnamen nutzt iOS Apples Geocoding-Dienst; ohne Verbindung bleiben die gespeicherten Koordinaten sichtbar. Die App fragt nicht nach deinem aktuellen Gerätestandort.
2. **Unsichtbare Tippbereiche:** In Originalgröße kurz auf den linken Bildrand tippen = zum Löschen vormerken; rechts = behalten. Die äußeren ungefähr 20 Prozent sind aktiv, maximal 88 Punkte breit. In der Mitte passiert durch einfaches Tippen nichts. Wischen, Doppeltipp-Zoom und die unteren Tasten bleiben erhalten. Vergrößert werden keine Randentscheidungen ausgelöst.
3. **Videos gedrückt halten:** Ein Video bei Originalgröße etwa 0,3 Sekunden gedrückt halten, um es solange mit 2× Geschwindigkeit abzuspielen. „2× Tempo“ zeigt den Zustand an. Loslassen stellt die vorherige Wiedergabe wieder her: normal weiter bei laufenden Videos, wieder pausiert bei vorher pausierten Videos. Zwei Finger bzw. Zoom, Spulen, Teilen und Unterbrechungen beenden die Beschleunigung. Die Geste funktioniert auch in der großen Prüfvorschau. Gedrückthalten in der Miniaturübersicht öffnet weiterhin die Prüfvorschau.
4. **Abschlussbilanz:** Nach einem erfolgreich bestätigten Cleanup erscheint ein animierter Haken mit der Anzahl entfernter Aufnahmen und ihrer Größe in MB/GB. Abgewählte Fotos zählen nicht zum aussortierten Volumen. Bei „Alle behalten“ steht die Bilanz auf 0 MB; ein abgebrochener Löschdialog zeigt keinen Erfolg an.

## Bedeutung der Speicherzahl

Die Bilanz beschreibt die Größe der ausgesonderten Medien. Wo möglich, wird die lokale Dateigröße genutzt; sonst wird anhand von Auflösung und Videodauer geschätzt. Live-Photo-Bewegungen und nicht verfügbare iCloud-Originale werden näherungsweise berücksichtigt, ohne für die Bilanz Originale herunterzuladen. Enthält die Summe Schätzwerte, steht „Ca.“ davor.

iOS legt gelöschte Aufnahmen zunächst in **Fotos → Zuletzt gelöscht**. Der Speicher wird deshalb gegebenenfalls erst nach deren endgültiger Entfernung frei. Die Anzeige misst keinen sofortigen freien Gerätespeicher; insbesondere mit optimiertem iCloud-Speicher und Bearbeitungen kann der tatsächliche lokale Gewinn abweichen. Die App leert „Zuletzt gelöscht“ nicht selbstständig.

## Aktualisieren mit Windows

1. **SwipeKlar-Quellcode.zip** herunterladen, gepackt lassen und auf den exakten Dateinamen ohne `(1)` achten.
2. In `DieOPSmalwieder/swipeklar1` unter **Code → Add file → Upload files** die vorhandene gleichnamige ZIP ersetzen und mit **Commit changes** auf `main` speichern.
3. **Actions → SwipeKlar iPhone bauen → Run workflow → main → Run workflow** starten. Einen neuen Lauf verwenden; „Re-run jobs“ eines alten Laufs verwendet dessen alten Quellcode.
4. Nach erfolgreichem Lauf **Summary → Artifacts → SwipeKlar-iPhone** herunterladen, entpacken und die IPA verwenden.
5. Mit Sideloadly über die bestehende App installieren. Dieselbe Apple-ID und Bundle-ID verwenden und die vorhandene App installiert lassen, damit dein Fortschritt erhalten bleibt.

Version **1.5**, Build **6**. Die bisherige Workflow-Datei passt weiterhin.

## Auf dem iPhone prüfen

- Ein Foto mit bekanntem GPS-Ort und eines ohne Standort öffnen, danach dieselben Aufnahmen in der großen Prüfvorschau. Auch im Flugmodus und nach schnellen Kartenwechseln darf nie der Ort der vorherigen Aufnahme stehen bleiben. Falls kein Ortsname geladen wird, müssen die korrekten Koordinaten sichtbar bleiben.
- Links/rechts am Bildrand kurz tippen; genau eine Entscheidung muss erfolgen. Doppeltippen, auch direkt am Rand, muss zoomen und darf keine Entscheidung auslösen. In der Bildmitte kurz tippen: kein Weiterschalten.
- Von beiden Rändern aus normal links/rechts wischen. Vergrößert am Rand tippen bzw. den Ausschnitt verschieben: keine Sortierentscheidung. Beide unteren Entscheidungstasten und Rückgängig prüfen.
- Ein laufendes Video festhalten: sichtbare und hörbare 2× Wiedergabe. Nach dem Loslassen normales Tempo. Bei einem vorher pausierten Video muss nach dem Loslassen wieder Pause gelten. Dasselbe in der großen Prüfvorschau testen.
- Ein Video am linken und rechten Rand halten und wieder loslassen sowie nach dem Halten deutlich seitlich ziehen: keine Sortierentscheidung. Beim Halten einen zweiten Finger aufsetzen und zoomen: 2× muss enden; die Aufnahme muss bleiben.
- Während 2× die App verlassen, teilen, eine Audiounterbrechung auslösen oder zur nächsten Aufnahme wechseln: Tempo und Wiedergabe dürfen sich nicht auf die nächste Aufnahme übertragen. Spulen muss wie bisher die Wiedergabeabsicht erhalten.
- Einige entbehrliche Fotos und ein Video vormerken, in der Prüfübersicht eines wieder behalten und erfolgreich abschließen. Bilanz und Haken dürfen erst nach erfolgreicher Bestätigung erscheinen; das abgewählte Foto darf nicht mitgezählt werden.
- Den iOS-Löschdialog abbrechen: Auswahl muss erhalten bleiben, kein Erfolgshaken. Danach alle abwählen und abschließen: 0 MB und „Alle Aufnahmen behalten“.
- Einen Abschluss mit „Bewegung reduzieren“ und größerer Schrift prüfen: Der Haken bleibt sichtbar; Text und Zurück-Taste müssen erreichbar bleiben.

## Prüfstand

41 Logiktests bestanden, Swift-Syntax und Xcode-Projektstruktur geprüft. Diese Umgebung hat kein iOS-SDK oder iPhone-Simulator. Der vollständige iOS-Build über GitHub sowie reale Mehrfingerfolgen, 2× AVPlayer-Wiedergabe, Geocoding und Bilanz auf dem iPhone sind noch zu prüfen. Details stehen in `VALIDIERUNG.md`.
