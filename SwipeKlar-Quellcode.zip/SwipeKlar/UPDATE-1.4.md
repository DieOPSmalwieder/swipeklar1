# SwipeKlar 1.4: automatisch weiterspielen und direkt teilen

## Änderungen

- Ein laufendes Video spielt nach dem Spulen automatisch weiter. Das gilt für die Spulleiste und die Zehn-Sekunden-Tasten in beiden Medienansichten. Der Player wird während des Spulens kurz pausiert; dieser technische Zustand setzt die Wiedergabeabsicht nicht mehr zurück.
- Ein ausdrücklich pausiertes Video bleibt beim Spulen pausiert. Pause, App-Hintergrund und Audiounterbrechungen während des Spulens verhindern weiterhin einen automatischen Start. Am Videoende bleibt die Wiedergabe stehen.
- Das Teilen-Symbol neben dem Datum öffnet nach der Dateivorbereitung die normale iOS-Teilenansicht. Darin kannst du WhatsApp oder andere installierte Teilen-Erweiterungen auswählen. Empfänger und Versand wählst du dort selbst.
- Teilen ist auf der normalen Wischkarte und in der großen Prüfvorschau möglich. Die Auswahl zum Löschen bzw. Behalten ändert sich dabei nicht.
- Fotos werden in vollständiger Auflösung vorbereitet; JPEG/PNG bleiben in ihrem Format, andere Bildformate werden für bessere Kompatibilität als JPEG ausgegeben. Live Photos werden als Standbild geteilt. Videos werden als MP4 bzw. MOV exportiert. Es wird nicht das Vorschaubild geteilt.
- iCloud-Medien werden bei Bedarf geladen. Während der Vorbereitung erscheinen ein Ladeindikator und ein Kreuz zum Abbrechen. Große Videos benötigen Zeit und temporären Speicher. Nach dem Schließen der Teilenansicht oder einem Abbruch wird die temporäre Datei entfernt.

## Update vom Windows-PC

1. **SwipeKlar-Quellcode.zip** herunterladen, gepackt lassen und auf den exakten Dateinamen ohne `(1)` achten.
2. In `DieOPSmalwieder/swipeklar1` unter **Code → Add file → Upload files** die vorhandene gleichnamige ZIP ersetzen und mit **Commit changes** auf `main` speichern.
3. **Actions → SwipeKlar iPhone bauen → Run workflow → main → Run workflow** starten. Einen neuen Lauf verwenden, nicht „Re-run jobs“ eines alten Laufs.
4. Nach erfolgreichem Lauf **Summary → Artifacts → SwipeKlar-iPhone** herunterladen, entpacken und die enthaltene IPA verwenden.
5. Mit Sideloadly über die bestehende App installieren. Dieselbe Apple-ID und Bundle-ID verwenden; die vorhandene App installiert lassen, damit dein Fortschritt erhalten bleibt.

Version **1.4**, Build **5**. Die bisherige GitHub-Workflow-Datei passt weiterhin.

## Auf dem iPhone prüfen

1. Ein laufendes Video über die Leiste vor- und zurückspulen und loslassen. Es soll ohne zusätzlichen Tastendruck weiterlaufen. Mehrmals schnell hintereinander ziehen und die Zehn-Sekunden-Tasten drücken.
2. Ein Video ausdrücklich pausieren und spulen: Es soll pausiert bleiben. Wieder starten und denselben Ablauf in der großen Löschvorschau prüfen.
3. Bis zum Ende spulen, dann zurückspulen bzw. erneut starten. Am Ende soll es stoppen; nach Start soll es wieder laufen. Während einer längeren Such-/Ladephase pausieren oder die App verlassen: Es darf danach nicht ungefragt starten.
4. Ein Foto über das Teilen-Symbol an WhatsApp übergeben. Die gewählte Aufnahme muss dort korrekt ausgerichtet und scharf erscheinen. Mit JPEG, PNG, HEIC und einem bearbeiteten Foto prüfen.
5. Ein lokales Video und ein iCloud-Video teilen. Die vollständige Aufnahme und gegebenenfalls die Bearbeitung müssen ankommen; Bild und Ton prüfen. Mit einem längeren Video auch Ladeanzeige und Abbruch testen.
6. Die Teilenansicht abbrechen und erneut öffnen. Danach weiter zoomen, aussortieren und die Prüfvorschau öffnen. Die Zähler und Markierungen müssen beim Teilen unverändert bleiben.

## Prüfstand

Die neuen Logiktests prüfen das Erhalten der Wiedergabeabsicht, wiederholte Startsignale der Spulgeste, verspätete Such-Abschlüsse und Unterbrechungen. Ein vollständiger iOS-Build sowie die tatsächliche AVPlayer-Wiedergabe und Übergabe an WhatsApp müssen über GitHub und auf deinem iPhone geprüft werden; diese Umgebung hat kein iOS-SDK. Ergebnisse stehen in `VALIDIERUNG.md`.
