# SwipeKlar

Eine kleine native iPhone-App zum Aussortieren von Fotos und Videos, ohne Abo, Werbung, Konto oder Server. Eigenständige Umsetzung des Wischprinzips mit genau drei Einstiegen; kein offizielles SwipeWipe-Produkt.

**Version 1.2:** Direkt auf der Wischkarte zoomen und Videos automatisch abspielen, mit Spulleiste und kontrastreichem Datum. Installation über die bestehende App ist in [UPDATE-1.2.md](UPDATE-1.2.md) erklärt.

## Die drei Modi

- **An diesem Tag:** Fotos und Videos mit dem heutigen Kalendertag und Monat aus allen Jahren. Auch heutige Aufnahmen gehören dazu. Die lokale Zeitzone des iPhones zählt.
- **Aktuelles:** Fotos und Videos ab Mitternacht vor 30 Tagen bis jetzt, neueste zuerst.
- **Zufällig:** Alle zugänglichen Fotos und Videos in zufälliger Reihenfolge, einschließlich Aufnahmen ohne Datum.

Es werden Fotos einschließlich Screenshots und der Standbilder von Live Photos sowie Videos angezeigt. Live Photos werden beim Löschen als vollständiges Foto inklusive Bewegungsteil gelöscht.

## Ansehen, abspielen und zoomen

Fotos und Videos werden direkt auf der Wischkarte angezeigt. Videos starten dort automatisch, sobald die Wiedergabe verfügbar ist. Die Bedienelemente direkt unter dem Video erlauben Start/Pause, Vor- und Zurückspringen um zehn Sekunden und das Verschieben der Wiedergabeposition über eine Spulleiste. Aktuelle Position und Gesamtlänge bleiben sichtbar. Bei pausierter Wiedergabe bleibt das Video nach dem Spulen pausiert.

Fotos und Videos lassen sich direkt auf der Karte mit zwei Fingern bis zu fünffach vergrößern. Vergrößert lässt sich der Ausschnitt mit einem Finger verschieben. Ein Doppeltipp schaltet zwischen Originalgröße und 2,5-fachem Zoom um. Die Pfeiltaste neben dem Datum setzt den Zoom mit einer Animation zurück. Zum normalen Aussortieren in Originalgröße links oder rechts wischen. Eine Geste, die einen zweiten Finger oder Zoom berührt hat, kann innerhalb derselben Berührung keine Sortierentscheidung mehr auslösen. Die Zoomfläche verwendet native UIScrollView-Gesten statt einer SwiftUI-Skalierung.

Die Wiedergabe wird beim Wechsel der Aufnahme, beim Verlassen der App, bei einer Audiounterbrechung und beim Öffnen der Abschluss-/Verlassen-Dialoge pausiert. Nach einer solchen Unterbrechung kann sie über die Wiedergabetaste wieder gestartet werden.

Datum, Uhrzeit, Medientyp und bei Videos die Länge erscheinen auf einer eigenen dunklen Fläche mit heller Schrift. Für die zoombare Fläche werden Fotos bis 4096 Pixel an der längsten Kante geladen, um Speicherverbrauch zu begrenzen. iCloud-Inhalte können eine Internetverbindung benötigen; bei Ladefehlern gibt es eine erneute Ladeoption.

## Vom Windows-PC installieren

Für Windows gibt es jetzt einen Weg über **GitHub Actions + Sideloadly**. GitHub baut die App; der Windows-PC signiert und installiert die fertige IPA. Die vollständige Anleitung steht in [WINDOWS-ANLEITUNG.md](WINDOWS-ANLEITUNG.md). Im separaten Windows-Paket liegen die Quellcode-ZIP und die fertige GitHub-Buildanweisung bei.

## Mit einem Mac auf dem iPhone installieren

Für die direkte Installation mit Xcode brauchst du einen **Mac mit Xcode 15 oder neuer**, eine Apple-ID und ein **iPhone mit iOS 17 oder neuer**. Für Windows nutze die oben verlinkte Cloud-Build-Anleitung.

1. Das ZIP entpacken und **SwipeKlar.xcodeproj** in Xcode öffnen. Du brauchst keine zusätzlichen Pakete und keinen Projektgenerator.
2. In **Xcode → Settings → Accounts** deine Apple-ID hinzufügen.
3. Im Projektnavigator das blaue **SwipeKlar**-Projekt auswählen, dann **Targets → SwipeKlar → Signing & Capabilities**. „Automatically manage signing“ aktivieren und unter „Team“ deine Apple-ID / dein „Personal Team“ auswählen. Falls der Bundle Identifier nicht verfügbar ist, `de.swipeklar.personal` durch etwas Eigenes wie `de.deinname.swipeklar` ersetzen.
4. Das iPhone per Kabel verbinden, entsperren und dem Mac vertrauen. Oben in Xcode dein iPhone als Zielgerät auswählen.
5. Falls iOS danach fragt, unter **Einstellungen → Datenschutz & Sicherheit → Entwicklermodus** den Entwicklermodus einschalten und das iPhone neu starten. Gegebenenfalls unter **Einstellungen → Allgemein → VPN und Geräteverwaltung** deinem Entwicklerprofil vertrauen.
6. In Xcode **▶ Run** drücken. Die App wird gebaut und auf deinem iPhone gestartet.
7. Einen der drei Modi öffnen und den Fotozugriff erlauben. „Voller Zugriff“ ermöglicht das Durchsehen der ganzen Mediathek; „Eingeschränkter Zugriff“ zeigt nur deine freigegebenen Fotos.

**Kostenlose Apple-ID:** Apple signiert persönlich installierte Test-Apps normalerweise für sieben Tage. Danach erneut mit Xcode auf dasselbe iPhone installieren; die App kann ohne gültige Signatur nicht gestartet werden. Ein kostenpflichtiges Apple Developer Program ist für diese persönliche Testinstallation nicht erforderlich. Diese Art der Installation bietet deshalb nicht die gleiche dauerhafte Verfügbarkeit wie eine App-Store-App.

## Benutzung und Löschung

- **Rechts wischen / Herz:** behalten.
- **Links wischen / Kreuz:** zum Löschen vormerken. Noch wird nichts gelöscht.
- **Pfeil zurück:** die letzte Entscheidung zurücknehmen.
- **Fertig** beendet auch eine teilweise durchgesehene Runde.
- **Auswahl prüfen:** alle vorgemerkten Fotos sehen; antippen, um einzelne doch zu behalten.
- **Fotos löschen:** die Auswahl an iOS übergeben. iOS zeigt seine eigene Löschbestätigung. Bei Abbruch oder einem Fehler bleibt die Auswahl zur Korrektur erhalten.

Beim Verlassen einer ungespeicherten Runde kannst du die Auswahl verwerfen. Dabei wird nichts gelöscht. Ein App-Abbruch speichert keine angefangene Runde. Erfolgreich abgeschlossene Entscheidungen werden lokal gespeichert und in allen drei Modi berücksichtigt. Sind alle passenden Fotos durchgesehen, kannst du im jeweiligen Modus mit **Erneut durchsehen** neu anfangen.

Gelöschte Fotos landen in **Fotos → Zuletzt gelöscht** und lassen sich dort normalerweise innerhalb von 30 Tagen wiederherstellen. Bei aktivierten **iCloud-Fotos** wird eine Löschung auch mit den anderen Geräten synchronisiert. iCloud-Fotos können zum Anzeigen von iOS heruntergeladen werden; ohne Netzwerk sind nicht lokal vorhandene Bilder möglicherweise nicht verfügbar.

## Datenschutz

Die App besitzt keinen Server, keine Werbung, keine Analysebibliothek und keine Kauf- oder Abo-Funktionen. Fotozugriff und Löschung laufen über Apples PhotoKit. Nur die Kennungen bereits abgeschlossener Fotos werden in den lokalen App-Einstellungen gespeichert. Der Fotozugriff lässt sich jederzeit in den iPhone-Einstellungen ändern. Die Startseite bietet bei eingeschränktem Zugriff die Möglichkeit, weitere Fotos freizugeben.

## Entwicklung und Prüfung

Der SwiftUI-/PhotoKit-Code ist unter `SwipeKlar/`. Das fertige Xcode-Projekt liegt bereits bei; `scripts/create_project.py` kann die Projektdatei reproduzieren.

Die reine Auswahllogik und der rückgängig machbare Entscheidungsablauf liegen in `SwipeKlar/Core/PhotoSelection.swift`. Auf einem Mac mit Xcode lassen sich ihre Tests ohne iPhone starten:

```sh
cd SwipeKlar
swift test
```

Die 18 Tests behandeln Datumsauswahl, 30-Tage-Grenze, Zeitzonen, Schalttage, bereits durchgesehene Aufnahmen, zufällige Auswahl und Rückgängig sowie Spulgrenzen, Zeitformatierung und die Absicherung von Sortierentscheidungen gegenüber Zoom, mehreren Fingern und abgebrochenen Gesten.

Ein Simulator-Build ohne Signatur:

```sh
xcodebuild -project SwipeKlar.xcodeproj -scheme SwipeKlar \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO build
```

Vor dem Einsatz bitte mit einigen entbehrlichen Fotos prüfen: eingeschränkter/voller/verweigerter Zugriff, beide Wischrichtungen, Rückgängig, Abwählen in der Löschübersicht, Abbruch der iOS-Löschbestätigung und Wiederherstellung aus „Zuletzt gelöscht“. Der Simulator hat eine eigene Mediathek; Testfotos kannst du per Drag-and-drop hinzufügen. Signatur und echte PhotoKit-Löschdialoge sollten auf dem iPhone geprüft werden.

Der iOS-Build und die Bedienung auf einem iPhone konnten in der Linux-Erstellungsumgebung nicht geprüft werden. Den Build kannst du über GitHub Actions oder Xcode ausführen; die Geräteprüfung erfolgt auf deinem iPhone. Ergebnisse der hier möglichen Prüfungen stehen in `VALIDIERUNG.md`.
