# SwipeKlar

Eine kleine native iPhone-App zum Aussortieren von Fotos und Videos, ohne Abo, Werbung, Konto oder Server. Eigenständige Umsetzung des Wischprinzips mit genau drei Einstiegen; kein offizielles SwipeWipe-Produkt.

**Version 1.6:** Randtipps zeigen eine kurze blaue Bestätigung für „Behalten“ bzw. rote Rückmeldung für „Vorgemerkt“. Die Aufnahme gleitet in die gewählte Richtung, bevor die nächste erscheint. Aufnahmeort, 2×-Halten, Teilen und Abschlussbilanz bleiben erhalten. Aktualisierung: [UPDATE-1.6.md](UPDATE-1.6.md).

## Die drei Modi

- **An diesem Tag:** Fotos und Videos mit dem heutigen Kalendertag und Monat aus allen Jahren. Auch heutige Aufnahmen gehören dazu. Die lokale Zeitzone des iPhones zählt.
- **Aktuelles:** Fotos und Videos ab Mitternacht vor 30 Tagen bis jetzt, neueste zuerst.
- **Zufällig:** Alle zugänglichen Fotos und Videos in zufälliger Reihenfolge, einschließlich Aufnahmen ohne Datum.

Es werden Fotos einschließlich Screenshots und der Standbilder von Live Photos sowie Videos angezeigt. Live Photos werden beim Löschen als vollständiges Foto inklusive Bewegungsteil gelöscht.

## Ansehen, abspielen und zoomen

Fotos und Videos werden direkt auf der Wischkarte angezeigt. Videos starten dort automatisch, sobald die Wiedergabe verfügbar ist. Die Bedienelemente direkt unter dem Video erlauben Start/Pause, Vor- und Zurückspringen um zehn Sekunden und das Verschieben der Wiedergabeposition über eine Spulleiste. Aktuelle Position und Gesamtlänge bleiben sichtbar. Ein laufendes Video spielt nach dem Loslassen der Spulleiste bzw. nach einem Zehn-Sekunden-Sprung automatisch weiter. Bei bewusst pausierter Wiedergabe bleibt das Video nach dem Spulen pausiert. Am Ende stoppt es; ein erneuter Start beginnt am Anfang.

Fotos und Videos lassen sich direkt auf der Karte mit zwei Fingern bis zu fünffach vergrößern. Vergrößert lässt sich der Ausschnitt mit einem Finger verschieben. Ein Doppeltipp schaltet zwischen Originalgröße und 2,5-fachem Zoom um. Bei aktivem Zoom setzt die Taste „1×“ neben dem Datum den Zoom mit einer Animation zurück. Zum normalen Aussortieren in Originalgröße links oder rechts wischen. Eine Geste, die einen zweiten Finger oder Zoom berührt hat, kann innerhalb derselben Berührung keine Sortierentscheidung mehr auslösen. Die Zoomfläche verwendet native UIScrollView-Gesten statt einer SwiftUI-Skalierung.

Alternativ in Originalgröße kurz auf den linken Bildrand tippen, um die Aufnahme zum Löschen vorzumerken, oder auf den rechten Bildrand, um sie zu behalten. Die unsichtbaren Tippbereiche liegen entlang der äußeren 20 Prozent der Medienfläche, mindestens 44 und höchstens 88 Punkte breit. Die Bildmitte löst keine Entscheidung aus. Doppeltipp hat Vorrang vor einer einzelnen Randentscheidung. Vergrößert, mit mehreren Fingern oder nach einer erkannten Haltegeste sind Randentscheidungen gesperrt. Die unteren Tasten und die Wischgeste bleiben erhalten.

Bei einem erkannten Randtipp erscheint etwa 0,3 Sekunden lang eine farbige Rückmeldung: rechts ein blauer Impuls mit Häkchen und „Behalten“, links ein roter Impuls mit Papierkorb und „Vorgemerkt“. Die Aufnahme gleitet kurz aus der gewählten Seite heraus. Erst danach wird die Entscheidung verbucht und die nächste Aufnahme gezeigt. Währenddessen werden weitere Entscheidungen, Rückgängig und Abschluss gesperrt. Wird die Ansicht verlassen, die App inaktiv oder die Animation unterbrochen, wird eine noch ausstehende Entscheidung verworfen. Mit „Bewegung reduzieren“ bleibt die Farbrückmeldung erhalten, ohne seitliches Herausgleiten oder Drehen.

Ein Video bei Originalgröße für etwa 0,3 Sekunden gedrückt halten: Es spielt solange mit 2× Tempo, sichtbar an „2× Tempo“. Loslassen stellt die vorherige Wiedergabe wieder her. Ein vorher laufendes Video läuft normal weiter; ein vorher pausiertes Video pausiert wieder. Die Geste funktioniert auch in der großen Prüfvorschau. Ein zweiter Finger, Zoom, Spulen, Teilen, ein Aufnahmewechsel und Unterbrechungen beenden die Beschleunigung. Gedrückthalten und anschließendes Ziehen darf keine Sortierentscheidung auslösen. Beim Verschieben eines bereits vergrößerten Ausschnitts bleibt die normale Zoomsteuerung aktiv.

Die Wiedergabe wird beim Wechsel der Aufnahme, beim Verlassen der App, bei einer Audiounterbrechung und beim Öffnen der Abschluss-/Verlassen-Dialoge pausiert. Nach einer solchen Unterbrechung kann sie über die Wiedergabetaste wieder gestartet werden.

Die Startseite verwendet Systemfarben und folgt dem Hell-/Dunkelmodus des iPhones. In der Medienansicht füllen Fotos und Videos die verfügbare Breite ohne zusätzlichen Kartenrahmen. Datum, Uhrzeit, Medientyp und bei Videos die Länge stehen darüber auf schwarzem Grund mit heller Schrift. Kompakte Bedienelemente und Materialflächen lassen mehr Platz für die Aufnahme. Für die zoombare Fläche werden Fotos bis 4096 Pixel an der längsten Kante geladen, um Speicherverbrauch zu begrenzen. iCloud-Inhalte können eine Internetverbindung benötigen; bei Ladefehlern gibt es eine erneute Ladeoption.

Die zusätzliche Ortszeile nutzt ausschließlich den in der Aufnahme gespeicherten GPS-Standort. Falls vorhanden, wird über Apples Geocoding-Dienst ein Orts- und Ländername ermittelt. Offline oder bei einem Lookup-Fehler bleiben die gespeicherten Koordinaten sichtbar; ohne Geodaten steht dort „Kein Standort“. Ein Zugriff auf den aktuellen Gerätestandort wird nicht angefordert. Ortsnamen werden nur im Arbeitsspeicher zwischengespeichert; schnelle Kartenwechsel werden vor einer Ortsabfrage kurz abgewartet.

In „Auswahl prüfen“ öffnet Gedrückthalten einer Miniatur die große Vorschau. Hier funktionieren Zoom, Doppeltipp, automatisches Abspielen und Spulen ebenfalls. „Diese Aufnahme behalten“ entfernt nur die Löschmarkierung; die Aufnahme bleibt zum weiteren Prüfen geöffnet. „Fertig“ kehrt zur Übersicht zurück. Das Öffnen oder Schließen der Vorschau ändert keine Markierung. Kurzes Antippen in der Übersicht schaltet weiterhin zwischen Löschen und Behalten um. Erst die abschließende Löschtaste übergibt die verbleibende Auswahl an iOS.

## Fotos und Videos teilen

Das Teilen-Symbol neben dem Datum öffnet die native iOS-Teilenansicht, sowohl beim Durchsehen als auch in der großen Prüfvorschau. Dort lässt sich zum Beispiel WhatsApp auswählen, sofern es installiert und als Teilen-Erweiterung verfügbar ist. Empfänger und Versand werden anschließend in der gewählten App bestätigt.

Zum Teilen wird eine temporäre Datei der aktuellen Aufnahme vorbereitet: JPEG/PNG bleiben in ihrer vollständigen Auflösung erhalten, HEIC/andere Bildformate werden für die Kompatibilität mit Teilen-Erweiterungen als JPEG mit hoher Qualität ausgegeben. Live Photos werden als Standbild geteilt. Videos werden aus der aktuellen PhotoKit-Version als MP4 bzw. MOV exportiert, einschließlich unterstützter Bearbeitungen. Es wird nicht die auf 4096 Pixel begrenzte Bildschirmvorschau verwendet. Große Videos können Zeit und freien Speicher benötigen; iCloud-Medien benötigen gegebenenfalls eine Internetverbindung.

Während der Vorbereitung zeigt die Taste einen Ladeindikator und ein Kreuz zum Abbrechen. Die Wiedergabe wird beim Teilen pausiert. Öffnen, Abbrechen oder Abschließen der Teilenansicht ändert keine Behalten-/Löschmarkierung. Die temporäre Datei wird nach dem Schließen der Teilenansicht bzw. einem Abbruch oder Fehler entfernt; die Aufnahme in der Mediathek bleibt erhalten.

## Vom Windows-PC installieren

Für Windows gibt es jetzt einen Weg über **GitHub Actions + Sideloadly**. GitHub baut die App; der Windows-PC signiert und installiert die fertige IPA. Die vollständige Anleitung steht in [WINDOWS-ANLEITUNG.md](WINDOWS-ANLEITUNG.md). Im separaten Windows-Paket liegen die Quellcode-ZIP und die fertige GitHub-Buildanweisung bei.

## Mit einem Mac auf dem iPhone installieren

Für die direkte Installation mit Xcode brauchst du einen **Mac mit Xcode 15 oder neuer**, eine Apple-ID und ein **iPhone mit iOS 17 oder neuer**. Für Windows nutze die oben verlinkte Cloud-Build-Anleitung.

1. Das ZIP entpacken und **SwipeKlar.xcodeproj** in Xcode öffnen. Du brauchst keine zusätzlichen Pakete und keinen Projektgenerator.
2. In **Xcode → Settings → Accounts** deine Apple-ID hinzufügen.
3. Im Projektnavigator das blaue **SwipeKlar**-Projekt auswählen, dann **Targets → SwipeKlar → Signing & Capabilities**. „Automatically manage signing“ aktivieren und unter „Team“ deine Apple-ID / dein „Personal Team“ auswählen. Falls der Bundle Identifier nicht verfügbar ist, `de.swipeklar.personal` durch etwas Eigenes wie `de.deinname.swipeklar` ersetzen.
4. Das iPhone per Kabel verbinden, entsperren und dem Mac vertrauen. Oben in Xcode dein iPhone als Zielgerät auswählen.
5. Falls iOS danach fragt, unter **Einstellungen → Datenschutz & Sicherheit → Entwicklermodus** den Entwicklermodus einschalten und das iPhone neu starten. Gegebenenfalls unter **Einstellungen → Allgemein → VPN und Geräteverwaltung** deinem Entwicklerprofil vertrauen.
6. In Xcode **▶ Run** drücken. Die App wird gebaut und auf deinem iPhone gestartet.
7. Einen der drei Modi öffnen und den Fotozugriff erlauben. „Voller Zugriff“ ermöglicht das Durchsehen der ganzen Mediathek; „Eingeschränkter Zugriff“ zeigt nur deine freigegebenen Fotos.

**Kostenlose Apple-ID:** Apple signiert persönlich installierte Test-Apps normalerweise für sieben Tage. Danach erneut mit Xcode auf dasselbe iPhone installieren; die App kann ohne gültige Signatur nicht gestartet werden. Ein kostenpflichtiges Apple Developer Program ist für diese persönliche Testinstallation nicht erforderlich. Diese Art der Installation bietet deshalb nicht die gleiche dauerhafte Verfügbarkeit wie eine App-Store-App.

## Benutzung und Löschung

- **Rechts wischen / Häkchen:** behalten.
- **Links wischen / Papierkorb:** zum Löschen vormerken. Noch wird nichts gelöscht.
- **Pfeil zurück:** die letzte Entscheidung zurücknehmen.
- **Fertig** beendet auch eine teilweise durchgesehene Runde.
- **Auswahl prüfen:** alle vorgemerkten Aufnahmen sehen; antippen ändert die Auswahl, gedrückt halten öffnet die große Prüfvorschau.
- **Fotos löschen:** die Auswahl an iOS übergeben. iOS zeigt seine eigene Löschbestätigung. Bei Abbruch oder einem Fehler bleibt die Auswahl zur Korrektur erhalten.

Beim Verlassen einer ungespeicherten Runde kannst du die Auswahl verwerfen. Dabei wird nichts gelöscht. Ein App-Abbruch speichert keine angefangene Runde. Erfolgreich abgeschlossene Entscheidungen werden lokal gespeichert und in allen drei Modi berücksichtigt. Sind alle passenden Fotos durchgesehen, kannst du im jeweiligen Modus mit **Erneut durchsehen** neu anfangen.

Nach einem erfolgreichen Abschluss zeichnet sich ein grüner Haken ein. Die Bilanz nennt die Zahl durchgesehener und tatsächlich zur Löschung übergebener Aufnahmen sowie ihre Mediengröße in MB/GB. Nur die zuletzt bestätigte Lösch-Auswahl zählt; abgewählte und behaltene Aufnahmen tragen nichts zur Größe bei. Bei abgebrochener oder fehlgeschlagener iOS-Löschung erscheint keine Erfolgsbilanz. Wer alles behält, sieht 0 MB und „Alle Aufnahmen behalten“. Die Hakenanimation beachtet „Bewegung reduzieren“.

Für die Größenbilanz werden beim Durchsehen verfügbare lokale Dateigrößen über öffentliche PhotoKit-Eingaben und Dateimetadaten gelesen. Es laufen höchstens drei kurze Abfragen gleichzeitig, jede höchstens eine Sekunde. Fehlende Größen werden anhand von Auflösung und Videodauer geschätzt; bei Live Photos wird die Bewegungskomponente näherungsweise berücksichtigt. iCloud-Originale werden für diese Bilanz nicht heruntergeladen. Geschätzte Summen sind mit „Ca.“ gekennzeichnet. Die Zahl ist eine Mediengröße, keine Messung des momentan freien iPhone-Speichers; bei optimierter iCloud-Speicherung und bearbeiteten Dateien kann sie vom tatsächlichen lokalen Gewinn abweichen.

Gelöschte Fotos landen in **Fotos → Zuletzt gelöscht** und lassen sich dort normalerweise innerhalb von 30 Tagen wiederherstellen. Bei aktivierten **iCloud-Fotos** wird eine Löschung auch mit den anderen Geräten synchronisiert. iCloud-Fotos können zum Anzeigen von iOS heruntergeladen werden; ohne Netzwerk sind nicht lokal vorhandene Bilder möglicherweise nicht verfügbar.

## Datenschutz

Die App besitzt keinen Server, keine Werbung, keine Analysebibliothek und keine Kauf- oder Abo-Funktionen. Fotozugriff und Löschung laufen über Apples PhotoKit. Nur die Kennungen bereits abgeschlossener Fotos werden in den lokalen App-Einstellungen gespeichert. Der Fotozugriff lässt sich jederzeit in den iPhone-Einstellungen ändern. Die Startseite bietet bei eingeschränktem Zugriff die Möglichkeit, weitere Fotos freizugeben.

Für die Anzeige lesbarer Ortsnamen werden die gespeicherten Koordinaten einer betrachteten Aufnahme an Apples Geocoding-Dienst übergeben. Bilder und Videos werden dafür nicht hochgeladen. Ohne Aufnahmestandort erfolgt keine Ortsabfrage; die App fordert keine Berechtigung für den aktuellen iPhone-Standort an.

## Entwicklung und Prüfung

Der SwiftUI-/PhotoKit-Code ist unter `SwipeKlar/`. Das fertige Xcode-Projekt liegt bereits bei; `scripts/create_project.py` kann die Projektdatei reproduzieren.

Die reine Auswahllogik und der rückgängig machbare Entscheidungsablauf liegen in `SwipeKlar/Core/PhotoSelection.swift`. Auf einem Mac mit Xcode lassen sich ihre Tests ohne iPhone starten:

```sh
cd SwipeKlar
swift test
```

Die 41 Tests behandeln Datumsauswahl, 30-Tage-Grenze, Zeitzonen, Schalttage, bereits durchgesehene Aufnahmen, zufällige Auswahl und Rückgängig sowie Spulgrenzen, Zeitformatierung, Wiedergabeabsicht nach Spulen/Unterbrechungen, Wiederherstellung nach 2×-Halten, seitliche Tippentscheidungen, Ausschluss von Zoom-/Mehrfinger-/Haltegesten und die bestätigte Speicherbilanz einschließlich ungültiger Metadaten und Überlauf.

Ein Simulator-Build ohne Signatur:

```sh
xcodebuild -project SwipeKlar.xcodeproj -scheme SwipeKlar \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO build
```

Vor dem Einsatz bitte mit einigen entbehrlichen Fotos prüfen: eingeschränkter/voller/verweigerter Zugriff, beide Wischrichtungen, Rückgängig, Abwählen in der Löschübersicht, Abbruch der iOS-Löschbestätigung und Wiederherstellung aus „Zuletzt gelöscht“. Der Simulator hat eine eigene Mediathek; Testfotos kannst du per Drag-and-drop hinzufügen. Signatur und echte PhotoKit-Löschdialoge sollten auf dem iPhone geprüft werden.

Der iOS-Build und die Bedienung auf einem iPhone konnten in der Linux-Erstellungsumgebung nicht geprüft werden. Den Build kannst du über GitHub Actions oder Xcode ausführen; die Geräteprüfung erfolgt auf deinem iPhone. Ergebnisse der hier möglichen Prüfungen stehen in `VALIDIERUNG.md`.
