// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "SwipeKlarCore",
    products: [.library(name: "SwipeKlarCore", targets: ["SwipeKlarCore"])],
    targets: [
        .target(name: "SwipeKlarCore", path: "SwipeKlar/Core"),
        .testTarget(name: "SwipeKlarCoreTests", dependencies: ["SwipeKlarCore"], path: "Tests")
    ]
)
