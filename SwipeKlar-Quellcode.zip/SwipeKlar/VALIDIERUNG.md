# Prüfergebnisse

## Aktueller Stand: Version 1.5 mit Aufnahmeort, Randtippen, 2× und Abschlussbilanz

Prüfung am 17. Oktober 2026:

- **41 Swift-Logiktests bestanden**, 0 Fehler, Swift 6.0.3 unter Linux. Gegenüber 1.4 sind 17 Tests hinzugekommen: fünf für Randentscheidungen und deren Ausschluss bei Zoom/Mehrfingern/Halten, sieben für 2×-Halten und die Rückkehr zum vorherigen Zustand sowie fünf für die bestätigte Größenbilanz, ungültige Metadaten und Überlauf. Die bisherigen Auswahl-, Wisch- und Spultests bleiben enthalten.
- **Swift-Syntax und Projektstruktur:** alle 18 App-Quelldateien mit dem Swift-Compiler im Parse-Modus geprüft; insgesamt 25 Swift-Dateien einschließlich Package/Tests grammatisch mit Tree-sitter geprüft. Alle 18 Swift-Appdateien und zwei Ressourcen sind registriert; Objektverweise, Scheme, Datenschutz-Manifest und App-Icon sind gültig. Die Bash-Syntax des bestehenden IPA-Skripts ist gültig. Syntaxprüfungen sind keine Typprüfung mit dem iOS-SDK.
- **Gesten:** native Tap-/Long-Press-Erkenner in der vorhandenen UIScrollView. Einfaches Randtippen wartet auf das Scheitern des Doppeltipps und des Haltens. Halten markiert die gesamte Berührung als ungeeignet zum Sortieren; ein zweiter Finger beendet 2× und darf zur Pinch-Geste wechseln. Vorhandene Pan-/Pinch-Logik bleibt erhalten. Erkenner werden bei Zeitanzeigen-Updates nicht erneut aktiviert/deaktiviert, solange sich die Freigabe nicht ändert.
- **Ortsanzeige:** ausschließlich PHAsset.location, ohne Anfrage des Gerätestandorts. Apples CLGeocoder liefert Ort/Land. Zwischenspeicherung im Arbeitsspeicher und 650-ms-Verzögerung vermeiden unnötige Abfragen beim schnellen Wischen. Offline/bei Lookup-Fehlern bleiben Koordinaten sichtbar, ohne GPS-Daten „Kein Standort“.
- **Speicherbilanz:** bestätigte Ziel-IDs und Größen werden vor der Löschtransaktion festgehalten; das Ergebnis wird erst nach erfolgreichem PhotoKit-Abschluss zurückgegeben. Abgewählte Aufnahmen werden nicht mitgezählt. Lokale Größen werden über öffentliche PhotoKit-Eingaben und Dateimetadaten gelesen, mit höchstens drei parallelen Abfragen und einer Sekunde je Anfrage. Fehlende Größen, Live-Photo-Bewegung und gegebenenfalls Bearbeitungen werden als Schätzung gekennzeichnet. Für diese Abfrage sind iCloud-Downloads ausgeschaltet. Keine privaten KVC-Dateigrößen oder vollständigen Medien-Streams zur Größenmessung.
- **Abschluss:** gezeichneter Haken mit Erfolgshaptik, Anzahl entfernter Aufnahmen und MB-/GB-Summe. „Bewegung reduzieren“ wird berücksichtigt; die Ansicht lässt sich bei großer Schrift scrollen. Der Text erklärt „Zuletzt gelöscht“ und dass Mediengröße nicht mit sofortigem freien Gerätespeicher gleichzusetzen ist.
- **Version:** 1.5, Build 6. Bundle-ID und lokaler Fortschrittsschlüssel bleiben erhalten. Die Teilenfunktion und der bisherige Build-Workflow bleiben erhalten.

**Noch erforderlich:** vollständiger iOS-Build über GitHub und reale iPhone-Prüfung der Erkennerprioritäten, Doppeltipp am Rand, Übergang Halten→Pinch, Videorate/Audio, Abbruch/Hintergrund, Geocoding und Größenwerte mit echten lokalen/iCloud-Aufnahmen. Auch die Erfolgsanimation und Schriftdarstellung wurden hier nicht gerendert. In dieser Umgebung fehlen iOS-SDK und Simulator. Die konkrete Anleitung steht in `UPDATE-1.5.md`.

## Vorheriger Stand: Version 1.4 mit Spulkorrektur und Teilen

Die Wiedergabeabsicht wird jetzt unabhängig vom technischen Pausenzustand des AVPlayers gehalten. Wiederholte Startmeldungen einer Spulgeste können sie nicht zurücksetzen. Nur der Abschluss der aktuellsten Suche darf weiter abspielen; Pause, Hintergrundwechsel und Audiounterbrechungen bleiben wirksam. Alte Ende-Meldungen werden während des Spulens bzw. nach einem Rücksprung nicht als aktuelles Videoende behandelt.

Die gemeinsame Metadatenleiste bietet in beiden Medienansichten einen nativen Teilen-Button. Fotos werden über PhotoKit in der aktuellen, vollständigen Bildversion angefordert; JPEG/PNG werden geschrieben, andere Formate über ImageIO als JPEG ausgegeben. Videos werden über PhotoKit/AVAssetExportSession als MP4 bzw. MOV vorbereitet. UIActivityViewController erhält die temporäre Datei. Die Wiedergabe wird beim Vorbereiten pausiert. Generationskennungen verwerfen verspätete Lade-/Export-Antworten nach einem Abbruch; die Datei bleibt während der Teilenansicht verfügbar und wird danach entfernt.

Prüfung am 16. Oktober 2026:

- **24 Swift-Logiktests bestanden**, 0 Fehler, Swift 6.0.3 unter Linux. Die sechs neuen Tests prüfen automatische Wiederaufnahme nach Spulen, bewusstes Pausieren, mehrfachen Spulbeginn, schnelle aufeinanderfolgende Suchen, Unterbrechung während einer Suche und den Wechsel der Aufnahme vor einem verspäteten Abschluss.
- **Swift-Compiler im Parse-Modus und Grammatik:** alle 13 App-Quelldateien syntaktisch geprüft; insgesamt 18 Swift-Dateien einschließlich Package/Tests mit Tree-sitter geprüft. Kein Ersatz für iOS-Typprüfung.
- **Xcode-Projekt:** alle 13 Swift-Appdateien und beide Ressourcen sind registriert; Objektverweise, Scheme, Datenschutz-Manifest und App-Icon sind gültig. Das bestehende IPA-Skript hat gültige Bash-Syntax.
- **Versionskennung:** 1.4, Build 5. Bundle-ID, Fortschrittsschlüssel und Löschtransaktion bleiben erhalten. Für die Teilenansicht werden keine neuen Foto-Berechtigungen oder WhatsApp-Zugangsdaten benötigt.

**Noch erforderlich:** ein neuer GitHub-iOS-Build und Tests auf dem iPhone mit AVPlayer, den tatsächlichen Slider-Ereignissen, lokalen/iCloud-Medien, HEIC-Ausrichtung und WhatsApps Teilen-Erweiterung. Exportgeschwindigkeit, Ziel-App-Unterstützung und Dateilebenszyklus wurden hier nur am Code geprüft. In dieser Umgebung fehlen iOS-SDK und iPhone-Simulator. Geräteprüffälle stehen in `UPDATE-1.4.md`.

## Vorheriger Stand: Version 1.3 mit neuer Oberfläche und Löschvorschau

Der Nutzer bestätigt die erfolgreiche Funktion von Version 1.2 auf seinem iPhone. Version 1.3 ersetzt die bisherigen Farbflächen und großen Kartenabstände durch eine Startseite mit Systemfarben, eine Medienfläche über die verfügbare Bildschirmbreite, eine kompakte Metadatenzeile und Material-Bedienelemente. In der Löschübersicht öffnet ein exklusiv gegenüber kurzem Antippen ausgewerteter langer Druck eine große Prüfvorschau. Die Vorschau nutzt die vorhandenen Zoom-/Videokomponenten und ändert die Löschmarkierung nur über ihre ausdrückliche Auswahltaste.

Prüfung am 16. Oktober 2026:

- **18 Swift-Logiktests bestanden**, 0 Fehler, Swift 6.0.3 unter Linux. Sie prüfen Auswahl, Rückgängig, Spulzeiten und die Absicherung der Sortiergesten. Die neue SwiftUI-Langdruckgeste wird dadurch nicht auf echte Touchzustellung geprüft.
- **Swift-Compiler im Parse-Modus:** alle elf App-Quelldateien akzeptiert. Zusätzlich wurden alle 15 Swift-Dateien einschließlich Package und Tests mit Tree-sitter grammatisch geprüft. Beide Prüfungen ersetzen keine Typprüfung mit dem iOS-SDK.
- **Projektstruktur:** alle elf Swift-Appdateien und beide Ressourcen sind im Xcode-Projekt registriert. Scheme, Objektverweise, Datenschutz-Manifest und App-Icon wurden geprüft. Die Bash-Syntax des IPA-Buildskripts ist gültig.
- **Regressionseingrenzung:** Zoom-/Wisch-Engine, PhotoKit-Zugriff und Löschtransaktion, reine Auswahl-/Spul-/Gestenlogik sowie Buildskript und GitHub-Workflow sind bytegleich zum bestätigten Paket 1.2. Der bestehende Medienlader und AVPlayer bleiben erhalten; seine Metadaten- und Bedienansichten wurden angepasst.
- **Versionskennung:** 1.3, Build 4. Bundle-ID und lokaler Fortschrittsschlüssel bleiben erhalten.

**Noch erforderlich:** der vollständige iOS-Build über GitHub sowie die Prüfung von Darstellung, Langdruck/Antippen/Scrollen, flüssigen Gesten, Audio und Auswahlübernahme auf dem iPhone. In dieser Umgebung steht kein iOS-SDK oder iPhone-Simulator zur Verfügung. Die konkrete Aktualisierung und Geräteprüffälle stehen in `UPDATE-1.3.md`.

## Vorheriger Stand: Version 1.2 mit Zoom und Autoplay auf der Karte

Der Nutzer bestätigt, dass Version 1.1 nach der Build-Korrektur erfolgreich läuft. In Version 1.2 übernimmt die Wischkarte selbst den AVPlayer und die native UIScrollView-Zoomfläche. Das Vollbildfenster und die bisherige konkurrierende SwiftUI-DragGesture wurden aus diesem Ablauf entfernt. Ein passiver Mehrfinger-Beobachter und die native Pan-/Pinch-Erkennung trennen die Sortierentscheidung vom Verschieben des vergrößerten Ausschnitts. Der UIKit-Import für eigene Gestenerkenner ist ausdrücklich vorhanden.

- **18 Tests bestanden** mit Swift 6.0.3 unter Linux: die elf vorhandenen Tests und sieben Tests für die neue Gesten-Entscheidungslogik. Zweiter Finger, Zoom, ungültige Werte und abgebrochene/abgeschlossene Gesten dürfen keine unbeabsichtigte neue Sortierentscheidung erzeugen.
- **Swift-Syntax/Projektstruktur geprüft:** 13 Swift-Dateien grammatisch geprüft; alle neun App-Quelldateien und beide Ressourcen sind im Xcode-Projekt registriert. Datenschutz-Manifest und App-Icon sind gültig.
- **Darstellung:** Pinch-Zoom und Bildausschnitt laufen innerhalb der nativen UIScrollView. Der Video-Layer und bereits eingesetzte Bilder werden bei Zeitanzeigen-Updates nicht ausgetauscht. Die Spulleiste liegt außerhalb der Zoomfläche.
- **Versionskennung:** 1.2, Build 3; gleiche Bundle-ID und gleicher lokaler Fortschrittsschlüssel.

**Noch nicht geprüft für 1.2:** vollständige Typprüfung/Build mit dem iOS-SDK, tatsächliche UIKit-Touchereignisse, Wiedergabe/Autoplay und Framerate auf dem Gerät. Die automatisierten Tests prüfen die Gate-Logik; sie ersetzen keine physische Mehrfingerprüfung. Die Anleitung und Prüffälle stehen in `UPDATE-1.2.md`.

Referenz für den zusätzlichen UIKit-Unterklassenimport: [Apple – Implementing a custom gesture recognizer](https://developer.apple.com/documentation/uikit/implementing-a-custom-gesture-recognizer).

## Vorheriger Stand: Version 1.1 mit Video und Zoom

**Build-Korrektur für Lauf `38824324738`:** Xcode 16.4 meldete in `ReviewView.swift` beim Aufbau der Medienkarte „the compiler is unable to type-check this expression in reasonable time“. Die Karte wurde in getrennte SwiftUI-Typen für Rahmen/Interaktionen, Vorschau/Wischgeste, Metadaten und Statusanzeigen zerlegt. Die Barrierefreiheitsbeschriftung wird als eigener String berechnet; der lokale Wischversatz gehört jetzt zur Vorschau und wird bei einem Wechsel der Aufnahme zurückgesetzt. Alle drei Medienfunktionen bleiben enthalten. Swift-Syntax und Projektstruktur wurden erneut geprüft. Der erfolgreiche vollständige iOS-Build dieser Korrektur muss noch durch einen neuen GitHub-Lauf bestätigt werden.

Der Nutzer bestätigt die erfolgreiche Installation und grundsätzliche Funktion der vorherigen Fassung. Für Version 1.1 wurden Fotos und Videos in der Mediathek-Abfrage zusammengeführt, ein Detailbetrachter mit AVPlayer, Spulleiste, Start/Pause, Zeitanzeigen und Zehn-Sekunden-Sprüngen ergänzt und ein gemeinsamer UIScrollView-Zoom für Fotos und Video-Layer eingebaut. Datum/Uhrzeit stehen jetzt auf einer eigenen dunklen Fläche mit festgelegten hellen Schriftfarben; die neuen Quelldateien sind im generierten Xcode-Projekt registriert.

- **Elf Swift-Tests bestanden:** sieben vorhandene Auswahl-/Rückgängig-Tests und vier neue Tests für Spulgrenzen und Zeitformatierung einschließlich ungültiger AV-Zeitwerte. Ausgeführt mit Swift 6.0.3 unter Linux.
- **Swift-Compiler im Parse-Modus und Swift-Grammatik geprüft:** alle App-Dateien akzeptiert; insgesamt elf Swift-Dateien einschließlich Package und Tests grammatisch geprüft. Ein Parse-Check enthält keine iOS-Typprüfung.
- **Projektstruktur geprüft:** alle acht App-Quelldateien und beide Ressourcen in den Buildphasen vorhanden; gemeinsame Scheme-Verweise, Datenschutz-Manifest und App-Icon gültig.
- **Kontrastberechnung:** Datum auf Metadatenfläche ca. 16,63:1, Zusatzinformationen ca. 11,68:1; weiße Texte der Startfelder an allen Gradient-Endpunkten mindestens 4,99:1. Dies prüft die festgelegten Farben, nicht die gesamte gerenderte Oberfläche auf dem Gerät.

**Noch ausstehend für Version 1.1:** vollständiger iOS-Build auf GitHub, Wiedergabe und Spulen mit echten lokalen/iCloud-Videos, Gesten und Lesbarkeit auf dem iPhone sowie Aktualisierung über die vorhandene Installation. Hier ist kein iOS-SDK verfügbar. Die konkrete Geräte- und Update-Checkliste steht in `UPDATE-1.1.md`.

## Frühere Prüfungen

Prüfung am 13. Oktober 2026 in einer Linux-Umgebung.

- **7 Swift-Tests bestanden, 0 Fehler.** Die originale Auswahllogik und der Entscheidungsablauf wurden mit Swift 6.0.3 im Swift-Package kompiliert und als XCTest-Tests ausgeführt. Abgedeckt sind Jahrestage, 30-Tage-Grenze, zukünftige/undatierte Fotos, Zeitzonen, Schalttage, zufällige Auswahl, bereits abgeschlossene Fotos, Rückgängig und leere Runden.
- **Swift-Syntax geprüft:** alle App-Quelldateien vom Swift-Compiler im Parse-Modus akzeptiert; zusätzlich alle sieben Swift-Dateien mit der Swift-Grammatik von Tree-sitter geprüft. Die App verwendet Swift-5-Sprachmodus und setzt iOS 17 voraus.
- **Xcode-Projekt strukturell geprüft:** OpenStep-Projektdatei eingelesen; alle Objektverweise, Quelldateien und Ressourcen überprüft.
- **Gemeinsames Xcode-Scheme, Datenschutz-Manifest und App-Icon geprüft:** XML/Property-List/JSON lesbar; Icon 1024 × 1024 Pixel ohne Transparenz.

**Noch auf einem Mac bzw. iPhone erforderlich:** vollständiger iOS-Build mit SwiftUI/PhotoKit, Signierung, Bildschirmdarstellung, Berechtigungsdialoge und tatsächliches Löschen bzw. Abbrechen des Löschens. Linux bietet kein iOS-SDK; ein Syntaxcheck ersetzt keinen iOS-Build. Die Befehle und Geräteprüfungen stehen in `README.md`.

## Ergänzung für den Windows-Weg

Für die Installation vom Windows-PC gibt es nun eine vorbereitete GitHub-Actions-Anweisung und ein IPA-Buildskript. Der Workflow startet ausschließlich manuell, führt die vorhandenen Swift-Tests auf einem GitHub-Mac aus, baut für ein echtes iPhone ohne Signatur und stellt die IPA zum anschließenden Signieren in Sideloadly bereit. Es werden keine Apple-Zugangsdaten im Build benötigt.

Lokal geprüft: YAML-Struktur der Build-Anweisung, Bash-Syntax des Buildskripts, seine verständliche Ablehnung eines direkten Builds unter Linux und die ZIP-Struktur des Windows-Pakets einschließlich der enthaltenen Quelldateien. Die Quellen des iPhone-Programms und seiner Logiktests wurden bei dieser Ergänzung nicht verändert.

**Noch nicht ausgeführt:** der GitHub-Actions-Lauf und ein vollständiger iOS-Build, die Erzeugung einer echten IPA und die Sideloadly-Installation unter Windows. Das Windows-Paket enthält deshalb noch keine fertige IPA. Diese wird nach einem erfolgreichen Workflow-Lauf in deinem GitHub-Projekt verfügbar. Die Schrittfolge steht in `WINDOWS-ANLEITUNG.md`.

## Korrektur nach dem ersten GitHub-Build

Der vom Nutzer ausgeführte GitHub-Lauf `38816511497` scheiterte beim Kompilieren mit `PhotoLibrary.swift:101:33: error: value of type 'PHPhotoLibrary' has no member 'presentLimitedLibraryPicker'`. Die Methode zum Erweitern des eingeschränkten Fotozugriffs wird über `PhotosUI` bereitgestellt. Der dafür fehlende Import wurde in `PhotoLibrary.swift` ergänzt.

Die Änderung betrifft ausschließlich diesen Framework-Import. Die Quellcode-ZIP und das Windows-Paket wurden mit der korrigierten Datei neu erstellt und auf Lesbarkeit und vollständigen Inhalt geprüft. Der anschließende Stand wird im folgenden Abschnitt dokumentiert.

## Erfolgreiches Kompilieren und Korrektur der IPA-Vorbereitung

Der vom Nutzer gezeigte GitHub-Lauf `38818726414` mit Xcode 16.4 meldet `BUILD SUCCEEDED`. Die App lässt sich nach dem PhotosUI-Import erfolgreich für das iPhone kompilieren. Danach scheiterte das Buildskript mit Exit-Code 1 an der Architekturprüfung: `lipo` interpretierte den hinter `-verify_arch arm64` stehenden Dateipfad als weiteren Architekturnamen.

Das Skript übergibt den Dateipfad jetzt vor der Option: `xcrun lipo "$swipeklar_app/SwipeKlar" -verify_arch arm64`. Die Bash-Syntax wurde geprüft und die Download-Archive mit dem korrigierten Skript neu erstellt und auf vollständigen Inhalt geprüft.

Noch ausstehend sind ein erneuter Cloud-Lauf einschließlich der nachfolgenden IPA-Verpackung, die Sideloadly-Installation und die Bedienungsprüfung auf dem iPhone. Der nachgewiesene erfolgreiche Kompilierlauf allein bestätigt noch keine fertige IPA oder erfolgreiche Geräteinstallation.
