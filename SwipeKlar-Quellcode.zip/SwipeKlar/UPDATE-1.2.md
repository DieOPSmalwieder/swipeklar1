# SwipeKlar 1.2: direkt zoomen und Videos automatisch abspielen

## Bedienung auf der Wischkarte

- **Videos starten automatisch** auf der gerade sichtbaren Karte, sobald sie geladen sind. Ein Extra-Fenster wird nicht mehr geöffnet. Bei iCloud-Videos kann der Start auf die Internetverbindung und das Laden warten.
- **Zwei Finger:** Foto oder Video direkt vergrößern und verkleinern, bis maximal 5-fach. Die Wiedergabe kann während des Zoomens weiterlaufen.
- **Doppeltipp:** auf 2,5-fach vergrößern bzw. zur Originalgröße zurückkehren.
- **Vergrößert mit einem Finger ziehen:** den Bildausschnitt verschieben.
- **Pfeiltaste neben dem Datum:** den Zoom animiert auf die Originalgröße zurücksetzen.
- **Bei Originalgröße mit einem Finger horizontal wischen:** wie bisher links zum Löschen vormerken und rechts behalten. Der Wisch muss über 90 Punkte und überwiegend horizontal sein.
- **Spulleiste und Wiedergabetasten:** direkt unter dem Video pausieren, starten und spulen. Die Bedienelemente liegen außerhalb der Zoom-/Wischfläche.

Eine Berührung, bei der ein zweiter Finger oder eine Zoomgeste beteiligt war, wird für den Rest dieser Geste vom Aussortieren ausgeschlossen. Erst eine neue Ein-Finger-Geste in Originalgröße kann wieder sortieren. Die Behalten-/Vormerken-Tasten bleiben als bewusste Alternative erreichbar. Die Datum- und Uhrzeitanzeige behält ihre kontrastreiche dunkle Fläche.

Ein Wechsel zur nächsten/vorherigen Aufnahme stoppt die alte Wiedergabe und setzt den Zoom der neuen Karte zurück. Verlassen der App, Audiounterbrechungen und Abschluss-/Verlassen-Dialoge pausieren die Wiedergabe. Danach kannst du über Start/Pause fortsetzen. Videos laufen einmal bis zum Ende; erneutes Starten beginnt dann wieder am Anfang.

## Aktualisierung über den Windows-PC

1. Die neue **SwipeKlar-Quellcode.zip** herunterladen und gepackt lassen. Der Dateiname muss exakt stimmen, ohne einen Browserzusatz wie `(1)`.
2. Im bestehenden GitHub-Projekt **Code → Add file → Upload files** öffnen, die gleichnamige ZIP ersetzen und **Commit changes** auf `main` bestätigen.
3. **Actions → SwipeKlar iPhone bauen → Run workflow → main → Run workflow** starten. Die bestehende Workflow-Datei passt weiterhin.
4. Bei einem erfolgreichen Lauf links **Summary** öffnen und unten unter **Artifacts → SwipeKlar-iPhone** das ZIP herunterladen. Darin liegt die neue IPA.
5. Mit Sideloadly über die vorhandene App installieren: dieselbe Apple-ID und dieselbe Bundle-ID verwenden und die vorhandene App installiert lassen, damit dein Fortschritt erhalten bleibt.

Die Versionsnummer ist **1.2**, Build **3**. Die kostenlose Signierung wird weiterhin wie bisher über Sideloadly erneuert.

## Auf dem iPhone prüfen

- Ein Foto direkt mit zwei Fingern vergrößern, verschieben, doppeltippen und mit der Pfeiltaste zurücksetzen. Dabei sollen die Entscheidungszähler unverändert bleiben.
- Einen horizontalen Wisch beginnen, dann vor dem Loslassen einen zweiten Finger auf die Medienfläche setzen: Die Aufnahme soll bleiben. Das gilt auch ohne sichtbare Größenänderung.
- Nach dem Zoomen den Ausschnitt deutlich mehr als 90 Punkte verschieben: Die Aufnahme soll bleiben. Herauszoomen und den Finger erst abheben; eine neu begonnene Ein-Finger-Geste soll wieder aussortieren können.
- Mehrere Foto-/Videokarten zügig durchwechseln. Jedes neue Video soll automatisch starten, das alte stoppen. Es sollen keine zwei Tonspuren gleichzeitig laufen.
- Ein Video während der Wiedergabe zoomen und die Spulleiste bedienen. Pausiert spulen soll das Video pausiert lassen. Die Sortierzähler sollen beim Spulen unverändert bleiben.
- Ein laufendes Video über „Fertig“/Zurück unterbrechen, die App in den Hintergrund schicken und eine Audiounterbrechung prüfen: Die Wiedergabe soll pausieren.
- Den gleichen Ablauf bei einem iCloud-Video, eingeschränktem Medienzugriff und auf einem kleineren iPhone prüfen. Nach dem Update sollen die bereits gespeicherten Entscheidungen erhalten sein.

## Prüfstand

18 Swift-Logiktests bestanden; sieben davon betreffen die neuen Gestengrenzen. Swift-Syntax und Projektstruktur wurden geprüft. Die native Darstellung verwendet UIScrollView-Zoom und AVPlayerLayer; Fotos werden bei Wiedergabe-Zeitupdates nicht erneut in die Bildfläche eingesetzt.

Ein vollständiger iOS-Build, reale Touchfolgen, die Framerate und Autoplay auf dem iPhone konnten in dieser Linux-Umgebung nicht geprüft werden. Das bestätigt erst der nächste GitHub-Build zusammen mit der Geräteprüfung. Die Tests prüfen die Entscheidungslogik, nicht die tatsächliche Zustellung der UIKit-Touchereignisse.
