# SwipeKlar 1.6.1: „An diesem Tag“ nur aus früheren Jahren

„An diesem Tag“ zeigt jetzt ausschließlich Fotos und Videos mit gleichem Tag und Monat aus früheren Jahren. Aufnahmen von heute werden ausgeschlossen. Entscheidend sind Kalender und lokale Zeitzone des iPhones, auch rund um den Jahreswechsel.

Wenn keine passenden Aufnahmen aus früheren Jahren vorhanden sind oder alle bereits durchgesehen wurden, erscheint wie bisher die entsprechende leere Ansicht. Heutige Aufnahmen bleiben unter „Aktuelles“ verfügbar.

## Aktualisieren unter Windows

1. **SwipeKlar-Quellcode.zip** herunterladen und gepackt lassen. Der Dateiname muss exakt stimmen, ohne `(1)`.
2. In `DieOPSmalwieder/swipeklar1` unter **Code → Add file → Upload files** die vorhandene gleichnamige ZIP ersetzen und auf `main` committen.
3. Unter **Actions → SwipeKlar iPhone bauen → Run workflow → main → Run workflow** einen neuen Lauf starten. Nicht „Re-run jobs“ eines alten Laufs wählen.
4. Nach erfolgreichem Lauf unter **Summary → Artifacts → SwipeKlar-iPhone** die neue IPA herunterladen und mit Sideloadly über die bestehende App installieren. Dieselbe Apple-ID und Bundle-ID verwenden und die bestehende App installiert lassen, damit der Fortschritt erhalten bleibt.

Version **1.6.1**, Build **8**. Die bestehende Workflow-Datei passt weiterhin.

## Prüfen

- In „An diesem Tag“ dürfen nur passende Aufnahmen aus früheren Jahren erscheinen, keine heutigen Fotos oder Videos.
- Heutige Aufnahmen müssen in „Aktuelles“ weiterhin verfügbar sein, sofern sie noch nicht als durchgesehen gespeichert sind.
- Fehlen historische Aufnahmen für den heutigen Kalendertag, muss der Modus eine leere Ansicht zeigen.

Zwei zusätzliche Regressionstests prüfen den Ausschluss heutiger Aufnahmen, ihre Verfügbarkeit in „Aktuelles“ und den lokalen Jahreswechsel. Der vollständige iOS-Build erfolgt über den neuen GitHub-Lauf; einzelne Prüfergebnisse stehen in `VALIDIERUNG.md`.
