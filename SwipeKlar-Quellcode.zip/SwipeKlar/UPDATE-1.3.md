# SwipeKlar 1.3: neue Oberfläche und große Prüfvorschau

## Was sich geändert hat

- Die Startseite nutzt native Systemfarben, klare Schrift und drei schlichte Moduszeilen. Sie folgt dem Hell- oder Dunkelmodus deines iPhones.
- Fotos und Videos reichen bis an die seitlichen Bildschirmränder. Der bisherige Kartenrahmen und große Außenabstände entfallen. Die kompakte Datumsanzeige sitzt oberhalb der Aufnahme, die Sortiertasten liegen in einer Materialleiste darunter.
- Zoom mit zwei Fingern, Doppeltipp, automatischer Videostart und die Spulleiste funktionieren weiterhin direkt auf der Aufnahme. Bei aktivem Zoom erscheint „1×“ zum Zurücksetzen.
- In „Auswahl prüfen“ öffnet Gedrückthalten einer Miniatur die große Vorschau. Das funktioniert auch bei Videos mit Ton, Start/Pause und Spulleiste. In der Vorschau kann man zoomen und den Ausschnitt verschieben, ohne eine Sortierentscheidung auszulösen.
- Die Vorschau zeigt ausdrücklich, ob die Aufnahme noch zum Löschen ausgewählt ist. Mit „Diese Aufnahme behalten“ entfernst du ihre Markierung. Sie bleibt geöffnet, bis du mit „Fertig“ zur Übersicht zurückkehrst. Falls nötig, kannst du sie wieder vormerken.
- Das Öffnen und Schließen der Vorschau verändert keine Auswahl. Ein langes Drücken und anschließendes Loslassen lösen keinen zusätzlichen kurzen Tipp aus. Die endgültige Löschung erfolgt weiterhin ausschließlich über die Löschtaste und Apples Bestätigung.

## Aktualisieren vom Windows-PC

1. **SwipeKlar-Quellcode.zip** herunterladen und gepackt lassen. Der Dateiname muss exakt stimmen, ohne einen Zusatz wie `(1)`.
2. In deinem bestehenden Projekt `DieOPSmalwieder/swipeklar1` unter **Code → Add file → Upload files** die vorhandene gleichnamige ZIP ersetzen und auf `main` mit **Commit changes** speichern.
3. **Actions → SwipeKlar iPhone bauen → Run workflow → main → Run workflow** starten. Einen neuen Lauf starten; „Re-run jobs“ eines älteren Laufs baut dessen alten Quellcode.
4. Nach dem erfolgreichen Lauf **Summary → Artifacts → SwipeKlar-iPhone** herunterladen. Das ZIP entpacken und die enthaltene IPA verwenden.
5. Mit Sideloadly über die bestehende App installieren. Dieselbe Apple-ID und dieselbe Bundle-ID verwenden. Die vorhandene App installiert lassen, damit der Fortschritt erhalten bleibt.

Die Version lautet **1.3**, Build **4**. Die bestehende Workflow-Datei und das Verfahren zum Erneuern der kostenlosen Signierung passen weiterhin.

## Auf dem iPhone prüfen

1. Startseite im hellen und dunklen Systemmodus öffnen. Alle drei Modi müssen lesbar und erreichbar bleiben, auch mit größer eingestellter Schrift.
2. Ein Foto und ein Video direkt zoomen, verschieben und mit „1×“ zurücksetzen. Beim Zoomen darf keine Sortierentscheidung ausgelöst werden. Videos müssen weiter automatisch starten und sich spulen lassen.
3. Mehrere Fotos und ein Video vormerken und „Auswahl prüfen“ öffnen. Ein kurzer Tipp muss nur die Markierung ändern.
4. Eine Miniatur länger als etwa eine halbe Sekunde halten. Die große Vorschau muss erscheinen. Ohne Auswahländerung „Fertig“ drücken: Markierung und Anzahl müssen gleich bleiben. Nach dem Loslassen des langen Drucks darf sich die Markierung nicht zusätzlich umschalten.
5. Dieselbe Vorschau erneut öffnen, hineinzoomen und „Diese Aufnahme behalten“ wählen. Nach „Fertig“ muss die Miniatur abgewählt und die Anzahl um eins kleiner sein. In der Vorschau gegebenenfalls erneut vormerken und den umgekehrten Ablauf prüfen.
6. Ein Video lange drücken: Wiedergabe, Spulen und Zoom prüfen. Vorschau schließen: Der Ton muss stoppen. Für ein iCloud-Video zusätzlich Laden bzw. Fehler/Wiederholen prüfen.
7. Durch die Löschübersicht scrollen: Scrollen soll keine Auswahl ändern und keine Vorschau öffnen. Auch abgewählte Aufnahmen müssen weiterhin per Gedrückthalten prüfbar bleiben.
8. Alle Markierungen entfernen und abschließen: Es darf nichts gelöscht werden. Einen tatsächlichen Löschdialog mit entbehrlichen Aufnahmen einmal abbrechen: Die Auswahl muss erhalten bleiben.

## Prüfstand

Syntax und Projektstruktur lassen sich hier prüfen; für einen vollständigen iOS-Build und die echte Touch-/Darstellungsprüfung sind der neue GitHub-Lauf und dein iPhone erforderlich. Die Quellcode-ZIP enthält keine bereits gebaute IPA. Einzelne Prüfergebnisse stehen in `VALIDIERUNG.md`.
