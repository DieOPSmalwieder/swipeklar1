# SwipeKlar 1.6: farbige Animation beim Randtippen

- **Rechts tippen:** blauer Randimpuls mit Häkchen und „Behalten“. Die Aufnahme gleitet nach rechts; danach erscheint die nächste.
- **Links tippen:** roter Randimpuls mit Papierkorb und „Vorgemerkt“. Die Aufnahme gleitet nach links. Wie bisher wird erst beim abschließenden Bestätigen tatsächlich gelöscht.
- Die Rückmeldung dauert nach Erkennung eines einzelnen Randtipps ungefähr **0,3 Sekunden**. Währenddessen kann keine zweite Entscheidung erfolgen.
- **„Bewegung reduzieren“:** Farbe, Symbol und kurze Rückmeldung bleiben erhalten; seitliche Bewegung und Drehung entfallen.
- Doppeltipp zum Zoomen, Wischen und 2×-Halten bleiben erhalten. Randtipps werden weiterhin nur bei Originalgröße ausgewertet. Ein abgebrochener Wechsel, etwa beim Wechsel in den Hintergrund, darf keine spätere Entscheidung auslösen.

## Aktualisierung unter Windows

1. **SwipeKlar-Quellcode.zip** herunterladen, gepackt lassen und auf den exakten Dateinamen ohne `(1)` achten.
2. In `DieOPSmalwieder/swipeklar1` unter **Code → Add file → Upload files** die vorhandene gleichnamige ZIP ersetzen und mit **Commit changes** auf `main` speichern.
3. **Actions → SwipeKlar iPhone bauen → Run workflow → main → Run workflow** neu starten. Nicht „Re-run jobs“ eines alten Laufs wählen.
4. Nach erfolgreichem Lauf **Summary → Artifacts → SwipeKlar-iPhone** herunterladen, entpacken und die IPA mit Sideloadly über die bestehende App installieren. Dieselbe Apple-ID und Bundle-ID verwenden; die bestehende App installiert lassen, damit der Fortschritt erhalten bleibt.

Version **1.6**, Build **7**. Die Workflow-Datei passt weiterhin.

## Auf dem iPhone prüfen

- Links und rechts jeweils einmal tippen: richtige Farbe, passendes Symbol und Bewegungsrichtung; anschließend genau eine verbuchte Entscheidung.
- Mehrfach schnell auf denselben Rand tippen, zusätzlich unten eine Entscheidung oder Rückgängig drücken: während einer laufenden Animation darf keine zweite Aufnahme gewählt werden.
- Doppeltippen direkt am Rand: Zoom ohne Entscheidung oder farbige Sortierbestätigung. Bei aktivem Zoom den Ausschnitt verschieben und am Rand tippen: keine Sortierung.
- Ein Video gedrückt halten, auch am Rand: 2× Tempo ohne rote/blaue Sortieranimation beim Loslassen. Weiterhin normal wischen, spulen und teilen.
- Einen Randtipp auslösen und sofort die App verlassen: Bei der Rückkehr darf keine verzögerte Entscheidung mehr erfolgen. Dieselbe Aufnahme muss weiter prüfbar sein.
- „Bewegung reduzieren“ aktivieren: Farbe und Symbol sollen sichtbar bleiben, die Aufnahme soll nicht seitlich wegfliegen.

## Prüfstand

Swift-Syntax und Xcode-Projektstruktur werden in dieser Umgebung geprüft. Für den vollständigen iOS-Build, die gerenderte Animation und reale Touchfolgen sind der neue GitHub-Lauf und das iPhone erforderlich. Einzelne Prüfergebnisse stehen in `VALIDIERUNG.md`.
