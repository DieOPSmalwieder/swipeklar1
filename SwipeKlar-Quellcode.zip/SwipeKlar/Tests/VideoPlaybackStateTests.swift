import XCTest
@testable import SwipeKlarCore

final class VideoPlaybackStateTests: XCTestCase {
    func testHoldingPlayingVideoRestoresNormalSpeedWithoutPausing() {
        var state = VideoPlaybackState()
        state.play()
        state.beginFastPlayback()
        XCTAssertEqual(state.rate, 2)
        XCTAssertTrue(state.shouldPlay)
        state.endFastPlayback()
        XCTAssertEqual(state.rate, 1)
        XCTAssertTrue(state.shouldPlay)
    }

    func testHoldingPausedVideoOnlyPlaysUntilRelease() {
        var state = VideoPlaybackState()
        state.beginFastPlayback()
        XCTAssertTrue(state.shouldPlay)
        state.endFastPlayback()
        XCTAssertFalse(state.shouldPlay)
        XCTAssertEqual(state.rate, 1)
    }

    func testRepeatedHoldStartCannotOverwriteOriginalPausedState() {
        var state = VideoPlaybackState()
        state.beginFastPlayback()
        state.beginFastPlayback()
        state.endFastPlayback()
        XCTAssertFalse(state.shouldPlay)
    }

    func testInterruptionDuringHoldPreventsReleaseFromRestartingVideo() {
        var state = VideoPlaybackState()
        state.play()
        state.beginFastPlayback()
        state.pause()
        state.endFastPlayback()
        XCTAssertFalse(state.shouldPlay)
        XCTAssertEqual(state.rate, 1)
    }

    func testSeekingCancelsBoostButPreservesPlaybackIntent() {
        var state = VideoPlaybackState()
        state.play()
        state.beginFastPlayback()
        let seek = state.beginSeek()
        XCTAssertEqual(state.rate, 1)
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertTrue(state.shouldPlay)
    }

    func testBoostCannotStartDuringScrubbingOrSeeking() {
        var state = VideoPlaybackState()
        state.play()
        state.beginScrubbing()
        state.beginFastPlayback()
        XCTAssertFalse(state.isFastPlayback)
        XCTAssertFalse(state.shouldPlay)
        state.endScrubbing()
        _ = state.beginSeek()
        state.beginFastPlayback()
        XCTAssertFalse(state.isFastPlayback)
        XCTAssertFalse(state.shouldPlay)
    }

    func testChangingMediaDuringHoldResetsSpeedAndPlaybackIntent() {
        var state = VideoPlaybackState()
        state.play()
        state.beginFastPlayback()
        state.reset()
        state.endFastPlayback()
        XCTAssertEqual(state.rate, 1)
        XCTAssertFalse(state.shouldPlay)
    }

    func testPlayingVideoResumesAfterScrubbingIncludingRepeatedStartCallbacks() {
        var state = VideoPlaybackState()
        state.play()
        state.beginScrubbing()
        state.beginScrubbing()
        XCTAssertTrue(state.wantsPlayback)
        XCTAssertFalse(state.shouldPlay)
        state.endScrubbing()
        let seek = state.beginSeek()
        XCTAssertFalse(state.shouldPlay)
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertTrue(state.shouldPlay)
    }

    func testPausedVideoStaysPausedAfterScrubbing() {
        var state = VideoPlaybackState()
        state.beginScrubbing()
        state.endScrubbing()
        let seek = state.beginSeek()
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
    }

    func testRapidSkipCompletionsCannotResumeAnOutdatedSeek() {
        var state = VideoPlaybackState()
        state.play()
        let oldSeek = state.beginSeek()
        let latestSeek = state.beginSeek()
        XCTAssertFalse(state.completeSeek(oldSeek))
        XCTAssertTrue(state.isSeeking)
        XCTAssertFalse(state.shouldPlay)
        XCTAssertTrue(state.completeSeek(latestSeek))
        XCTAssertTrue(state.shouldPlay)
    }

    func testPauseOrInterruptionDuringSeekPreventsAutoplay() {
        var state = VideoPlaybackState()
        state.play()
        let seek = state.beginSeek()
        state.pause()
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
    }

    func testSeekFinishingDuringScrubbingCannotStartVideoEarly() {
        var state = VideoPlaybackState()
        state.play()
        let seek = state.beginSeek()
        state.beginScrubbing()
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
        state.endScrubbing()
        XCTAssertTrue(state.shouldPlay)
    }

    func testChangingMediaInvalidatesOutstandingSeekCallbacks() {
        var state = VideoPlaybackState()
        state.play()
        let seek = state.beginSeek()
        state.reset()
        XCTAssertFalse(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
        XCTAssertFalse(state.isSeeking)
        XCTAssertFalse(state.isScrubbing)
    }
}
