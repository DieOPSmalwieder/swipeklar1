import XCTest
@testable import SwipeKlarCore

final class VideoPlaybackStateTests: XCTestCase {
    func testPlayingVideoResumesAfterScrubbingIncludingRepeatedStartCallbacks() {
        var state = VideoPlaybackState()
        state.play()
        state.beginScrubbing()
        state.beginScrubbing()
        XCTAssertTrue(state.wantsPlayback)
        XCTAssertFalse(state.shouldPlay)
        state.endScrubbing()
        let seek = state.beginSeek()
        XCTAssertFalse(state.shouldPlay)
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertTrue(state.shouldPlay)
    }

    func testPausedVideoStaysPausedAfterScrubbing() {
        var state = VideoPlaybackState()
        state.beginScrubbing()
        state.endScrubbing()
        let seek = state.beginSeek()
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
    }

    func testRapidSkipCompletionsCannotResumeAnOutdatedSeek() {
        var state = VideoPlaybackState()
        state.play()
        let oldSeek = state.beginSeek()
        let latestSeek = state.beginSeek()
        XCTAssertFalse(state.completeSeek(oldSeek))
        XCTAssertTrue(state.isSeeking)
        XCTAssertFalse(state.shouldPlay)
        XCTAssertTrue(state.completeSeek(latestSeek))
        XCTAssertTrue(state.shouldPlay)
    }

    func testPauseOrInterruptionDuringSeekPreventsAutoplay() {
        var state = VideoPlaybackState()
        state.play()
        let seek = state.beginSeek()
        state.pause()
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
    }

    func testSeekFinishingDuringScrubbingCannotStartVideoEarly() {
        var state = VideoPlaybackState()
        state.play()
        let seek = state.beginSeek()
        state.beginScrubbing()
        XCTAssertTrue(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
        state.endScrubbing()
        XCTAssertTrue(state.shouldPlay)
    }

    func testChangingMediaInvalidatesOutstandingSeekCallbacks() {
        var state = VideoPlaybackState()
        state.play()
        let seek = state.beginSeek()
        state.reset()
        XCTAssertFalse(state.completeSeek(seek))
        XCTAssertFalse(state.shouldPlay)
        XCTAssertFalse(state.isSeeking)
        XCTAssertFalse(state.isScrubbing)
    }
}
