import XCTest
@testable import SwipeKlarCore

final class PlaybackTimeTests: XCTestCase {
    func testSeekingClampsToVideoBoundaries() {
        XCTAssertEqual(PlaybackTime.clamped(-10, duration: 60), 0)
        XCTAssertEqual(PlaybackTime.clamped(75, duration: 60), 60)
        XCTAssertEqual(PlaybackTime.clamped(12.5, duration: 60), 12.5)
    }

    func testUnknownOrInvalidDurationCannotProduceInvalidSeekTimes() {
        for duration in [0.0, -1, .nan, .infinity] {
            XCTAssertEqual(PlaybackTime.clamped(10, duration: duration), 0)
        }
        XCTAssertEqual(PlaybackTime.clamped(.nan, duration: 60), 0)
        XCTAssertEqual(PlaybackTime.clamped(.infinity, duration: 60), 60)
        XCTAssertEqual(PlaybackTime.clamped(-.infinity, duration: 60), 0)
    }

    func testPlaybackLabelsAtMinuteAndHourBoundaries() {
        XCTAssertEqual(PlaybackTime.label(0), "0:00")
        XCTAssertEqual(PlaybackTime.label(59.99), "0:59")
        XCTAssertEqual(PlaybackTime.label(60), "1:00")
        XCTAssertEqual(PlaybackTime.label(3599), "59:59")
        XCTAssertEqual(PlaybackTime.label(3600), "1:00:00")
        XCTAssertEqual(PlaybackTime.label(3661), "1:01:01")
    }

    func testUnloadedTimesDoNotCrashTimeFormatting() {
        for seconds in [-1.0, .nan, .infinity, -.infinity, Double(Int.max)] {
            XCTAssertEqual(PlaybackTime.label(seconds), "0:00")
        }
    }
}
