import XCTest
@testable import SwipeKlarCore

final class CleanupSummaryTests: XCTestCase {
    func testOnlyConfirmedDeletedAndReviewedIDsContributeToStorage() {
        let summary = CleanupSummary.confirmed(reviewedIDs: ["keep", "delete", "unchecked"],
            deletedIDs: ["delete", "unrelated"], sizes: [
                "delete": MediaSizeEstimate(bytes: 8_000_000, isEstimated: false),
                "unchecked": MediaSizeEstimate(bytes: 30_000_000, isEstimated: false),
                "unrelated": MediaSizeEstimate(bytes: 99_000_000, isEstimated: false)])
        XCTAssertEqual(summary.reviewedCount, 3)
        XCTAssertEqual(summary.deletedCount, 1)
        XCTAssertEqual(summary.bytes, 8_000_000)
        XCTAssertFalse(summary.isEstimated)
    }

    func testKeepingEverythingAlwaysReportsZero() {
        let summary = CleanupSummary.confirmed(reviewedIDs: ["a"], deletedIDs: [],
            sizes: ["a": MediaSizeEstimate(bytes: 5_000_000, isEstimated: true)])
        XCTAssertEqual(summary.deletedCount, 0)
        XCTAssertEqual(summary.bytes, 0)
        XCTAssertFalse(summary.isEstimated)
    }

    func testEstimatedAndMissingSizesAreNotPresentedAsExact() {
        let estimated = CleanupSummary.confirmed(reviewedIDs: ["a", "b"], deletedIDs: ["a", "b"],
            sizes: ["a": MediaSizeEstimate(bytes: 5_000_000, isEstimated: true)])
        XCTAssertTrue(estimated.isEstimated)
        XCTAssertEqual(estimated.bytes, 5_000_000)
    }

    func testInvalidSizesAndOverflowDoNotWrapToNegativeStorage() {
        let summary = CleanupSummary.confirmed(reviewedIDs: ["a", "b", "c"], deletedIDs: ["a", "b", "c"], sizes: [
            "a": MediaSizeEstimate(bytes: Int64.max, isEstimated: false),
            "b": MediaSizeEstimate(bytes: 1, isEstimated: false),
            "c": MediaSizeEstimate(bytes: -200, isEstimated: false)])
        XCTAssertEqual(summary.bytes, Int64.max)
    }

    func testFallbackHandlesVideoDurationLivePhotosAndInvalidMetadata() {
        let still = MediaSizeHeuristic.bytes(width: 4032, height: 3024, duration: 0, isVideo: false, isLivePhoto: false)
        let live = MediaSizeHeuristic.bytes(width: 4032, height: 3024, duration: 0, isVideo: false, isLivePhoto: true)
        XCTAssertGreaterThan(still, 0)
        XCTAssertGreaterThan(live, still)
        let short = MediaSizeHeuristic.bytes(width: 1920, height: 1080, duration: 10, isVideo: true, isLivePhoto: false)
        let long = MediaSizeHeuristic.bytes(width: 1920, height: 1080, duration: 20, isVideo: true, isLivePhoto: false)
        XCTAssertGreaterThan(long, short)
        for duration in [-1.0, .nan, .infinity] {
            XCTAssertEqual(MediaSizeHeuristic.bytes(width: 0, height: -1, duration: duration, isVideo: true, isLivePhoto: false), 0)
        }
        XCTAssertEqual(MediaSizeHeuristic.bytes(width: Int.max, height: Int.max, duration: 0, isVideo: false, isLivePhoto: false), Int64.max)
    }
}
