import Foundation
import XCTest
@testable import SwipeKlarCore

final class PhotoSelectionTests: XCTestCase {
    private var calendar: Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        return calendar
    }
    private func date(_ text: String) -> Date {
        ISO8601DateFormatter().date(from: text)!
    }
    private var now: Date { date("2026-10-13T12:00:00Z") }

    func testAnniversaryMatchesMonthAndDayAcrossYears() {
        let records = [
            PhotoRecord(id: "old", date: date("2020-10-13T19:00:00Z")),
            PhotoRecord(id: "today", date: date("2026-10-13T08:00:00Z")),
            PhotoRecord(id: "wrongDay", date: date("2020-10-12T19:00:00Z")),
            PhotoRecord(id: "future", date: date("2027-10-13T08:00:00Z")),
            PhotoRecord(id: "undated", date: nil)
        ]
        XCTAssertEqual(PhotoSelection.queue(records, mode: .onThisDay, reviewed: [], now: now, calendar: calendar), ["today", "old"])
    }

    func testRecentIncludesCutoffAndExcludesFutureAndUndated() {
        let records = [
            PhotoRecord(id: "cutoff", date: date("2026-09-13T00:00:00Z")),
            PhotoRecord(id: "tooOld", date: date("2026-09-12T23:59:59Z")),
            PhotoRecord(id: "now", date: now),
            PhotoRecord(id: "future", date: date("2026-10-13T12:00:01Z")),
            PhotoRecord(id: "undated", date: nil)
        ]
        XCTAssertEqual(PhotoSelection.queue(records, mode: .recent, reviewed: [], now: now, calendar: calendar), ["now", "cutoff"])
    }

    func testRandomIncludesUndatedWithoutDuplicatesAndExcludesReviewed() {
        let records = (0..<100).map { PhotoRecord(id: String($0), date: nil) }
        let queue = PhotoSelection.queue(records, mode: .random, reviewed: ["5", "12"], now: now, calendar: calendar)
        XCTAssertEqual(queue.count, 98)
        XCTAssertEqual(Set(queue), Set(records.map(\.id)).subtracting(["5", "12"]))
    }

    func testAnniversaryUsesLocalDay() {
        var local = calendar
        local.timeZone = TimeZone(secondsFromGMT: 2 * 3600)!
        let records = [PhotoRecord(id: "local13th", date: date("2020-10-12T23:00:00Z"))]
        XCTAssertEqual(PhotoSelection.queue(records, mode: .onThisDay, reviewed: [], now: now, calendar: local), ["local13th"])
    }

    func testLeapDayMatchesOnlyLeapDay() {
        let leapNow = date("2024-02-29T12:00:00Z")
        let records = [
            PhotoRecord(id: "leap", date: date("2020-02-29T09:00:00Z")),
            PhotoRecord(id: "feb28", date: date("2020-02-28T09:00:00Z"))
        ]
        XCTAssertEqual(PhotoSelection.queue(records, mode: .onThisDay, reviewed: [], now: leapNow, calendar: calendar), ["leap"])
    }

    func testReviewUndoRestoresCurrentPhotoAndDeleteSelection() {
        var progress = ReviewProgress(ids: ["a", "b"])
        progress.choose(.delete)
        XCTAssertEqual(progress.currentID, "b")
        XCTAssertEqual(progress.deleteIDs, ["a"])
        progress.undo()
        XCTAssertEqual(progress.currentID, "a")
        XCTAssertTrue(progress.deleteIDs.isEmpty)
        progress.choose(.keep)
        progress.choose(.delete)
        XCTAssertTrue(progress.isComplete)
        XCTAssertEqual(progress.keptCount, 1)
        progress.choose(.delete)
        XCTAssertEqual(progress.decisions.count, 2)
        progress.undo()
        XCTAssertEqual(progress.currentID, "b")
        XCTAssertTrue(progress.deleteIDs.isEmpty)
    }

    func testEmptyReviewAndUndoAreSafe() {
        var progress = ReviewProgress(ids: [])
        progress.undo()
        progress.choose(.keep)
        XCTAssertTrue(progress.isComplete)
        XCTAssertTrue(progress.decisions.isEmpty)
    }
}
