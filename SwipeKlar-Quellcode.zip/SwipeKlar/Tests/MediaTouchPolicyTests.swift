import XCTest
@testable import SwipeKlarCore

final class MediaTouchPolicyTests: XCTestCase {
    private func choice(_ x: Double, width: Double = 390, zoom: Double = 1,
                        multiple: Bool = false, held: Bool = false) -> PhotoChoice? {
        MediaTouchPolicy.edgeChoice(x: x, width: width, zoomScale: zoom,
            hadMultipleTouches: multiple, wasHeld: held)
    }

    func testOnlySideAreasChooseAndCenterStaysNeutral() {
        XCTAssertEqual(choice(12), .delete)
        XCTAssertEqual(choice(378), .keep)
        XCTAssertNil(choice(195))
    }

    func testZoomedOrMultiFingerGesturesCannotChooseAtEitherEdge() {
        for x in [12.0, 378] {
            XCTAssertNil(choice(x, zoom: 2))
            XCTAssertNil(choice(x, multiple: true))
            XCTAssertNil(choice(x, held: true))
        }
    }

    func testSideAreasRemainSeparateOnNarrowAndWideScreens() {
        XCTAssertNil(choice(80, width: 150))
        XCTAssertEqual(choice(43, width: 176), .delete)
        XCTAssertEqual(choice(133, width: 176), .keep)
        XCTAssertNil(choice(500, width: 1000))
        XCTAssertEqual(choice(980, width: 1000), .keep)
    }

    func testInvalidOrOutsideCoordinatesNeverChoose() {
        for x in [-1.0, 391, .nan, .infinity] { XCTAssertNil(choice(x)) }
        for width in [0.0, -1, .nan, .infinity] { XCTAssertNil(choice(0, width: width)) }
        for zoom in [0.0, -1, .nan, .infinity] { XCTAssertNil(choice(12, zoom: zoom)) }
    }

    func testFastPlaybackEligibilityExcludesZoomAndEarlierHoldOrSecondFinger() {
        XCTAssertTrue(MediaTouchPolicy.canUseSingleTouch(zoomScale: 1, hadMultipleTouches: false, wasHeld: false))
        XCTAssertFalse(MediaTouchPolicy.canUseSingleTouch(zoomScale: 1.1, hadMultipleTouches: false, wasHeld: false))
        XCTAssertFalse(MediaTouchPolicy.canUseSingleTouch(zoomScale: 1, hadMultipleTouches: true, wasHeld: false))
        XCTAssertFalse(MediaTouchPolicy.canUseSingleTouch(zoomScale: 1, hadMultipleTouches: false, wasHeld: true))
    }
}
