import XCTest
@testable import SwipeKlarCore

final class CardSwipeSessionTests: XCTestCase {
    func testSingleFingerHorizontalSwipesAtOriginalSizeCanDecide() {
        var session = CardSwipeSession()
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertEqual(session.finish(horizontal: 120, vertical: 10, zoomScale: 1), .keep)
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertEqual(session.finish(horizontal: -120, vertical: 10, zoomScale: 1), .delete)
    }

    func testShortOrMostlyVerticalMovementDoesNotDecide() {
        var session = CardSwipeSession()
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertNil(session.finish(horizontal: -90, vertical: 0, zoomScale: 1))
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertNil(session.finish(horizontal: -120, vertical: 180, zoomScale: 1))
    }

    func testPanningAZoomedPhotoCannotBecomeASortWhenZoomReturnsToOne() {
        var session = CardSwipeSession()
        session.begin(zoomScale: 2.5, touchCount: 1, isPinching: false)
        session.update(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertNil(session.finish(horizontal: -250, vertical: 0, zoomScale: 1))
    }

    func testAddingSecondFingerDisqualifiesRestOfGesture() {
        var session = CardSwipeSession()
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        session.update(zoomScale: 1, touchCount: 2, isPinching: false)
        session.update(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertNil(session.finish(horizontal: -250, vertical: 0, zoomScale: 1))
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertEqual(session.finish(horizontal: -120, vertical: 0, zoomScale: 1), .delete)
    }

    func testPinchIsBlockedEvenBeforeItsScaleChanges() {
        var session = CardSwipeSession()
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        session.update(zoomScale: 1, touchCount: 1, isPinching: true)
        session.update(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertNil(session.finish(horizontal: -250, vertical: 0, zoomScale: 1))
        session.begin(zoomScale: 1, touchCount: 2, isPinching: true)
        XCTAssertFalse(session.isEligible)
    }

    func testInvalidCoordinatesAndScaleDoNotDecide() {
        var session = CardSwipeSession()
        for scale in [Double.nan, .infinity, 0, -1] {
            session.begin(zoomScale: scale, touchCount: 1, isPinching: false)
            XCTAssertNil(session.finish(horizontal: -250, vertical: 0, zoomScale: scale))
        }
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertNil(session.finish(horizontal: -.infinity, vertical: 0, zoomScale: 1))
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertNil(session.finish(horizontal: -250, vertical: .nan, zoomScale: 1))
    }

    func testCancelledOrFinishedSessionCannotBeReusedWithoutNewBegin() {
        var session = CardSwipeSession()
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        session.cancel()
        XCTAssertNil(session.finish(horizontal: -250, vertical: 0, zoomScale: 1))
        session.begin(zoomScale: 1, touchCount: 1, isPinching: false)
        XCTAssertEqual(session.finish(horizontal: 120, vertical: 0, zoomScale: 1), .keep)
        XCTAssertNil(session.finish(horizontal: -250, vertical: 0, zoomScale: 1))
    }
}
