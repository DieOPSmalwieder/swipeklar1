#!/bin/bash
# Build on macOS with Xcode; the unsigned IPA is signed locally by Sideloadly.
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
    printf '%s\n' 'Dieser Build benötigt macOS mit Xcode. Unter Windows übernimmt das GitHub Actions.' >&2
    exit 1
fi

swipeklar_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
swipeklar_output="$swipeklar_root/dist"
swipeklar_temp="$(mktemp -d "${RUNNER_TEMP:-${TMPDIR:-/tmp}}/swipeklar.XXXXXX")"
trap 'rm -rf "$swipeklar_temp"' EXIT
mkdir -p "$swipeklar_output"

xcodebuild \
    -project "$swipeklar_root/SwipeKlar.xcodeproj" \
    -scheme SwipeKlar \
    -configuration Release \
    -sdk iphoneos \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$swipeklar_temp/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY= \
    build 2>&1 | tee "$swipeklar_output/build.log"

swipeklar_app="$swipeklar_temp/DerivedData/Build/Products/Release-iphoneos/SwipeKlar.app"
test -f "$swipeklar_app/Info.plist"
test -f "$swipeklar_app/SwipeKlar"
xcrun lipo "$swipeklar_app/SwipeKlar" -verify_arch arm64
/usr/libexec/PlistBuddy -c 'Print :CFBundleSupportedPlatforms:0' "$swipeklar_app/Info.plist" | \
    python3 -c 'import sys; assert sys.stdin.read().strip() == "iPhoneOS", "Kein iPhone-Build"'

mkdir -p "$swipeklar_temp/Package/Payload"
ditto "$swipeklar_app" "$swipeklar_temp/Package/Payload/SwipeKlar.app"
(
    cd "$swipeklar_temp/Package"
    ditto -c -k --keepParent Payload "$swipeklar_output/SwipeKlar.ipa"
)

python3 - "$swipeklar_output/SwipeKlar.ipa" <<'PY'
import plistlib
import sys
from zipfile import ZipFile
with ZipFile(sys.argv[1]) as archive:
    assert archive.testzip() is None, "Beschädigtes IPA-Archiv"
    info = plistlib.loads(archive.read("Payload/SwipeKlar.app/Info.plist"))
    assert "iPhoneOS" in info["CFBundleSupportedPlatforms"]
    executable = "Payload/SwipeKlar.app/" + info["CFBundleExecutable"]
    assert executable in archive.namelist(), "App-Programm fehlt"
print("SwipeKlar.ipa erstellt. Zur Installation unter Windows mit Sideloadly signieren.")
PY
