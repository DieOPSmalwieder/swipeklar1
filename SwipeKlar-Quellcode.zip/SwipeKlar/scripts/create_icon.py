"""Generate the bundled app icon; only regeneration needs Pillow."""
from pathlib import Path
import json
from PIL import Image, ImageDraw

directory = Path(__file__).resolve().parents[1] / "SwipeKlar/Assets.xcassets"
icon_dir = directory / "AppIcon.appiconset"
icon_dir.mkdir(parents=True, exist_ok=True)
image = Image.new("RGB", (1024, 1024))
draw = ImageDraw.Draw(image)
for y in range(1024):
    weight = y / 1023
    first, last = (134, 80, 229), (29, 184, 177)
    draw.line((0, y, 1024, y), fill=tuple(round(a + (b - a) * weight) for a, b in zip(first, last)))
draw.rounded_rectangle((234, 212, 790, 812), radius=102, fill=(201, 227, 244))
draw.rounded_rectangle((205, 182, 760, 781), radius=102, fill=(234, 238, 254))
draw.rounded_rectangle((176, 152, 731, 751), radius=102, fill=(255, 255, 255))
draw.line([(307, 471), (415, 579), (615, 367)], fill=(70, 160, 162), width=56, joint="curve")
for x, y in [(307, 471), (415, 579), (615, 367)]:
    draw.ellipse((x-28, y-28, x+28, y+28), fill=(70, 160, 162))
image.save(icon_dir / "AppIcon.png")
(directory / "Contents.json").write_text(json.dumps({"info": {"author": "xcode", "version": 1}}, indent=2))
(icon_dir / "Contents.json").write_text(json.dumps({
    "images": [{"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"}],
    "info": {"author": "xcode", "version": 1}
}, indent=2))
print("App icon generated")
