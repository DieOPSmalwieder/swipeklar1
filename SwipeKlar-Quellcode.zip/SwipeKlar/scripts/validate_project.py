"""Structural checks. Extra check dependencies: tree-sitter, tree-sitter-swift, pbxproj, Pillow."""
from pathlib import Path
import json
import plistlib
import re
import xml.etree.ElementTree as ET
from PIL import Image
from pbxproj import XcodeProject
from tree_sitter import Language, Parser
import tree_sitter_swift

root = Path(__file__).resolve().parents[1]
parser = Parser(Language(tree_sitter_swift.language()))
swift_files = sorted(root.rglob("*.swift"))
for path in swift_files:
    tree = parser.parse(path.read_bytes())
    assert not tree.root_node.has_error, f"Swift syntax error: {path}"
print(f"PASS: Swift grammar for {len(swift_files)} files")

project_path = root / "SwipeKlar.xcodeproj/project.pbxproj"
project = XcodeProject.load(str(project_path))
assert project is not None, "Cannot parse Xcode project"
content = project_path.read_text()
definitions = set(re.findall(r"^\s*([0-9A-F]{24}) /\* .*? \*/ = \{", content, re.M))
references = set(re.findall(r"\b[0-9A-F]{24}\b", content))
assert definitions == references, "Dangling Xcode object reference"

file_refs = project.objects.get_objects_in_section("PBXFileReference")
for file in file_refs:
    if file.sourceTree == "<group>":
        assert (root / "SwipeKlar" / file.path).exists(), f"Missing build input: {file.path}"
build_files = project.objects.get_objects_in_section("PBXBuildFile")
assert len(build_files) == 13
for phase_name, count in [("PBXSourcesBuildPhase", 11), ("PBXResourcesBuildPhase", 2)]:
    phases = project.objects.get_objects_in_section(phase_name)
    assert len(phases) == 1 and len(phases[0].files) == count
print("PASS: Xcode project parses; references and all build inputs exist")

scheme = ET.parse(root / "SwipeKlar.xcodeproj/xcshareddata/xcschemes/SwipeKlar.xcscheme")
for node in scheme.findall(".//BuildableReference"):
    assert node.attrib["BlueprintIdentifier"] in definitions
    assert node.attrib["ReferencedContainer"] == "container:SwipeKlar.xcodeproj"
print("PASS: Shared Xcode scheme")

privacy = plistlib.loads((root / "SwipeKlar/PrivacyInfo.xcprivacy").read_bytes())
assert privacy["NSPrivacyTracking"] is False
assert privacy["NSPrivacyCollectedDataTypes"] == []
assert privacy["NSPrivacyAccessedAPITypes"][0]["NSPrivacyAccessedAPITypeReasons"] == ["CA92.1"]
print("PASS: Privacy manifest")

catalog = root / "SwipeKlar/Assets.xcassets"
json.loads((catalog / "Contents.json").read_text())
icon = json.loads((catalog / "AppIcon.appiconset/Contents.json").read_text())
image = Image.open(catalog / "AppIcon.appiconset" / icon["images"][0]["filename"])
assert image.size == (1024, 1024) and image.mode == "RGB"
print("PASS: App icon metadata, dimensions and opaque RGB format")
