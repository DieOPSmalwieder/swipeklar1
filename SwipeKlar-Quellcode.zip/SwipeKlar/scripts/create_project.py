"""Generate a dependency-free Xcode project. Run from any directory with Python 3."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "SwipeKlar.xcodeproj"
PROJECT.mkdir(exist_ok=True)

def ident(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()

def quote(value):
    return json.dumps(value, ensure_ascii=False)

objects = []
def add(name, isa, body):
    key = ident(name)
    objects.append(f"\t\t{key} /* {name} */ = {{\n\t\t\tisa = {isa};\n{body}\n\t\t}};")
    return key

def refs(names):
    return "(\n" + "".join(f"\t\t\t\t{ident(name)} /* {name} */,\n" for name in names) + "\t\t\t)"

sources = ["SwipeKlarApp.swift", "HomeView.swift", "ReviewView.swift", "PhotoLibrary.swift",
           "MediaViewer.swift", "ZoomableMedia.swift", "DeleteReviewView.swift", "DeletionPreviewView.swift",
           "Core/PhotoSelection.swift", "Core/PlaybackTime.swift",
           "Core/CardSwipeSession.swift"]
resources = ["Assets.xcassets", "PrivacyInfo.xcprivacy"]
for path in sources + resources:
    kind = "sourcecode.swift" if path.endswith(".swift") else ("folder.assetcatalog" if path.endswith("xcassets") else "text.xml")
    add(path, "PBXFileReference", f'\t\t\tlastKnownFileType = {kind};\n\t\t\tpath = {quote(path)};\n\t\t\tsourceTree = "<group>";')
    add(path + " in Build", "PBXBuildFile", f"\t\t\tfileRef = {ident(path)};")

add("SwipeKlar.app", "PBXFileReference", '\t\t\texplicitFileType = wrapper.application;\n\t\t\tincludeInIndex = 0;\n\t\t\tpath = SwipeKlar.app;\n\t\t\tsourceTree = BUILT_PRODUCTS_DIR;')
add("App Group", "PBXGroup", f'\t\t\tchildren = {refs(sources + resources)};\n\t\t\tpath = SwipeKlar;\n\t\t\tsourceTree = "<group>";')
add("Products", "PBXGroup", f'\t\t\tchildren = {refs(["SwipeKlar.app"])};\n\t\t\tname = Products;\n\t\t\tsourceTree = "<group>";')
add("Main Group", "PBXGroup", f'\t\t\tchildren = {refs(["App Group", "Products"])};\n\t\t\tsourceTree = "<group>";')
for name, isa, files in [("Sources", "PBXSourcesBuildPhase", sources), ("Resources", "PBXResourcesBuildPhase", resources), ("Frameworks", "PBXFrameworksBuildPhase", [])]:
    add(name, isa, f'\t\t\tbuildActionMask = 2147483647;\n\t\t\tfiles = {refs([p + " in Build" for p in files])};\n\t\t\trunOnlyForDeploymentPostprocessing = 0;')

for scope in ["Project", "Target"]:
    for config in ["Debug", "Release"]:
        settings = {
            "CLANG_ENABLE_MODULES": "YES", "CLANG_ENABLE_OBJC_ARC": "YES",
            "IPHONEOS_DEPLOYMENT_TARGET": "17.0", "SDKROOT": "iphoneos",
            "SWIFT_VERSION": "5.0",
        }
        if scope == "Project":
            settings.update({"DEBUG_INFORMATION_FORMAT": "dwarf" if config == "Debug" else "dwarf-with-dsym", "SWIFT_OPTIMIZATION_LEVEL": "-Onone" if config == "Debug" else "-O"})
            if config == "Debug":
                settings["SWIFT_ACTIVE_COMPILATION_CONDITIONS"] = "DEBUG $(inherited)"
                settings["ENABLE_TESTABILITY"] = "YES"
            else:
                settings["SWIFT_COMPILATION_MODE"] = "wholemodule"
        else:
            settings.update({
                "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon",
                "CODE_SIGN_STYLE": "Automatic", "DEVELOPMENT_TEAM": "",
                "CURRENT_PROJECT_VERSION": "4", "MARKETING_VERSION": "1.3",
                "GENERATE_INFOPLIST_FILE": "YES", "INFOPLIST_KEY_CFBundleDisplayName": "SwipeKlar",
                "INFOPLIST_KEY_NSPhotoLibraryUsageDescription": "SwipeKlar zeigt deine Fotos und Videos zum Durchsehen an und löscht nur die von dir bestätigte Auswahl.",
                "INFOPLIST_KEY_UIApplicationSceneManifest_Generation": "YES",
                "INFOPLIST_KEY_UILaunchScreen_Generation": "YES",
                "INFOPLIST_KEY_UISupportedInterfaceOrientations": "UIInterfaceOrientationPortrait",
                "LD_RUNPATH_SEARCH_PATHS": "$(inherited) @executable_path/Frameworks",
                "PRODUCT_BUNDLE_IDENTIFIER": "de.swipeklar.personal",
                "PRODUCT_NAME": "$(TARGET_NAME)", "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator",
                "SUPPORTS_MACCATALYST": "NO", "SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD": "NO",
                "TARGETED_DEVICE_FAMILY": "1",
            })
        body = "\t\t\tbuildSettings = {\n" + "".join(f"\t\t\t\t{k} = {quote(v)};\n" for k, v in sorted(settings.items())) + f"\t\t\t}};\n\t\t\tname = {config};"
        add(scope + " " + config, "XCBuildConfiguration", body)
    add(scope + " Configuration List", "XCConfigurationList", f'\t\t\tbuildConfigurations = {refs([scope + " Debug", scope + " Release"])};\n\t\t\tdefaultConfigurationIsVisible = 0;\n\t\t\tdefaultConfigurationName = Release;')

add("SwipeKlar Target", "PBXNativeTarget", f'\t\t\tbuildConfigurationList = {ident("Target Configuration List")};\n\t\t\tbuildPhases = {refs(["Sources", "Frameworks", "Resources"])};\n\t\t\tbuildRules = ();\n\t\t\tdependencies = ();\n\t\t\tname = SwipeKlar;\n\t\t\tproductName = SwipeKlar;\n\t\t\tproductReference = {ident("SwipeKlar.app")};\n\t\t\tproductType = "com.apple.product-type.application";')
add("SwipeKlar Project", "PBXProject", f'\t\t\tattributes = {{ LastUpgradeCheck = 1500; TargetAttributes = {{ {ident("SwipeKlar Target")} = {{ CreatedOnToolsVersion = 15.0; ProvisioningStyle = Automatic; }}; }}; }};\n\t\t\tbuildConfigurationList = {ident("Project Configuration List")};\n\t\t\tcompatibilityVersion = "Xcode 14.0";\n\t\t\tdevelopmentRegion = de;\n\t\t\thasScannedForEncodings = 0;\n\t\t\tknownRegions = (de, en, Base);\n\t\t\tmainGroup = {ident("Main Group")};\n\t\t\tproductRefGroup = {ident("Products")};\n\t\t\tprojectDirPath = "";\n\t\t\tprojectRoot = "";\n\t\t\ttargets = {refs(["SwipeKlar Target"])};')
content = '// !$*UTF8*$!\n{\n\tarchiveVersion = 1;\n\tclasses = {};\n\tobjectVersion = 56;\n\tobjects = {\n' + "\n".join(objects) + f'\n\t}};\n\trootObject = {ident("SwipeKlar Project")};\n}}\n'
(PROJECT / "project.pbxproj").write_text(content)

scheme_dir = PROJECT / "xcshareddata" / "xcschemes"
scheme_dir.mkdir(parents=True, exist_ok=True)
reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ident("SwipeKlar Target")}" BuildableName="SwipeKlar.app" BlueprintName="SwipeKlar" ReferencedContainer="container:SwipeKlar.xcodeproj"/>'
(scheme_dir / "SwipeKlar.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1500" version="1.3">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES">
    <BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{reference}</BuildActionEntry></BuildActionEntries>
  </BuildAction>
  <TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.DebuggerFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables/></TestAction>
  <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.DebuggerFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></LaunchAction>
  <ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></ProfileAction>
  <AnalyzeAction buildConfiguration="Debug"/>
  <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''')
print("Xcode project generated:", PROJECT)
