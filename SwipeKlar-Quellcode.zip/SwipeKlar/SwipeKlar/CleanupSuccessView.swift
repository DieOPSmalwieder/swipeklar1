import SwiftUI
import UIKit

struct CleanupSuccessView: View {
    let summary: CleanupSummary
    let onDone: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var ringProgress: CGFloat = 0
    @State private var checkProgress: CGFloat = 0
    @State private var appeared = false

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 24) {
                    animatedCheckmark.padding(.top, 32)
                    Text("Geschafft!").font(.largeTitle.bold())
                    storageResult
                    Text("\(summary.reviewedCount) durchgesehen · \(summary.deletedCount) entfernt")
                        .font(.subheadline).foregroundStyle(MediaStyle.secondary)
                    explanation
                }
                .frame(maxWidth: .infinity).padding(.horizontal, 24).padding(.bottom, 24)
            }
            Button(action: onDone) {
                Text("Zur Übersicht").fontWeight(.semibold)
                    .frame(maxWidth: .infinity).padding(.vertical, 8)
            }
            .buttonStyle(.borderedProminent).tint(.blue)
            .padding(.horizontal, 24).padding(.vertical, 16)
        }
        .task { await animateSuccess() }
    }

    private var animatedCheckmark: some View {
        ZStack {
            Circle().fill(Color.green.opacity(0.12))
            Circle().trim(from: 0, to: ringProgress)
                .stroke(Color.green.opacity(0.55), style: StrokeStyle(lineWidth: 3, lineCap: .round))
                .rotationEffect(.degrees(-90))
            CleanupCheckmark().trim(from: 0, to: checkProgress)
                .stroke(Color.green, style: StrokeStyle(lineWidth: 6, lineCap: .round, lineJoin: .round))
                .frame(width: 48, height: 36)
        }
        .frame(width: 112, height: 112)
        .scaleEffect(reduceMotion || appeared ? 1 : 0.82)
        .accessibilityHidden(true)
    }

    private var storageResult: some View {
        VStack(spacing: 8) {
            Text(storageLabel)
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .minimumScaleFactor(0.6).lineLimit(1)
            Text(summary.deletedCount == 0 ? "Alle Aufnahmen behalten" : "an Medien aussortiert")
                .font(.headline).foregroundStyle(MediaStyle.secondary)
        }.accessibilityElement(children: .combine)
    }

    @ViewBuilder private var explanation: some View {
        if summary.deletedCount > 0 {
            Text("iOS behält die Aufnahmen zunächst in „Zuletzt gelöscht“. Speicher wird gegebenenfalls erst nach der endgültigen Entfernung frei. Die angezeigte Mediengröße kann vom freien Gerätespeicher abweichen.")
                .font(.footnote).foregroundStyle(MediaStyle.secondary)
                .multilineTextAlignment(.center)
        } else {
            Text("Deine Entscheidungen sind gespeichert. Es wurde nichts gelöscht.")
                .font(.footnote).foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
        }
    }

    private var storageLabel: String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowedUnits = [.useMB, .useGB]
        formatter.allowsNonnumericFormatting = false
        let size = formatter.string(fromByteCount: summary.bytes)
        return summary.isEstimated && summary.deletedCount > 0 ? "Ca. " + size : size
    }

    @MainActor private func animateSuccess() async {
        guard !appeared else { return }
        do { try await Task.sleep(nanoseconds: 250_000_000) } catch { return }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        if reduceMotion {
            appeared = true
            ringProgress = 1
            checkProgress = 1
        } else {
            withAnimation(.spring(response: 0.45, dampingFraction: 0.75)) { appeared = true }
            withAnimation(.easeOut(duration: 0.4)) { ringProgress = 1 }
            withAnimation(.easeOut(duration: 0.3).delay(0.18)) { checkProgress = 1 }
        }
    }
}

private struct CleanupCheckmark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.minX + rect.width * 0.36, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        return path
    }
}
