import SwiftUI

@main
struct SwipeKlarApp: App {
    @StateObject private var library = PhotoLibrary()
    var body: some Scene {
        WindowGroup {
            HomeView().environmentObject(library)
                .preferredColorScheme(.light)
        }
    }
}
