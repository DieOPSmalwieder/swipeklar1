import Photos
import SwiftUI
import UIKit

struct DeleteReviewView: View {
    let decisions: [PhotoDecision]
    let onFinished: () -> Void
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var selected: Set<String>
    @State private var preview: DeletionPreviewItem?
    @State private var isSaving = false
    @State private var error: String?
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 4), count: 3)
    private var candidates: [String] { decisions.filter { $0.choice == .delete }.map(\.id) }

    init(decisions: [PhotoDecision], onFinished: @escaping () -> Void) {
        self.decisions = decisions
        self.onFinished = onFinished
        _selected = State(initialValue: Set(decisions.filter { $0.choice == .delete }.map(\.id)))
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    instructions.padding(.horizontal, 16)
                    thumbnailGrid
                }.padding(.top, 16).padding(.bottom, 12)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .safeAreaInset(edge: .bottom, spacing: 0) { confirmationBar }
            .navigationTitle("Auswahl prüfen").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Zurück") { dismiss() }.disabled(isSaving)
                }
            }
            .fullScreenCover(item: $preview) { item in
                DeletionPreviewView(asset: item.asset, isSelected: selectionBinding(for: item.id))
            }
            .alert("Nicht abgeschlossen", isPresented: errorPresented) {
                Button("OK", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }
        .tint(.blue).interactiveDismissDisabled(isSaving)
        .presentationDetents([.large]).presentationDragIndicator(.visible)
        .presentationCornerRadius(28)
    }

    private var instructions: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("\(selected.count) von \(candidates.count) zum Löschen ausgewählt")
                .font(.headline).accessibilityAddTraits(.updatesFrequently)
            Text("Tippen ändert die Auswahl. Gedrückt halten öffnet die große Vorschau – mit Zoom und Videowiedergabe.")
                .font(.subheadline).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var thumbnailGrid: some View {
        LazyVGrid(columns: columns, spacing: 4) {
            ForEach(candidates, id: \.self) { id in
                DeletionThumbnail(asset: library.asset(for: id), isSelected: selected.contains(id),
                    onToggle: { toggleSelection(id) }, onPreview: { openPreview(id) })
                    .disabled(isSaving)
            }
        }.padding(.horizontal, 4)
    }

    private var confirmationBar: some View {
        VStack(spacing: 12) {
            Text("iOS fragt vor dem Löschen erneut nach. Aufnahmen landen in „Zuletzt gelöscht“. Mit iCloud-Fotos gilt die Löschung auf allen verbundenen Geräten.")
                .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button(action: save) {
                HStack(spacing: 10) {
                    if isSaving { ProgressView().tint(.white) }
                    if !isSaving { Image(systemName: selected.isEmpty ? "checkmark" : "trash") }
                    Text(selected.isEmpty ? "Alle behalten und abschließen" : "\(selected.count) Aufnahmen löschen")
                        .fontWeight(.semibold)
                }.frame(maxWidth: .infinity).padding(.vertical, 8)
            }
            .buttonStyle(.borderedProminent).tint(selected.isEmpty ? .blue : .red)
            .disabled(isSaving)
        }
        .padding(16).background(.regularMaterial)
    }

    private var errorPresented: Binding<Bool> {
        Binding(get: { error != nil }, set: { if !$0 { error = nil } })
    }

    private func selectionBinding(for id: String) -> Binding<Bool> {
        Binding(get: { selected.contains(id) }, set: { value in
            guard !isSaving, candidates.contains(id) else { return }
            if value { selected.insert(id) } else { selected.remove(id) }
        })
    }

    private func toggleSelection(_ id: String) {
        guard !isSaving else { return }
        if selected.contains(id) { selected.remove(id) } else { selected.insert(id) }
        UISelectionFeedbackGenerator().selectionChanged()
    }

    private func openPreview(_ id: String) {
        guard !isSaving, let asset = library.asset(for: id) else { return }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        // Opening the preview does not change the deletion selection.
        preview = DeletionPreviewItem(asset: asset)
    }

    private func save() {
        guard !isSaving, preview == nil else { return }
        isSaving = true
        Task {
            do {
                try await library.finish(decisions, deleting: selected)
                onFinished()
            } catch {
                self.error = "Die Löschung wurde nicht abgeschlossen. Deine Auswahl bleibt erhalten.\n\n" + error.localizedDescription
            }
            isSaving = false
        }
    }
}

private struct DeletionThumbnail: View {
    let asset: PHAsset?
    let isSelected: Bool
    let onToggle: () -> Void
    let onPreview: () -> Void

    var body: some View {
        thumbnail
            .aspectRatio(1, contentMode: .fit)
            .contentShape(RoundedRectangle(cornerRadius: 8))
            .gesture(previewOrToggle)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(accessibilityText)
            .accessibilityValue(isSelected ? "Zum Löschen ausgewählt" : "Wird behalten")
            .accessibilityHint("Antippen ändert die Auswahl. Gedrückt halten zeigt die große Vorschau.")
            .accessibilityAddTraits(.isButton)
            .accessibilityAction { onToggle() }
            .accessibilityAction(named: Text("Groß ansehen")) { onPreview() }
    }

    private var thumbnail: some View {
        GeometryReader { geometry in
            AssetPhoto(asset: asset, thumbnail: true)
                .frame(width: geometry.size.width, height: geometry.size.height)
                .background(Color.black)
                .overlay(alignment: .bottomTrailing) { selectionIndicator }
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay {
                    RoundedRectangle(cornerRadius: 8)
                        .strokeBorder(isSelected ? Color.blue : Color.clear, lineWidth: 3)
                }
        }
    }

    private var selectionIndicator: some View {
        Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
            .font(.system(size: 25, weight: .medium))
            .symbolRenderingMode(.palette)
            .foregroundStyle(.white, isSelected ? Color.blue : Color.black.opacity(0.45))
            .background(Color.black.opacity(0.35), in: Circle())
            .padding(8).accessibilityHidden(true)
    }

    private var previewOrToggle: some Gesture {
        // Only one branch can complete. Releasing a long press cannot also toggle selection.
        LongPressGesture(minimumDuration: 0.4, maximumDistance: 12)
            .exclusively(before: TapGesture())
            .onEnded { result in
                switch result {
                case .first(true): onPreview()
                case .second: onToggle()
                default: break
                }
            }
    }

    private var accessibilityText: String {
        let kind = asset?.mediaType == .video ? "Video" : "Foto"
        guard let date = asset?.creationDate else { return kind + ", Aufnahmedatum unbekannt" }
        return kind + ", " + date.formatted(date: .long, time: .shortened)
    }
}
