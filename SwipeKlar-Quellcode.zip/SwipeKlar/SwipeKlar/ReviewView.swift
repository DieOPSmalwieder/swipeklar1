import Photos
import SwiftUI
import UIKit

struct ReviewView: View {
    let mode: ReviewMode
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var progress: ReviewProgress
    @State private var drag = CGSize.zero
    @State private var showReview = false
    @State private var showLeave = false
    @State private var saved = false
    @State private var isSaving = false
    @State private var error: String?
    @State private var preview: MediaPreviewItem?
    private let background = MediaStyle.background

    init(mode: ReviewMode, ids: [String]) {
        self.mode = mode
        _progress = State(initialValue: ReviewProgress(ids: ids))
    }

    var body: some View {
        VStack(spacing: 18) {
            if progress.ids.isEmpty {
                emptyState
            } else if saved {
                Spacer()
                Image(systemName: "checkmark.circle.fill").font(.system(size: 64)).foregroundStyle(.mint)
                Text("Alles erledigt.").font(.largeTitle.bold())
                Text("Deine Auswahl wurde gespeichert.").foregroundStyle(MediaStyle.secondary)
                Button("Zur Übersicht") { dismiss() }.buttonStyle(.borderedProminent).tint(.mint)
                Spacer()
            } else {
                HStack {
                    Text("\(progress.decisions.count) von \(progress.ids.count)").monospacedDigit()
                    Spacer()
                    Label("\(progress.deleteIDs.count)", systemImage: "trash").foregroundStyle(.pink)
                }.font(.subheadline).foregroundStyle(.white)
                ProgressView(value: Double(progress.decisions.count), total: Double(max(1, progress.ids.count)))
                    .tint(.mint)

                if let id = progress.currentID {
                    photoCard(id: id)
                    HStack(spacing: 26) {
                        actionButton("Löschen vormerken", symbol: "xmark", color: .pink) { choose(.delete) }
                        Button {
                            progress.undo()
                            drag = .zero
                        } label: {
                            Image(systemName: "arrow.uturn.backward").font(.title2)
                                .frame(width: 48, height: 48)
                        }.tint(.white).disabled(progress.decisions.isEmpty)
                            .accessibilityLabel("Letzte Entscheidung zurücknehmen")
                        actionButton("Behalten", symbol: "heart.fill", color: .mint) { choose(.keep) }
                    }
                    Text("← Löschen vormerken     Behalten →")
                        .font(.caption).foregroundStyle(MediaStyle.secondary)
                } else {
                    Spacer()
                    Image(systemName: "checkmark.seal").font(.system(size: 64)).foregroundStyle(.mint)
                    Text("Gut durchgewischt.").font(.title.bold())
                    Text("\(progress.keptCount) behalten · \(progress.deleteIDs.count) vorgemerkt")
                        .foregroundStyle(MediaStyle.secondary)
                    Text("Gelöscht wird erst nach deiner Bestätigung.")
                        .font(.footnote).foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
                    Button(progress.deleteIDs.isEmpty ? "Abschließen" : "Auswahl prüfen") { finish() }
                        .buttonStyle(.borderedProminent).tint(.mint).foregroundStyle(.black)
                        .disabled(isSaving)
                    Button("Letzte Entscheidung zurücknehmen") { progress.undo() }
                        .font(.footnote).tint(.white).disabled(isSaving)
                    Spacer()
                }
            }
        }
        .padding(20).frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(background.ignoresSafeArea()).foregroundStyle(.white)
        .environment(\.colorScheme, .dark).preferredColorScheme(.dark)
        .navigationTitle(mode.title).navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .navigationBarBackButtonHidden(true)
        .toolbar(.visible, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    if !saved && !progress.decisions.isEmpty { showLeave = true } else { dismiss() }
                } label: { Image(systemName: "chevron.left") }
                    .accessibilityLabel("Zur Übersicht").disabled(isSaving)
            }
            ToolbarItem(placement: .topBarTrailing) {
                if !saved && !progress.decisions.isEmpty && !progress.isComplete {
                    Button("Fertig") { finish() }.disabled(isSaving)
                }
            }
        }.tint(.white)
        .confirmationDialog("Auswahl verwerfen? Es wird nichts gelöscht.", isPresented: $showLeave, titleVisibility: .visible) {
            Button("Auswahl verwerfen und zurück", role: .destructive) { dismiss() }
            Button("Weiter durchsehen", role: .cancel) {}
        }
        .sheet(isPresented: $showReview) {
            DeleteReviewView(decisions: progress.decisions) {
                showReview = false
                saved = true
            }.environmentObject(library)
        }
        .fullScreenCover(item: $preview) { item in
            MediaViewer(asset: item.asset).id(item.id)
        }
        .alert("Abschließen nicht möglich", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("OK", role: .cancel) { error = nil }
        } message: { Text(error ?? "Bitte versuche es erneut.") }
    }

    private func photoCard(id: String) -> some View {
        let asset = library.asset(for: id)
        return VStack(spacing: 0) {
            GeometryReader { geometry in
                ZStack(alignment: .top) {
                    AssetPhoto(asset: asset)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                    if asset?.mediaType == .video, abs(drag.width) <= 25 {
                        VStack(spacing: 10) {
                            Image(systemName: "play.circle.fill")
                                .font(.system(size: 64)).foregroundStyle(.white)
                            Text("Video abspielen").font(.headline).foregroundStyle(.white)
                        }.padding(18).background(Color.black.opacity(0.8), in: RoundedRectangle(cornerRadius: 20))
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .accessibilityHidden(true)
                    }
                    if abs(drag.width) > 25 {
                        Text(drag.width > 0 ? "BEHALTEN" : "LÖSCHEN")
                            .font(.title2.bold()).foregroundStyle(drag.width > 0 ? Color.mint : Color.pink)
                            .padding(12).background(Color.black, in: Capsule()).padding(.top, 24)
                    }
                }
                .offset(x: drag.width, y: drag.height * 0.12)
                .rotationEffect(.degrees(Double(drag.width / 24)))
                .contentShape(Rectangle())
                .clipped()
                .gesture(DragGesture(minimumDistance: 15)
                    .onChanged { drag = $0.translation }
                    .onEnded { value in
                        if abs(value.translation.width) > 90 {
                            choose(value.translation.width > 0 ? .keep : .delete)
                        } else { withAnimation(.spring(response: 0.3)) { drag = .zero } }
                    })
            }
            VStack(alignment: .leading, spacing: 10) {
                MediaMetadataView(asset: asset)
                Label(asset?.mediaType == .video ? "Tippen zum Abspielen und Zoomen" : "Tippen zum Vergrößern",
                      systemImage: "arrow.up.left.and.arrow.down.right")
                    .font(.caption.weight(.medium)).foregroundStyle(MediaStyle.secondary)
            }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(MediaStyle.panel)
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .contentShape(Rectangle())
        .onTapGesture { if let asset { preview = MediaPreviewItem(asset: asset) } }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel((asset?.mediaType == .video ? "Video" : "Foto")
            + (asset?.creationDate.map { ", " + $0.formatted(date: .long, time: .shortened) } ?? ", Aufnahmedatum unbekannt"))
        .accessibilityHint("Öffnet die Detailansicht zum Zoomen und gegebenenfalls Abspielen.")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { if let asset { preview = MediaPreviewItem(asset: asset) } }
        .accessibilityAction(named: Text("Behalten")) { choose(.keep) }
        .accessibilityAction(named: Text("Löschen vormerken")) { choose(.delete) }
    }

    private func actionButton(_ title: String, symbol: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 26, weight: .bold))
                .foregroundStyle(color).frame(width: 70, height: 70)
                .background(color.opacity(0.14), in: Circle())
                .overlay(Circle().stroke(color.opacity(0.35), lineWidth: 1))
        }.buttonStyle(.plain).accessibilityLabel(title)
    }

    private var emptyState: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: mode.symbol).font(.system(size: 56)).foregroundStyle(.mint)
            Text("Hier ist gerade alles klar.").font(.title2.bold()).multilineTextAlignment(.center)
            Text(PhotoSelection.matching(library.records, mode: mode).isEmpty
                 ? "Für diesen Modus sind keine Fotos oder Videos verfügbar. Bei eingeschränktem Zugriff kannst du auf der Startseite weitere Aufnahmen freigeben."
                 : "Du hast die verfügbaren Aufnahmen bereits durchgesehen.")
                .foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
            if !PhotoSelection.matching(library.records, mode: mode).isEmpty {
                Button("Erneut durchsehen") {
                    library.restart(mode)
                    progress = ReviewProgress(ids: library.queue(for: mode))
                }.buttonStyle(.borderedProminent).tint(.mint).foregroundStyle(.black)
            }
            Button("Zur Übersicht") { dismiss() }.tint(.white)
            Spacer()
        }
    }

    private func choose(_ choice: PhotoChoice) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        progress.choose(choice)
        drag = .zero
    }

    private func finish() {
        if !progress.deleteIDs.isEmpty { showReview = true; return }
        isSaving = true
        Task {
            do {
                try await library.finish(progress.decisions, deleting: [])
                saved = true
            } catch { self.error = error.localizedDescription }
            isSaving = false
        }
    }
}

struct DeleteReviewView: View {
    let decisions: [PhotoDecision]
    let onFinished: () -> Void
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var selected: Set<String>
    @State private var isSaving = false
    @State private var error: String?
    private var candidates: [String] { decisions.filter { $0.choice == .delete }.map(\.id) }

    init(decisions: [PhotoDecision], onFinished: @escaping () -> Void) {
        self.decisions = decisions
        self.onFinished = onFinished
        _selected = State(initialValue: Set(decisions.filter { $0.choice == .delete }.map(\.id)))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Tippe auf eine Aufnahme, um sie doch zu behalten.")
                    .font(.subheadline).foregroundStyle(MediaStyle.secondary).padding(.top, 10)
                ScrollView {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 3), spacing: 8) {
                        ForEach(candidates, id: \.self) { id in
                            Button {
                                if selected.contains(id) { selected.remove(id) } else { selected.insert(id) }
                            } label: {
                                GeometryReader { geometry in
                                    AssetPhoto(asset: library.asset(for: id), thumbnail: true)
                                        .frame(width: geometry.size.width, height: geometry.size.height)
                                        .overlay(alignment: .bottomTrailing) {
                                            Image(systemName: selected.contains(id) ? "checkmark.circle.fill" : "heart.circle.fill")
                                                .font(.title2).foregroundStyle(selected.contains(id) ? Color.pink : Color.mint)
                                                .background(.black, in: Circle()).padding(6)
                                        }.clipShape(RoundedRectangle(cornerRadius: 10))
                                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(selected.contains(id) ? Color.pink : Color.clear, lineWidth: 2))
                                }.aspectRatio(1, contentMode: .fit)
                            }.buttonStyle(.plain).disabled(isSaving)
                                .accessibilityLabel(selected.contains(id) ? "Zum Löschen ausgewählt. Tippen zum Behalten." : "Wird behalten. Tippen zum Löschen.")
                        }
                    }.padding(2)
                }
                Text("iOS fragt vor dem Löschen nochmals nach. Gelöschte Fotos und Videos landen in „Zuletzt gelöscht“ in der Fotos-App. Bei iCloud-Fotos gilt die Löschung auch auf deinen anderen Geräten.")
                    .font(.caption).foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
                Button {
                    isSaving = true
                    Task {
                        do {
                            try await library.finish(decisions, deleting: selected)
                            onFinished()
                        } catch {
                            self.error = "Die Löschung wurde nicht abgeschlossen. Deine Auswahl bleibt erhalten.\n\n" + error.localizedDescription
                        }
                        isSaving = false
                    }
                } label: {
                    HStack {
                        if isSaving { ProgressView().tint(.white) }
                        Text(selected.isEmpty ? "Alle behalten und abschließen" : "\(selected.count) Aufnahmen löschen")
                            .fontWeight(.semibold)
                    }.frame(maxWidth: .infinity).padding(.vertical, 8)
                }.buttonStyle(.borderedProminent).tint(selected.isEmpty ? .mint : .pink)
                    .foregroundStyle(.black).disabled(isSaving)
            }
            .padding(.horizontal, 16).padding(.bottom, 16)
            .navigationTitle("Auswahl prüfen").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Zurück") { dismiss() }.disabled(isSaving)
                }
            }
            .alert("Nicht abgeschlossen", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("OK", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }.foregroundStyle(.white).environment(\.colorScheme, .dark)
            .preferredColorScheme(.dark).interactiveDismissDisabled(isSaving)
    }
}
