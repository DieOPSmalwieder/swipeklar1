import AVFAudio
import Photos
import SwiftUI
import UIKit

struct ReviewView: View {
    let mode: ReviewMode
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var progress: ReviewProgress
    @State private var showReview = false
    @State private var showLeave = false
    @State private var saved = false
    @State private var isSaving = false
    @State private var error: String?
    private let background = MediaStyle.background

    init(mode: ReviewMode, ids: [String]) {
        self.mode = mode
        _progress = State(initialValue: ReviewProgress(ids: ids))
    }

    var body: some View {
        VStack(spacing: 18) {
            if progress.ids.isEmpty {
                emptyState
            } else if saved {
                Spacer()
                Image(systemName: "checkmark.circle.fill").font(.system(size: 64)).foregroundStyle(.mint)
                Text("Alles erledigt.").font(.largeTitle.bold())
                Text("Deine Auswahl wurde gespeichert.").foregroundStyle(MediaStyle.secondary)
                Button("Zur Übersicht") { dismiss() }.buttonStyle(.borderedProminent).tint(.mint)
                Spacer()
            } else {
                HStack {
                    Text("\(progress.decisions.count) von \(progress.ids.count)").monospacedDigit()
                    Spacer()
                    Label("\(progress.deleteIDs.count)", systemImage: "trash").foregroundStyle(.pink)
                }.font(.subheadline).foregroundStyle(.white)
                ProgressView(value: Double(progress.decisions.count), total: Double(max(1, progress.ids.count)))
                    .tint(.mint)

                if let id = progress.currentID {
                    photoCard(id: id)
                    HStack(spacing: 26) {
                        actionButton("Löschen vormerken", symbol: "xmark", color: .pink) { choose(.delete) }
                        Button {
                            progress.undo()
                        } label: {
                            Image(systemName: "arrow.uturn.backward").font(.title2)
                                .frame(width: 48, height: 48)
                        }.tint(.white).disabled(progress.decisions.isEmpty)
                            .accessibilityLabel("Letzte Entscheidung zurücknehmen")
                        actionButton("Behalten", symbol: "heart.fill", color: .mint) { choose(.keep) }
                    }
                    Text("Bei 1× wischen: ← Vormerken · Behalten →")
                        .font(.caption).foregroundStyle(MediaStyle.secondary)
                } else {
                    Spacer()
                    Image(systemName: "checkmark.seal").font(.system(size: 64)).foregroundStyle(.mint)
                    Text("Gut durchgewischt.").font(.title.bold())
                    Text("\(progress.keptCount) behalten · \(progress.deleteIDs.count) vorgemerkt")
                        .foregroundStyle(MediaStyle.secondary)
                    Text("Gelöscht wird erst nach deiner Bestätigung.")
                        .font(.footnote).foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
                    Button(progress.deleteIDs.isEmpty ? "Abschließen" : "Auswahl prüfen") { finish() }
                        .buttonStyle(.borderedProminent).tint(.mint).foregroundStyle(.black)
                        .disabled(isSaving)
                    Button("Letzte Entscheidung zurücknehmen") { progress.undo() }
                        .font(.footnote).tint(.white).disabled(isSaving)
                    Spacer()
                }
            }
        }
        .padding(20).frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(background.ignoresSafeArea()).foregroundStyle(.white)
        .environment(\.colorScheme, .dark).preferredColorScheme(.dark)
        .navigationTitle(mode.title).navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(background, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .navigationBarBackButtonHidden(true)
        .toolbar(.visible, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    if !saved && !progress.decisions.isEmpty { showLeave = true } else { dismiss() }
                } label: { Image(systemName: "chevron.left") }
                    .accessibilityLabel("Zur Übersicht").disabled(isSaving)
            }
            ToolbarItem(placement: .topBarTrailing) {
                if !saved && !progress.decisions.isEmpty && !progress.isComplete {
                    Button("Fertig") { finish() }.disabled(isSaving)
                }
            }
        }.tint(.white)
        .confirmationDialog("Auswahl verwerfen? Es wird nichts gelöscht.", isPresented: $showLeave, titleVisibility: .visible) {
            Button("Auswahl verwerfen und zurück", role: .destructive) { dismiss() }
            Button("Weiter durchsehen", role: .cancel) {}
        }
        .sheet(isPresented: $showReview) {
            DeleteReviewView(decisions: progress.decisions) {
                showReview = false
                saved = true
            }.environmentObject(library)
        }
        .alert("Abschließen nicht möglich", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("OK", role: .cancel) { error = nil }
        } message: { Text(error ?? "Bitte versuche es erneut.") }
    }

    @ViewBuilder private func photoCard(id: String) -> some View {
        if let asset = library.asset(for: id) {
            ReviewMediaCard(asset: asset, isActive: !showReview && !showLeave && !isSaving && error == nil,
                onChoose: choose).id(id)
        } else {
            ContentUnavailableView("Aufnahme nicht verfügbar", systemImage: "photo.badge.exclamationmark")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private func actionButton(_ title: String, symbol: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 26, weight: .bold))
                .foregroundStyle(color).frame(width: 70, height: 70)
                .background(color.opacity(0.14), in: Circle())
                .overlay(Circle().stroke(color.opacity(0.35), lineWidth: 1))
        }.buttonStyle(.plain).accessibilityLabel(title)
    }

    private var emptyState: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: mode.symbol).font(.system(size: 56)).foregroundStyle(.mint)
            Text("Hier ist gerade alles klar.").font(.title2.bold()).multilineTextAlignment(.center)
            Text(PhotoSelection.matching(library.records, mode: mode).isEmpty
                 ? "Für diesen Modus sind keine Fotos oder Videos verfügbar. Bei eingeschränktem Zugriff kannst du auf der Startseite weitere Aufnahmen freigeben."
                 : "Du hast die verfügbaren Aufnahmen bereits durchgesehen.")
                .foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
            if !PhotoSelection.matching(library.records, mode: mode).isEmpty {
                Button("Erneut durchsehen") {
                    library.restart(mode)
                    progress = ReviewProgress(ids: library.queue(for: mode))
                }.buttonStyle(.borderedProminent).tint(.mint).foregroundStyle(.black)
            }
            Button("Zur Übersicht") { dismiss() }.tint(.white)
            Spacer()
        }
    }

    private func choose(_ choice: PhotoChoice) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        progress.choose(choice)
    }

    private func finish() {
        if !progress.deleteIDs.isEmpty { showReview = true; return }
        isSaving = true
        Task {
            do {
                try await library.finish(progress.decisions, deleting: [])
                saved = true
            } catch { self.error = error.localizedDescription }
            isSaving = false
        }
    }
}

// Each view below is type-checked independently to keep the card's generic types small.
@MainActor
private struct ReviewMediaCard: View {
    let asset: PHAsset
    let isActive: Bool
    let onChoose: (PhotoChoice) -> Void
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var model: MediaViewerModel
    @State private var resetID = UUID()
    @State private var drag = CGSize.zero
    @State private var isZoomed = false

    init(asset: PHAsset, isActive: Bool, onChoose: @escaping (PhotoChoice) -> Void) {
        self.asset = asset
        self.isActive = isActive
        self.onChoose = onChoose
        _model = StateObject(wrappedValue: MediaViewerModel(asset: asset))
    }

    var body: some View {
        cardContent
            .accessibilityElement(children: .contain)
            .accessibilityLabel(Text(accessibilityText))
            .accessibilityHint("Direkt mit zwei Fingern zoomen. In Originalgröße zum Aussortieren wischen.")
            .accessibilityAction(named: Text("Behalten")) { onChoose(.keep) }
            .accessibilityAction(named: Text("Löschen vormerken")) { onChoose(.delete) }
            .onAppear(perform: loadMedia)
            .onDisappear { model.stop() }
            .onChange(of: isActive) { _, active in if !active { model.pause() } }
            .onChange(of: scenePhase) { _, phase in if phase != .active { model.pause() } }
            .onReceive(NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)) { _ in model.pause() }
    }

    private var cardContent: some View {
        VStack(spacing: 0) {
            poster
            if model.isVideo { VideoPlaybackControls(model: model) }
            ReviewMediaFooter(asset: asset, isZoomed: isZoomed, onReset: resetZoom)
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay {
            RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.18), lineWidth: 1)
        }
    }

    private var poster: some View {
        GeometryReader { geometry in
            mediaSurface
                .frame(width: geometry.size.width, height: geometry.size.height)
                .overlay { loadingPoster }
                .overlay { MediaLoadStatus(model: model, onRetry: loadMedia) }
                .overlay(alignment: .top) { swipeBadge }
                .offset(x: drag.width, y: drag.height * 0.12)
                .rotationEffect(.degrees(Double(drag.width / 24)))
                .clipped()
        }
    }

    private var mediaSurface: some View {
        ZoomableMedia(mediaID: asset.localIdentifier, image: model.image,
            player: model.isVideo ? model.player : nil,
            mediaSize: CGSize(width: CGFloat(asset.pixelWidth), height: CGFloat(asset.pixelHeight)),
            resetID: resetID,
            onSwipeChanged: { drag = $0 }, onSwipeEnded: finishSwipe,
            onZoomChanged: { isZoomed = $0 })
    }

    @ViewBuilder private var loadingPoster: some View {
        if model.isVideo ? !model.isReady : model.image == nil {
            AssetPhoto(asset: asset).allowsHitTesting(false).accessibilityHidden(true)
        }
    }

    @ViewBuilder private var swipeBadge: some View {
        if abs(drag.width) > 25 {
            ReviewSwipeBadge(keeping: drag.width > 0).allowsHitTesting(false)
        }
    }

    private func loadMedia() {
        model.load(autoplay: isActive && scenePhase == .active)
    }

    private func resetZoom() {
        resetID = UUID()
        withAnimation(.spring(response: 0.28, dampingFraction: 0.88)) { drag = .zero }
    }

    private func finishSwipe(_ choice: PhotoChoice?) {
        withAnimation(.spring(response: 0.28, dampingFraction: 0.88)) { drag = .zero }
        guard let choice, isActive, scenePhase == .active else { return }
        model.pause()
        onChoose(choice)
    }

    private var accessibilityText: String {
        let kind: String = asset.mediaType == .video ? "Video" : "Foto"
        let dateText: String
        if let date = asset.creationDate {
            dateText = date.formatted(date: .long, time: .shortened)
        } else {
            dateText = "Aufnahmedatum unbekannt"
        }
        return kind + ", " + dateText
    }
}

private struct ReviewMediaFooter: View {
    let asset: PHAsset
    let isZoomed: Bool
    let onReset: () -> Void

    private var hint: String {
        isZoomed ? "Vergrößert: mit einem Finger verschieben" : "Zwei Finger: Zoom · Doppeltipp: vergrößern"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 8) {
                MediaMetadataView(asset: asset)
                Button(action: onReset) {
                    Image(systemName: "arrow.down.right.and.arrow.up.left")
                        .font(.headline).frame(width: 44, height: 44)
                }.foregroundStyle(.white).disabled(!isZoomed)
                    .accessibilityLabel("Zoom zurücksetzen")
            }
            Label(hint, systemImage: "arrow.up.left.and.arrow.down.right")
                .font(.caption.weight(.medium))
                .foregroundStyle(MediaStyle.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(MediaStyle.panel)
    }
}

private struct ReviewSwipeBadge: View {
    let keeping: Bool

    private var label: String { keeping ? "BEHALTEN" : "LÖSCHEN" }
    private var color: Color { keeping ? Color.mint : Color.pink }

    var body: some View {
        Text(label)
            .font(.title2.bold())
            .foregroundStyle(color)
            .padding(12)
            .background(Color.black, in: Capsule())
            .padding(.top, 24)
    }
}

struct DeleteReviewView: View {
    let decisions: [PhotoDecision]
    let onFinished: () -> Void
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var selected: Set<String>
    @State private var isSaving = false
    @State private var error: String?
    private var candidates: [String] { decisions.filter { $0.choice == .delete }.map(\.id) }

    init(decisions: [PhotoDecision], onFinished: @escaping () -> Void) {
        self.decisions = decisions
        self.onFinished = onFinished
        _selected = State(initialValue: Set(decisions.filter { $0.choice == .delete }.map(\.id)))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text("Tippe auf eine Aufnahme, um sie doch zu behalten.")
                    .font(.subheadline).foregroundStyle(MediaStyle.secondary).padding(.top, 10)
                ScrollView {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 3), spacing: 8) {
                        ForEach(candidates, id: \.self) { id in
                            Button {
                                if selected.contains(id) { selected.remove(id) } else { selected.insert(id) }
                            } label: {
                                GeometryReader { geometry in
                                    AssetPhoto(asset: library.asset(for: id), thumbnail: true)
                                        .frame(width: geometry.size.width, height: geometry.size.height)
                                        .overlay(alignment: .bottomTrailing) {
                                            Image(systemName: selected.contains(id) ? "checkmark.circle.fill" : "heart.circle.fill")
                                                .font(.title2).foregroundStyle(selected.contains(id) ? Color.pink : Color.mint)
                                                .background(.black, in: Circle()).padding(6)
                                        }.clipShape(RoundedRectangle(cornerRadius: 10))
                                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(selected.contains(id) ? Color.pink : Color.clear, lineWidth: 2))
                                }.aspectRatio(1, contentMode: .fit)
                            }.buttonStyle(.plain).disabled(isSaving)
                                .accessibilityLabel(selected.contains(id) ? "Zum Löschen ausgewählt. Tippen zum Behalten." : "Wird behalten. Tippen zum Löschen.")
                        }
                    }.padding(2)
                }
                Text("iOS fragt vor dem Löschen nochmals nach. Gelöschte Fotos und Videos landen in „Zuletzt gelöscht“ in der Fotos-App. Bei iCloud-Fotos gilt die Löschung auch auf deinen anderen Geräten.")
                    .font(.caption).foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
                Button {
                    isSaving = true
                    Task {
                        do {
                            try await library.finish(decisions, deleting: selected)
                            onFinished()
                        } catch {
                            self.error = "Die Löschung wurde nicht abgeschlossen. Deine Auswahl bleibt erhalten.\n\n" + error.localizedDescription
                        }
                        isSaving = false
                    }
                } label: {
                    HStack {
                        if isSaving { ProgressView().tint(.white) }
                        Text(selected.isEmpty ? "Alle behalten und abschließen" : "\(selected.count) Aufnahmen löschen")
                            .fontWeight(.semibold)
                    }.frame(maxWidth: .infinity).padding(.vertical, 8)
                }.buttonStyle(.borderedProminent).tint(selected.isEmpty ? .mint : .pink)
                    .foregroundStyle(.black).disabled(isSaving)
            }
            .padding(.horizontal, 16).padding(.bottom, 16)
            .navigationTitle("Auswahl prüfen").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Zurück") { dismiss() }.disabled(isSaving)
                }
            }
            .alert("Nicht abgeschlossen", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("OK", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }.foregroundStyle(.white).environment(\.colorScheme, .dark)
            .preferredColorScheme(.dark).interactiveDismissDisabled(isSaving)
    }
}
