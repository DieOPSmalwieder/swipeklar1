import AVFAudio
import Photos
import SwiftUI
import UIKit

struct ReviewView: View {
    let mode: ReviewMode
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var progress: ReviewProgress
    @State private var showReview = false
    @State private var showLeave = false
    @State private var saved = false
    @State private var isSaving = false
    @State private var error: String?

    init(mode: ReviewMode, ids: [String]) {
        self.mode = mode
        _progress = State(initialValue: ReviewProgress(ids: ids))
    }

    var body: some View {
        reviewContent
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if progress.currentID != nil && !saved { decisionBar }
            }
            .background(Color.black.ignoresSafeArea()).foregroundStyle(.white)
            .environment(\.colorScheme, .dark)
            .navigationTitle(mode.displayTitle).navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .toolbar(.visible, for: .navigationBar)
            .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar { navigationItems }
            .tint(.white)
            .confirmationDialog("Auswahl verwerfen? Es wird nichts gelöscht.", isPresented: $showLeave, titleVisibility: .visible) {
                Button("Auswahl verwerfen und zurück", role: .destructive) { dismiss() }
                Button("Weiter durchsehen", role: .cancel) {}
            }
            .sheet(isPresented: $showReview) {
                DeleteReviewView(decisions: progress.decisions) {
                    showReview = false
                    saved = true
                }.environmentObject(library)
            }
            .alert("Abschließen nicht möglich", isPresented: errorPresented) {
                Button("OK", role: .cancel) { error = nil }
            } message: { Text(error ?? "Bitte versuche es erneut.") }
    }

    @ViewBuilder private var reviewContent: some View {
        if progress.ids.isEmpty {
            emptyState
        } else if saved {
            savedState
        } else {
            VStack(spacing: 0) {
                progressHeader
                if let id = progress.currentID {
                    photoCard(id: id).layoutPriority(1)
                } else {
                    completedState
                }
            }
        }
    }

    private var progressHeader: some View {
        VStack(spacing: 8) {
            HStack {
                Text("\(progress.decisions.count) von \(progress.ids.count)").monospacedDigit()
                Spacer()
                Label("\(progress.deleteIDs.count) vorgemerkt", systemImage: "trash")
            }.font(.caption.weight(.medium)).foregroundStyle(MediaStyle.secondary)
            ProgressView(value: Double(progress.decisions.count), total: Double(max(1, progress.ids.count)))
                .tint(.blue).accessibilityLabel("Fortschritt")
        }.padding(.horizontal, 16).padding(.top, 6).padding(.bottom, 4)
    }

    private var decisionBar: some View {
        HStack(spacing: 0) {
            ReviewDecisionButton(title: "Vormerken", symbol: "trash", color: .red) { choose(.delete) }
            ReviewDecisionButton(title: "Zurück", symbol: "arrow.uturn.backward", color: .white) { progress.undo() }
                .disabled(progress.decisions.isEmpty)
                .accessibilityLabel("Letzte Entscheidung zurücknehmen")
            ReviewDecisionButton(title: "Behalten", symbol: "checkmark", color: .blue) { choose(.keep) }
        }
        .padding(.vertical, 4)
        .background(.regularMaterial, in: Capsule())
        .padding(.horizontal, 24).padding(.vertical, 8)
        .background(Color.black)
        .disabled(isSaving)
    }

    @ToolbarContentBuilder private var navigationItems: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            Button {
                if !saved && !progress.decisions.isEmpty { showLeave = true } else { dismiss() }
            } label: { Image(systemName: "chevron.left") }
                .accessibilityLabel("Zur Übersicht").disabled(isSaving)
        }
        ToolbarItem(placement: .topBarTrailing) {
            if !saved && !progress.decisions.isEmpty && !progress.isComplete {
                Button("Fertig") { finish() }.fontWeight(.semibold).disabled(isSaving)
            }
        }
    }

    @ViewBuilder private func photoCard(id: String) -> some View {
        if let asset = library.asset(for: id) {
            ReviewMediaCard(asset: asset, isActive: !showReview && !showLeave && !isSaving && error == nil,
                onChoose: choose).id(id)
        } else {
            ContentUnavailableView("Aufnahme nicht verfügbar", systemImage: "photo.badge.exclamationmark")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private var savedState: some View {
        VStack(spacing: 20) {
            Image(systemName: "checkmark.circle.fill").font(.system(size: 56)).foregroundStyle(.blue)
            Text("Alles erledigt.").font(.largeTitle.bold())
            Text("Deine Auswahl wurde gespeichert.").foregroundStyle(MediaStyle.secondary)
            Button("Zur Übersicht") { dismiss() }.buttonStyle(.borderedProminent).tint(.blue)
        }.padding(24)
    }

    private var completedState: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "checkmark.circle").font(.system(size: 56)).foregroundStyle(.blue)
            Text("Gut durchgesehen.").font(.title.bold())
            Text("\(progress.keptCount) behalten · \(progress.deleteIDs.count) vorgemerkt")
                .foregroundStyle(MediaStyle.secondary)
            Text("Gelöscht wird erst nach deiner Bestätigung.")
                .font(.footnote).foregroundStyle(MediaStyle.secondary)
            Button(progress.deleteIDs.isEmpty ? "Abschließen" : "Auswahl prüfen") { finish() }
                .buttonStyle(.borderedProminent).tint(.blue).disabled(isSaving)
            Button("Letzte Entscheidung zurücknehmen") { progress.undo() }
                .font(.footnote).padding(.vertical, 8).disabled(isSaving)
            Spacer()
        }.multilineTextAlignment(.center).padding(24)
    }

    private var emptyState: some View {
        VStack(spacing: 20) {
            Image(systemName: mode.symbol).font(.system(size: 48)).foregroundStyle(.blue)
            Text("Hier ist gerade alles klar.").font(.title2.bold())
            Text(PhotoSelection.matching(library.records, mode: mode).isEmpty
                 ? "Für diesen Modus sind keine Aufnahmen verfügbar. Bei eingeschränktem Zugriff kannst du auf der Startseite weitere Fotos freigeben."
                 : "Du hast die verfügbaren Aufnahmen bereits durchgesehen.")
                .foregroundStyle(MediaStyle.secondary)
            if !PhotoSelection.matching(library.records, mode: mode).isEmpty {
                Button("Erneut durchsehen") {
                    library.restart(mode)
                    progress = ReviewProgress(ids: library.queue(for: mode))
                }.buttonStyle(.borderedProminent).tint(.blue)
            }
            Button("Zur Übersicht") { dismiss() }.padding(.vertical, 8)
        }.multilineTextAlignment(.center).padding(24)
    }

    private var errorPresented: Binding<Bool> {
        Binding(get: { error != nil }, set: { if !$0 { error = nil } })
    }

    private func choose(_ choice: PhotoChoice) {
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        progress.choose(choice)
    }

    private func finish() {
        if !progress.deleteIDs.isEmpty { showReview = true; return }
        isSaving = true
        Task {
            do {
                try await library.finish(progress.decisions, deleting: [])
                saved = true
            } catch { self.error = error.localizedDescription }
            isSaving = false
        }
    }
}

private struct ReviewDecisionButton: View {
    let title: String
    let symbol: String
    let color: Color
    let action: () -> Void
    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: symbol).font(.system(size: 21, weight: .semibold))
                    .foregroundStyle(color)
                Text(title).font(.caption2.weight(.medium)).foregroundStyle(.white)
            }.frame(maxWidth: .infinity).frame(minHeight: 52).contentShape(Rectangle())
        }
        .buttonStyle(.plain).opacity(isEnabled ? 1 : 0.35)
        .accessibilityLabel(title == "Vormerken" ? "Zum Löschen vormerken" : title)
    }
}

// Each view below is type-checked independently to keep the card's generic types small.
@MainActor
private struct ReviewMediaCard: View {
    let asset: PHAsset
    let isActive: Bool
    let onChoose: (PhotoChoice) -> Void
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var model: MediaViewerModel
    @State private var resetID = UUID()
    @State private var drag = CGSize.zero
    @State private var isZoomed = false

    init(asset: PHAsset, isActive: Bool, onChoose: @escaping (PhotoChoice) -> Void) {
        self.asset = asset
        self.isActive = isActive
        self.onChoose = onChoose
        _model = StateObject(wrappedValue: MediaViewerModel(asset: asset))
    }

    var body: some View {
        cardContent
            .accessibilityElement(children: .contain)
            .accessibilityLabel(Text(accessibilityText))
            .accessibilityHint("Direkt mit zwei Fingern zoomen. In Originalgröße zum Aussortieren wischen.")
            .accessibilityAction(named: Text("Behalten")) { onChoose(.keep) }
            .accessibilityAction(named: Text("Löschen vormerken")) { onChoose(.delete) }
            .onAppear(perform: loadMedia)
            .onDisappear { model.stop() }
            .onChange(of: isActive) { _, active in if !active { model.pause() } }
            .onChange(of: scenePhase) { _, phase in if phase != .active { model.pause() } }
            .onReceive(NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)) { _ in model.pause() }
    }

    private var cardContent: some View {
        VStack(spacing: 0) {
            MediaInformationBar(asset: asset, isZoomed: isZoomed, onReset: resetZoom)
            poster
            if model.isVideo { VideoPlaybackControls(model: model) }
        }
        .background(Color.black)
    }

    private var poster: some View {
        GeometryReader { geometry in
            mediaSurface
                .frame(width: geometry.size.width, height: geometry.size.height)
                .overlay { loadingPoster }
                .overlay { MediaLoadStatus(model: model, onRetry: loadMedia) }
                .overlay(alignment: .top) { swipeBadge }
                .offset(x: drag.width, y: drag.height * 0.12)
                .rotationEffect(.degrees(Double(drag.width / 24)))
                .clipped()
        }
    }

    private var mediaSurface: some View {
        ZoomableMedia(mediaID: asset.localIdentifier, image: model.image,
            player: model.isVideo ? model.player : nil,
            mediaSize: CGSize(width: CGFloat(asset.pixelWidth), height: CGFloat(asset.pixelHeight)),
            resetID: resetID,
            onSwipeChanged: { drag = $0 }, onSwipeEnded: finishSwipe,
            onZoomChanged: { isZoomed = $0 })
    }

    @ViewBuilder private var loadingPoster: some View {
        if model.isVideo ? !model.isReady : model.image == nil {
            AssetPhoto(asset: asset).allowsHitTesting(false).accessibilityHidden(true)
        }
    }

    @ViewBuilder private var swipeBadge: some View {
        if abs(drag.width) > 25 {
            ReviewSwipeBadge(keeping: drag.width > 0).allowsHitTesting(false)
        }
    }

    private func loadMedia() {
        model.load(autoplay: isActive && scenePhase == .active)
    }

    private func resetZoom() {
        resetID = UUID()
        withAnimation(.spring(response: 0.28, dampingFraction: 0.88)) { drag = .zero }
    }

    private func finishSwipe(_ choice: PhotoChoice?) {
        withAnimation(.spring(response: 0.28, dampingFraction: 0.88)) { drag = .zero }
        guard let choice, isActive, scenePhase == .active else { return }
        model.pause()
        onChoose(choice)
    }

    private var accessibilityText: String {
        let kind: String = asset.mediaType == .video ? "Video" : "Foto"
        let dateText: String
        if let date = asset.creationDate {
            dateText = date.formatted(date: .long, time: .shortened)
        } else {
            dateText = "Aufnahmedatum unbekannt"
        }
        return kind + ", " + dateText
    }
}

private struct ReviewSwipeBadge: View {
    let keeping: Bool

    var body: some View {
        Label(keeping ? "Behalten" : "Vorgemerkt", systemImage: keeping ? "checkmark" : "trash")
            .font(.headline).foregroundStyle(.white)
            .padding(.horizontal, 18).padding(.vertical, 12)
            .background(keeping ? Color.blue : Color.red, in: Capsule())
            .padding(.top, 24)
    }
}
