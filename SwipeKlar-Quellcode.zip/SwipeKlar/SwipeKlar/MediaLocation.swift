import CoreLocation
import Photos
import SwiftUI

@MainActor
struct MediaLocationLabel: View {
    let asset: PHAsset?
    @StateObject private var location = MediaLocationModel()

    var body: some View {
        Label(location.text, systemImage: asset?.location == nil ? "location.slash" : "location.fill")
            .font(.caption).foregroundStyle(MediaStyle.secondary)
            .lineLimit(1).truncationMode(.tail)
            .frame(minHeight: 16, alignment: .leading)
            .accessibilityLabel("Aufnahmeort: " + location.text)
            .task(id: asset?.localIdentifier) { await location.load(asset?.location) }
            .onDisappear { location.cancel() }
    }
}

@MainActor
private final class MediaLocationModel: ObservableObject {
    @Published private(set) var text = "Kein Standort"
    private let geocoder = CLGeocoder()
    private static var cache: [String: String] = [:]

    func load(_ location: CLLocation?) async {
        guard let location else { text = "Kein Standort"; return }
        let coordinate = location.coordinate
        guard CLLocationCoordinate2DIsValid(coordinate) else { text = "Kein Standort"; return }
        let key = String(format: "%.3f,%.3f", coordinate.latitude, coordinate.longitude)
        if let cached = Self.cache[key] { text = cached; return }
        // Coordinates remain useful offline, without requesting the device's location.
        text = String(format: "%.3f° · %.3f°", coordinate.latitude, coordinate.longitude)
        do {
            // Rapidly swiping through cards should not issue a geocoding request for each.
            try await Task.sleep(nanoseconds: 650_000_000)
            try Task.checkCancellation()
            let placemarks = try await geocoder.reverseGeocodeLocation(location, preferredLocale: .current)
            try Task.checkCancellation()
            guard let place = placemarks.first else { return }
            let town = place.locality ?? place.subAdministrativeArea ?? place.administrativeArea
            let parts = [town, place.country].compactMap { $0 }.filter { !$0.isEmpty }
            let unique = parts.reduce(into: [String]()) { values, part in
                if !values.contains(part) { values.append(part) }
            }
            let name = unique.joined(separator: ", ")
            guard !name.isEmpty else { return }
            if Self.cache.count >= 256 { Self.cache.removeAll(keepingCapacity: true) }
            Self.cache[key] = name
            text = name
        } catch {
            // Keep the recorded coordinates when offline or geocoding is rate-limited.
        }
    }

    func cancel() { geocoder.cancelGeocode() }
}
