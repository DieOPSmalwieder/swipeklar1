import AVFAudio
import Photos
import SwiftUI
import UIKit

struct DeletionPreviewItem: Identifiable {
    let asset: PHAsset
    var id: String { asset.localIdentifier }
}

/// Inspecting a candidate never commits a deletion; only the review's final button does.
@MainActor
struct DeletionPreviewView: View {
    let asset: PHAsset
    @Binding var isSelected: Bool
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var model: MediaViewerModel
    @State private var resetID = UUID()
    @State private var isZoomed = false

    init(asset: PHAsset, isSelected: Binding<Bool>) {
        self.asset = asset
        _isSelected = isSelected
        _model = StateObject(wrappedValue: MediaViewerModel(asset: asset))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                MediaInformationBar(asset: asset, isZoomed: isZoomed) { resetID = UUID() }
                mediaSurface
                if model.isVideo { VideoPlaybackControls(model: model) }
            }
            .background(Color.black)
            .safeAreaInset(edge: .bottom, spacing: 0) { selectionBar }
            .navigationTitle("Vorschau").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Fertig") { model.pause(); dismiss() }.fontWeight(.semibold)
                        .accessibilityLabel("Vorschau schließen")
                }
            }
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
        .tint(.white).environment(\.colorScheme, .dark).preferredColorScheme(.dark)
        .onAppear(perform: loadMedia)
        .onDisappear { model.stop() }
        .onChange(of: scenePhase) { _, phase in if phase != .active { model.pause() } }
        .onReceive(NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)) { _ in model.pause() }
    }

    private var mediaSurface: some View {
        GeometryReader { geometry in
            ZoomableMedia(mediaID: asset.localIdentifier, image: model.image,
                player: model.isVideo ? model.player : nil,
                mediaSize: CGSize(width: CGFloat(asset.pixelWidth), height: CGFloat(asset.pixelHeight)),
                resetID: resetID, onZoomChanged: { isZoomed = $0 })
                .frame(width: geometry.size.width, height: geometry.size.height)
                .overlay { loadingPoster }
                .overlay { MediaLoadStatus(model: model, onRetry: loadMedia) }
                .clipped()
        }
        .accessibilityLabel(asset.mediaType == .video ? "Video in großer Vorschau" : "Foto in großer Vorschau")
        .accessibilityHint("Mit zwei Fingern zoomen oder zum Vergrößern doppeltippen.")
    }

    @ViewBuilder private var loadingPoster: some View {
        if model.isVideo ? !model.isReady : model.image == nil {
            AssetPhoto(asset: asset).allowsHitTesting(false).accessibilityHidden(true)
        }
    }

    private var selectionBar: some View {
        VStack(spacing: 10) {
            Label(isSelected ? "Zum Löschen ausgewählt" : "Diese Aufnahme wird behalten",
                systemImage: isSelected ? "trash" : "checkmark.shield")
                .font(.subheadline.weight(.medium)).foregroundStyle(.white)
                .accessibilityAddTraits(.updatesFrequently)
            Button {
                isSelected.toggle()
                UISelectionFeedbackGenerator().selectionChanged()
            } label: {
                Label(isSelected ? "Diese Aufnahme behalten" : "Wieder zum Löschen vormerken",
                    systemImage: isSelected ? "checkmark" : "trash")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity).padding(.vertical, 8)
            }
            .buttonStyle(.borderedProminent).tint(isSelected ? .blue : .gray.opacity(0.3))
        }
        .padding(16).background(.regularMaterial)
    }

    private func loadMedia() { model.load(autoplay: scenePhase == .active) }
}
