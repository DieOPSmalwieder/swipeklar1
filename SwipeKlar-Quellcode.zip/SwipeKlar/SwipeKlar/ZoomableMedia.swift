import AVFoundation
import SwiftUI
import UIKit
import UIKit.UIGestureRecognizerSubclass

/// One zoom surface for both a still image and the video layer. Controls stay outside it.
struct ZoomableMedia: UIViewRepresentable {
    let mediaID: String
    let image: UIImage?
    let player: AVPlayer?
    let mediaSize: CGSize
    let resetID: UUID
    var onSwipeChanged: ((CGSize) -> Void)? = nil
    var onSwipeEnded: ((PhotoChoice?) -> Void)? = nil
    var onZoomChanged: ((Bool) -> Void)? = nil
    var onHoldChanged: ((Bool) -> Void)? = nil
    var onEdgeTap: ((PhotoChoice) -> Void)? = nil

    func makeUIView(context: Context) -> MediaZoomScrollView {
        let scroll = MediaZoomScrollView(frame: .zero)
        scroll.delegate = context.coordinator
        let doubleTap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.doubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        doubleTap.delegate = context.coordinator
        scroll.addGestureRecognizer(doubleTap)
        let hold = UILongPressGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleHold(_:)))
        hold.minimumPressDuration = 0.3
        hold.allowableMovement = 10
        hold.numberOfTouchesRequired = 1
        hold.delegate = context.coordinator
        scroll.addGestureRecognizer(hold)
        context.coordinator.holdRecognizer = hold
        let edgeTap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.edgeTap(_:)))
        edgeTap.numberOfTouchesRequired = 1
        edgeTap.require(toFail: doubleTap)
        edgeTap.require(toFail: hold)
        edgeTap.delegate = context.coordinator
        scroll.addGestureRecognizer(edgeTap)
        context.coordinator.edgeRecognizer = edgeTap
        let touchGuard = MediaMultiTouchGuard(target: nil, action: nil)
        touchGuard.cancelsTouchesInView = false
        touchGuard.delaysTouchesBegan = false
        touchGuard.delaysTouchesEnded = false
        touchGuard.onSequenceBegan = { [weak coordinator = context.coordinator] in
            coordinator?.hadMultipleTouches = false
            coordinator?.sequenceWasHeld = false
        }
        touchGuard.onMultipleTouches = { [weak coordinator = context.coordinator] in
            coordinator?.hadMultipleTouches = true
            coordinator?.cancelSwipe()
            coordinator?.setHolding(false)
        }
        scroll.addGestureRecognizer(touchGuard)
        scroll.panGestureRecognizer.addTarget(context.coordinator, action: #selector(Coordinator.handlePan(_:)))
        scroll.pinchGestureRecognizer?.addTarget(context.coordinator, action: #selector(Coordinator.handlePinch(_:)))
        return scroll
    }

    func updateUIView(_ scroll: MediaZoomScrollView, context: Context) {
        let coordinator = context.coordinator
        coordinator.suppressCallbacks = true
        defer { coordinator.suppressCallbacks = false }
        if coordinator.mediaID != mediaID || coordinator.resetID != resetID {
            coordinator.setHolding(false, deferred: true)
        }
        coordinator.onSwipeChanged = onSwipeChanged
        coordinator.onSwipeEnded = onSwipeEnded
        coordinator.onZoomChanged = onZoomChanged
        coordinator.onHoldChanged = onHoldChanged
        coordinator.onEdgeTap = onEdgeTap
        let allowsHolding = player != nil && onHoldChanged != nil
        if coordinator.holdRecognizer?.isEnabled != allowsHolding {
            coordinator.holdRecognizer?.isEnabled = allowsHolding
        }
        let allowsEdgeTaps = onEdgeTap != nil || onSwipeEnded != nil
        if coordinator.edgeRecognizer?.isEnabled != allowsEdgeTaps {
            coordinator.edgeRecognizer?.isEnabled = allowsEdgeTaps
        }
        coordinator.allowsSwiping = onSwipeEnded != nil
        if scroll.alwaysBounceHorizontal != coordinator.allowsSwiping {
            scroll.alwaysBounceHorizontal = coordinator.allowsSwiping
        }
        scroll.mediaSize = mediaSize
        if coordinator.mediaID != mediaID || coordinator.resetID != resetID {
            let isNewMedia = coordinator.mediaID != mediaID
            coordinator.cancelSwipe(notify: false)
            coordinator.mediaID = mediaID
            coordinator.resetID = resetID
            scroll.setZoomScale(1, animated: !isNewMedia)
            if isNewMedia { scroll.setContentOffset(.zero, animated: false) }
            scroll.centerCanvas()
        }
        // Playback time updates must not repeatedly replace the same displayed image.
        if scroll.canvas.imageView.image !== image { scroll.canvas.imageView.image = image }
        scroll.canvas.imageView.isHidden = player != nil
        if scroll.canvas.videoLayer.player !== player { scroll.canvas.videoLayer.player = player }
        coordinator.reportZoom(scroll)
    }

    static func dismantleUIView(_ scroll: MediaZoomScrollView, coordinator: Coordinator) {
        coordinator.setHolding(false, deferred: true)
        coordinator.mediaID = nil
        coordinator.onSwipeChanged = nil
        coordinator.onSwipeEnded = nil
        coordinator.onZoomChanged = nil
        coordinator.onHoldChanged = nil
        coordinator.onEdgeTap = nil
        scroll.panGestureRecognizer.removeTarget(coordinator, action: #selector(Coordinator.handlePan(_:)))
        scroll.pinchGestureRecognizer?.removeTarget(coordinator, action: #selector(Coordinator.handlePinch(_:)))
        scroll.canvas.videoLayer.player = nil
        scroll.canvas.imageView.image = nil
        scroll.delegate = nil
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    final class Coordinator: NSObject, UIScrollViewDelegate, UIGestureRecognizerDelegate {
        var mediaID: String?
        var resetID: UUID?
        var allowsSwiping = false
        var suppressCallbacks = false
        var hadMultipleTouches = false
        var sequenceWasHeld = false
        private var isHolding = false
        weak var holdRecognizer: UILongPressGestureRecognizer?
        weak var edgeRecognizer: UITapGestureRecognizer?
        var onSwipeChanged: ((CGSize) -> Void)?
        var onSwipeEnded: ((PhotoChoice?) -> Void)?
        var onZoomChanged: ((Bool) -> Void)?
        var onHoldChanged: ((Bool) -> Void)?
        var onEdgeTap: ((PhotoChoice) -> Void)?
        private var swipe = CardSwipeSession()
        private var reportedZoom: Bool?

        func viewForZooming(in scrollView: UIScrollView) -> UIView? {
            (scrollView as? MediaZoomScrollView)?.canvas
        }

        func scrollViewDidZoom(_ scrollView: UIScrollView) {
            (scrollView as? MediaZoomScrollView)?.centerCanvas()
            if scrollView.zoomScale > 1.01 { cancelSwipe() }
            reportZoom(scrollView)
        }

        func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
            cancelSwipe()
        }

        func scrollViewDidEndZooming(_ scrollView: UIScrollView, with view: UIView?, atScale scale: CGFloat) {
            reportZoom(scrollView)
        }

        func scrollViewDidScroll(_ scrollView: UIScrollView) {
            guard allowsSwiping, scrollView.zoomScale <= 1.01, !scrollView.isZooming,
                  !pinchIsActive(scrollView) else { return }
            // At 1× the pan moves the card rather than scrolling into letterbox space.
            if abs(scrollView.contentOffset.x) > 0.01 || abs(scrollView.contentOffset.y) > 0.01 {
                scrollView.contentOffset = .zero
            }
        }

        @objc func handlePan(_ gesture: UIPanGestureRecognizer) {
            guard let scroll = gesture.view as? UIScrollView, allowsSwiping else { return }
            let translation = gesture.translation(in: scroll.window)
            let scale = Double(scroll.zoomScale)
            let pinching = scroll.isZooming || pinchIsActive(scroll) || hadMultipleTouches || sequenceWasHeld
            switch gesture.state {
            case .began:
                swipe.begin(zoomScale: scale, touchCount: gesture.numberOfTouches, isPinching: pinching)
            case .changed:
                swipe.update(zoomScale: scale, touchCount: gesture.numberOfTouches, isPinching: pinching)
                let horizontal = abs(translation.x) > abs(translation.y)
                if !suppressCallbacks {
                    onSwipeChanged?(swipe.isEligible && horizontal
                        ? CGSize(width: translation.x, height: translation.y) : .zero)
                }
            case .ended:
                if pinching { swipe.cancel() }
                let choice = swipe.finish(horizontal: Double(translation.x), vertical: Double(translation.y), zoomScale: scale)
                if !suppressCallbacks { onSwipeEnded?(choice) }
            case .cancelled, .failed:
                cancelSwipe()
                if !suppressCallbacks { onSwipeEnded?(nil) }
            default: break
            }
        }

        @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
            if gesture.state == .began || (gesture.state == .changed && swipe.isEligible) {
                cancelSwipe()
                setHolding(false)
            }
        }

        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let scroll = gestureRecognizer.view as? UIScrollView else { return true }
            if gestureRecognizer === holdRecognizer || gestureRecognizer === edgeRecognizer {
                guard !scroll.isZooming, !pinchIsActive(scroll),
                      MediaTouchPolicy.canUseSingleTouch(zoomScale: Double(scroll.zoomScale),
                          hadMultipleTouches: hadMultipleTouches, wasHeld: sequenceWasHeld) else { return false }
                if gestureRecognizer === holdRecognizer { return onHoldChanged != nil }
                return edgeRecognizer?.isEnabled == true
            }
            return !hadMultipleTouches && !sequenceWasHeld
        }

        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool {
            // A second finger must be able to turn a hold into a native pinch gesture.
            (gestureRecognizer is UILongPressGestureRecognizer && other is UIPinchGestureRecognizer)
                || (gestureRecognizer is UIPinchGestureRecognizer && other is UILongPressGestureRecognizer)
        }

        @objc func handleHold(_ gesture: UILongPressGestureRecognizer) {
            switch gesture.state {
            case .began:
                guard !hadMultipleTouches else { return }
                sequenceWasHeld = true
                cancelSwipe()
                setHolding(true)
            case .ended, .cancelled, .failed: setHolding(false)
            default: break
            }
        }

        func setHolding(_ active: Bool, deferred: Bool = false) {
            guard isHolding != active else { return }
            isHolding = active
            let callback = onHoldChanged
            if deferred { DispatchQueue.main.async { callback?(active) } }
            else { callback?(active) }
        }

        @objc func edgeTap(_ gesture: UITapGestureRecognizer) {
            guard gesture.state == .ended,
                  let scroll = gesture.view as? UIScrollView, !scroll.isZooming, !pinchIsActive(scroll) else { return }
            let point = gesture.location(in: scroll)
            let x = point.x - scroll.bounds.minX
            if let choice = MediaTouchPolicy.edgeChoice(x: Double(x), width: Double(scroll.bounds.width),
                zoomScale: Double(scroll.zoomScale), hadMultipleTouches: hadMultipleTouches, wasHeld: sequenceWasHeld) {
                cancelSwipe()
                if let onEdgeTap { onEdgeTap(choice) }
                else { onSwipeEnded?(choice) }
            }
        }

        func cancelSwipe(notify: Bool = true) {
            let wasEligible = swipe.isEligible
            swipe.cancel()
            if notify, wasEligible, !suppressCallbacks { onSwipeChanged?(.zero) }
        }

        func reportZoom(_ scroll: UIScrollView) {
            let zoomed = scroll.zoomScale > 1.01
            guard reportedZoom != zoomed else { return }
            reportedZoom = zoomed
            let id = mediaID
            DispatchQueue.main.async { [weak self] in
                guard let self, self.mediaID == id else { return }
                self.onZoomChanged?(zoomed)
            }
        }

        private func pinchIsActive(_ scroll: UIScrollView) -> Bool {
            let state = scroll.pinchGestureRecognizer?.state
            return state == .began || state == .changed
        }

        @objc func doubleTap(_ gesture: UITapGestureRecognizer) {
            guard let scroll = gesture.view as? MediaZoomScrollView else { return }
            cancelSwipe()
            if scroll.zoomScale > 1.05 {
                scroll.setZoomScale(1, animated: true)
            } else {
                let point = gesture.location(in: scroll.canvas)
                let width = scroll.bounds.width / 2.5
                let height = scroll.bounds.height / 2.5
                scroll.zoom(to: CGRect(x: point.x - width / 2, y: point.y - height / 2,
                    width: width, height: height), animated: true)
            }
        }
    }
}

/// Observes added fingers even before a pinch has moved enough to be recognized.
/// It never wins or blocks another recognizer and ends by failing deliberately.
final class MediaMultiTouchGuard: UIGestureRecognizer {
    var onSequenceBegan: (() -> Void)?
    var onMultipleTouches: (() -> Void)?
    private var activeTouches: Set<UITouch> = []

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        if activeTouches.isEmpty { onSequenceBegan?() }
        activeTouches.formUnion(touches)
        if activeTouches.count > 1 { onMultipleTouches?() }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        activeTouches.subtract(touches)
        if activeTouches.isEmpty { state = .failed }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        // Observation only; remain possible while native pan and pinch recognize normally.
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        activeTouches.removeAll()
        state = .failed
    }

    override func reset() {
        super.reset()
        activeTouches.removeAll()
    }

    override func canPrevent(_ preventedGestureRecognizer: UIGestureRecognizer) -> Bool { false }
    override func canBePrevented(by preventingGestureRecognizer: UIGestureRecognizer) -> Bool { false }
}

final class MediaZoomScrollView: UIScrollView {
    let canvas = MediaCanvasView(frame: .zero)
    var mediaSize = CGSize(width: 1, height: 1) {
        didSet { if oldValue != mediaSize { setNeedsLayout() } }
    }
    private var previousSize = CGSize.zero
    private var previousMediaSize = CGSize.zero

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        minimumZoomScale = 1
        maximumZoomScale = 5
        bouncesZoom = true
        decelerationRate = .fast
        delaysContentTouches = false
        scrollsToTop = false
        showsHorizontalScrollIndicator = false
        showsVerticalScrollIndicator = false
        contentInsetAdjustmentBehavior = .never
        addSubview(canvas)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds.size != previousSize || mediaSize != previousMediaSize else { return }
        guard bounds.width > 0, bounds.height > 0 else { return }
        previousSize = bounds.size
        previousMediaSize = mediaSize
        setZoomScale(1, animated: false)
        let width = max(1, mediaSize.width)
        let height = max(1, mediaSize.height)
        let scale = min(bounds.width / width, bounds.height / height)
        let fitted = CGSize(width: width * scale, height: height * scale)
        canvas.frame = CGRect(origin: .zero, size: fitted)
        contentSize = fitted
        contentOffset = .zero
        centerCanvas()
    }

    func centerCanvas() {
        canvas.center = CGPoint(x: max(contentSize.width, bounds.width) / 2,
            y: max(contentSize.height, bounds.height) / 2)
    }
}

final class MediaCanvasView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var videoLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    let imageView = UIImageView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        videoLayer.videoGravity = .resizeAspect
        imageView.contentMode = .scaleAspectFit
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.frame = bounds
        addSubview(imageView)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}
