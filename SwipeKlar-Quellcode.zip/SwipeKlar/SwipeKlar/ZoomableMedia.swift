import AVFoundation
import SwiftUI
import UIKit

/// One zoom surface for both a still image and the video layer. Controls stay outside it.
struct ZoomableMedia: UIViewRepresentable {
    let mediaID: String
    let image: UIImage?
    let player: AVPlayer?
    let mediaSize: CGSize
    let resetID: UUID

    func makeUIView(context: Context) -> MediaZoomScrollView {
        let scroll = MediaZoomScrollView(frame: .zero)
        scroll.delegate = context.coordinator
        let doubleTap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.doubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        scroll.addGestureRecognizer(doubleTap)
        return scroll
    }

    func updateUIView(_ scroll: MediaZoomScrollView, context: Context) {
        scroll.mediaSize = mediaSize
        if context.coordinator.mediaID != mediaID || context.coordinator.resetID != resetID {
            scroll.setZoomScale(1, animated: false)
            scroll.setContentOffset(.zero, animated: false)
            scroll.centerCanvas()
            context.coordinator.mediaID = mediaID
            context.coordinator.resetID = resetID
        }
        scroll.canvas.imageView.image = image
        scroll.canvas.imageView.isHidden = player != nil
        if scroll.canvas.videoLayer.player !== player { scroll.canvas.videoLayer.player = player }
    }

    static func dismantleUIView(_ scroll: MediaZoomScrollView, coordinator: Coordinator) {
        scroll.canvas.videoLayer.player = nil
        scroll.canvas.imageView.image = nil
        scroll.delegate = nil
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    final class Coordinator: NSObject, UIScrollViewDelegate {
        var mediaID: String?
        var resetID: UUID?

        func viewForZooming(in scrollView: UIScrollView) -> UIView? {
            (scrollView as? MediaZoomScrollView)?.canvas
        }

        func scrollViewDidZoom(_ scrollView: UIScrollView) {
            (scrollView as? MediaZoomScrollView)?.centerCanvas()
        }

        @objc func doubleTap(_ gesture: UITapGestureRecognizer) {
            guard let scroll = gesture.view as? MediaZoomScrollView else { return }
            if scroll.zoomScale > 1.05 {
                scroll.setZoomScale(1, animated: true)
            } else {
                let point = gesture.location(in: scroll.canvas)
                let width = scroll.bounds.width / 2.5
                let height = scroll.bounds.height / 2.5
                scroll.zoom(to: CGRect(x: point.x - width / 2, y: point.y - height / 2,
                    width: width, height: height), animated: true)
            }
        }
    }
}

final class MediaZoomScrollView: UIScrollView {
    let canvas = MediaCanvasView(frame: .zero)
    var mediaSize = CGSize(width: 1, height: 1) {
        didSet { if oldValue != mediaSize { setNeedsLayout() } }
    }
    private var previousSize = CGSize.zero
    private var previousMediaSize = CGSize.zero

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        minimumZoomScale = 1
        maximumZoomScale = 5
        bouncesZoom = true
        showsHorizontalScrollIndicator = false
        showsVerticalScrollIndicator = false
        contentInsetAdjustmentBehavior = .never
        addSubview(canvas)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds.size != previousSize || mediaSize != previousMediaSize else { return }
        guard bounds.width > 0, bounds.height > 0 else { return }
        previousSize = bounds.size
        previousMediaSize = mediaSize
        setZoomScale(1, animated: false)
        let width = max(1, mediaSize.width)
        let height = max(1, mediaSize.height)
        let scale = min(bounds.width / width, bounds.height / height)
        let fitted = CGSize(width: width * scale, height: height * scale)
        canvas.frame = CGRect(origin: .zero, size: fitted)
        contentSize = fitted
        contentOffset = .zero
        centerCanvas()
    }

    func centerCanvas() {
        canvas.center = CGPoint(x: max(contentSize.width, bounds.width) / 2,
            y: max(contentSize.height, bounds.height) / 2)
    }
}

final class MediaCanvasView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var videoLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    let imageView = UIImageView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        videoLayer.videoGravity = .resizeAspect
        imageView.contentMode = .scaleAspectFit
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.frame = bounds
        addSubview(imageView)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}
