import AVFoundation
import Photos

/// Reads only already-local file metadata. Never downloads iCloud originals for a size label.
@MainActor
final class LocalAssetSizeProbe {
    private let asset: PHAsset
    private let completion: (MediaSizeEstimate) -> Void
    private var requestID: PHContentEditingInputRequestID?
    private var timeout: Task<Void, Never>?
    private var finished = false

    init(asset: PHAsset, completion: @escaping (MediaSizeEstimate) -> Void) {
        self.asset = asset
        self.completion = completion
    }

    static func fallback(for asset: PHAsset) -> MediaSizeEstimate {
        MediaSizeEstimate(bytes: MediaSizeHeuristic.bytes(width: asset.pixelWidth, height: asset.pixelHeight,
            duration: asset.duration, isVideo: asset.mediaType == .video,
            isLivePhoto: asset.mediaSubtypes.contains(.photoLive)), isEstimated: true)
    }

    func start() {
        let options = PHContentEditingInputRequestOptions()
        options.isNetworkAccessAllowed = false
        options.canHandleAdjustmentData = { _ in true }
        requestID = asset.requestContentEditingInput(with: options) { [weak self] input, _ in
            DispatchQueue.main.async { self?.finish(input) }
        }
        timeout = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 1_000_000_000) }
            catch { return }
            self?.finish(nil)
        }
    }

    func cancel() {
        finished = true
        timeout?.cancel()
        timeout = nil
        if let requestID { asset.cancelContentEditingInputRequest(requestID) }
        requestID = nil
    }

    private func finish(_ input: PHContentEditingInput?) {
        guard !finished else { return }
        let url: URL?
        if asset.mediaType == .video { url = (input?.audiovisualAsset as? AVURLAsset)?.url }
        else { url = input?.fullSizeImageURL }
        var estimate = Self.fallback(for: asset)
        if let url, let values = try? url.resourceValues(forKeys: [.fileSizeKey]),
           let bytes = values.fileSize, bytes > 0 {
            let isLive = asset.mediaSubtypes.contains(.photoLive)
            let addition = Int64(bytes).addingReportingOverflow(isLive ? 3_000_000 : 0)
            estimate = MediaSizeEstimate(bytes: addition.overflow ? Int64.max : addition.partialValue,
                isEstimated: isLive || input?.adjustmentData != nil)
        }
        cancel()
        completion(estimate)
    }
}
