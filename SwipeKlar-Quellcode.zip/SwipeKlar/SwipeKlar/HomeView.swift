import SwiftUI
import UIKit

extension ReviewMode {
    var colors: [Color] {
        switch self {
        case .onThisDay: return [Color(red: 0.95, green: 0.71, blue: 0.40), Color(red: 0.63, green: 0.25, blue: 0.71)]
        case .recent: return [Color(red: 0.02, green: 0.81, blue: 0.58), Color(red: 0.13, green: 0.20, blue: 0.79)]
        case .random: return [Color(red: 0.62, green: 0.05, blue: 0.86), Color(red: 0.50, green: 0.73, blue: 0.99)]
        }
    }

    var detail: String {
        switch self {
        case .onThisDay: return "Erinnerungen aus allen Jahren"
        case .recent: return "Deine Fotos der letzten 30 Tage"
        case .random: return "Ein frischer Blick auf deine Mediathek"
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedMode: ReviewMode?
    private let peach = Color(red: 0.98, green: 0.80, blue: 0.68)

    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                VStack(spacing: 0) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(alignment: .firstTextBaseline) {
                            Text("swipeklar").font(.system(size: 49, weight: .black, design: .rounded)).italic()
                                .minimumScaleFactor(0.6).lineLimit(1)
                            Spacer(minLength: 16)
                            Image(systemName: "sparkle").font(.system(size: 25, weight: .bold))
                                .accessibilityHidden(true)
                        }
                        Text("Mehr Platz. Gute Erinnerungen.")
                            .font(.subheadline).foregroundStyle(.black.opacity(0.6))
                    }.padding(.horizontal, 24).padding(.vertical, 28)

                    ForEach(ReviewMode.allCases) { mode in
                        Button {
                            Task {
                                if !library.hasAccess { await library.requestAccess() }
                                if library.hasAccess { selectedMode = mode }
                            }
                        } label: {
                            HStack(spacing: 16) {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text(mode.title).font(.system(size: 43, weight: .bold))
                                        .minimumScaleFactor(0.5).lineLimit(1)
                                    Text(mode.detail).font(.subheadline).opacity(0.88)
                                        .multilineTextAlignment(.leading)
                                }
                                Spacer(minLength: 0)
                                Image(systemName: mode.symbol).font(.system(size: 34, weight: .bold))
                                    .frame(width: 46).accessibilityHidden(true)
                            }.foregroundStyle(.white).padding(.horizontal, 24)
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .background(LinearGradient(colors: mode.colors, startPoint: .leading, endPoint: .trailing))
                        }
                        .buttonStyle(.plain)
                        .disabled(library.isLoading)
                        .accessibilityLabel(mode.title + ". " + mode.detail)
                    }

                    footer.padding(.horizontal, 24).padding(.vertical, 18)
                }.frame(minHeight: geometry.size.height)
            }
            .background(peach.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(item: $selectedMode) { mode in
                ReviewView(mode: mode, ids: library.queue(for: mode))
            }
        }
        .task { await library.refreshAuthorization() }
        .onChange(of: scenePhase) { phase in
            if phase == .active { Task { await library.refreshAuthorization() } }
        }
    }

    @ViewBuilder private var footer: some View {
        if library.isLoading {
            HStack { ProgressView(); Text("Fotos werden geladen …").font(.footnote) }
        } else if library.authorization == .denied || library.authorization == .restricted {
            VStack(spacing: 8) {
                Text("Erlaube Fotozugriff in den iPhone-Einstellungen.").font(.footnote).multilineTextAlignment(.center)
                Button("Einstellungen öffnen") {
                    if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                }.font(.footnote.bold()).tint(.black)
            }
        } else if library.authorization == .limited {
            Button("Nur ausgewählte Fotos · Auswahl erweitern") { library.showLimitedPicker() }
                .font(.footnote).tint(.black)
        } else {
            Text(library.hasAccess ? "\(library.records.count) Fotos · nur auf deinem Gerät" : "Wähle einen Modus, um deine Fotos freizugeben.")
                .font(.footnote).foregroundStyle(.black.opacity(0.6)).multilineTextAlignment(.center)
        }
    }
}
