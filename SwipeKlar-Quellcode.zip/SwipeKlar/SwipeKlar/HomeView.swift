import SwiftUI
import UIKit

extension ReviewMode {
    var displayTitle: String {
        switch self {
        case .onThisDay: return "An diesem Tag"
        case .recent: return "Aktuelles"
        case .random: return "Zufällig"
        }
    }

    var detail: String {
        switch self {
        case .onThisDay: return "Erinnerungen aus früheren Jahren"
        case .recent: return "Die letzten 30 Tage"
        case .random: return "Deine Mediathek neu entdecken"
        }
    }

    var accent: Color {
        switch self {
        case .onThisDay: return .orange
        case .recent: return .blue
        case .random: return .indigo
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var library: PhotoLibrary
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedMode: ReviewMode?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    introduction
                    modeList
                    accessStatus
                }
                .padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 32)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("SwipeKlar")
            .navigationBarTitleDisplayMode(.large)
            .navigationDestination(item: $selectedMode) { mode in
                ReviewView(mode: mode, ids: library.queue(for: mode))
            }
        }
        .tint(.blue)
        .task { await library.refreshAuthorization() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { Task { await library.refreshAuthorization() } }
        }
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: "photo.on.rectangle.angled")
                .font(.system(size: 30, weight: .medium)).foregroundStyle(.blue)
                .frame(width: 64, height: 64)
                .background(Color.blue.opacity(0.10), in: RoundedRectangle(cornerRadius: 18))
                .accessibilityHidden(true)
            Text("Platz für das,\nwas bleibt.")
                .font(.system(.largeTitle, design: .rounded, weight: .bold))
                .fixedSize(horizontal: false, vertical: true)
            Text("Fotos und Videos in Ruhe durchsehen.\nDu entscheidest, was du behalten möchtest.")
                .font(.body).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var modeList: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Loslegen").font(.headline).padding(.horizontal, 4)
            VStack(spacing: 0) {
                ForEach(ReviewMode.allCases) { mode in
                    Button { open(mode) } label: { ModeRow(mode: mode) }
                        .buttonStyle(.plain).disabled(library.isLoading)
                    if mode != ReviewMode.allCases.last {
                        Divider().padding(.leading, 78)
                    }
                }
            }
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
        }
    }

    @ViewBuilder private var accessStatus: some View {
        if library.isLoading {
            HStack(spacing: 10) {
                ProgressView()
                Text("Mediathek wird geladen …").font(.footnote).foregroundStyle(.secondary)
            }.frame(maxWidth: .infinity)
        } else if library.authorization == .denied || library.authorization == .restricted {
            VStack(alignment: .leading, spacing: 10) {
                Label("Fotozugriff erforderlich", systemImage: "photo.badge.exclamationmark").font(.subheadline.weight(.semibold))
                Text("Erlaube SwipeKlar den Zugriff in den iPhone-Einstellungen.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button("Einstellungen öffnen") {
                    if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                }.font(.subheadline.weight(.semibold)).padding(.vertical, 8)
            }
        } else if library.authorization == .limited {
            VStack(alignment: .leading, spacing: 6) {
                Text("Du siehst nur deine freigegebenen Aufnahmen.").font(.footnote).foregroundStyle(.secondary)
                Button("Weitere Fotos auswählen") { library.showLimitedPicker() }
                    .font(.subheadline.weight(.semibold)).padding(.vertical, 8)
            }
        } else {
            VStack(spacing: 8) {
                if library.hasAccess {
                    Text("\(library.records.count.formatted()) Fotos & Videos").font(.footnote.weight(.medium))
                }
                Label("Privat auf deinem iPhone", systemImage: "lock.shield")
                    .font(.footnote).foregroundStyle(.secondary)
                if !library.hasAccess {
                    Text("Wähle einen Modus, um deine Mediathek freizugeben.")
                        .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }
            }.frame(maxWidth: .infinity)
        }
    }

    private func open(_ mode: ReviewMode) {
        Task {
            if !library.hasAccess { await library.requestAccess() }
            if library.hasAccess { selectedMode = mode }
        }
    }
}

private struct ModeRow: View {
    let mode: ReviewMode

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: mode.symbol)
                .font(.system(size: 21, weight: .semibold)).foregroundStyle(mode.accent)
                .frame(width: 46, height: 46)
                .background(mode.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 13))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                Text(mode.displayTitle).font(.headline).foregroundStyle(.primary)
                Text(mode.detail).font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right").font(.footnote.weight(.semibold))
                .foregroundStyle(.tertiary).accessibilityHidden(true)
        }
        .padding(16).frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
