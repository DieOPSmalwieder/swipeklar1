import AVFAudio
import AVFoundation
import Photos
import SwiftUI
import UIKit

enum MediaStyle {
    static let background = Color.black
    static let panel = Color.black
    static let secondary = Color(red: 0.82, green: 0.85, blue: 0.90)
}

struct MediaInformationBar: View {
    let asset: PHAsset
    let isZoomed: Bool
    let onReset: () -> Void
    let onShare: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            MediaMetadataView(asset: asset)
            if isZoomed {
                Button(action: onReset) {
                    Text("1×").font(.subheadline.weight(.semibold))
                        .frame(width: 44, height: 44)
                }
                .foregroundStyle(.white)
                .accessibilityLabel("Zoom auf Originalgröße zurücksetzen")
            } else {
                Image(systemName: "plus.magnifyingglass")
                    .font(.body).foregroundStyle(MediaStyle.secondary)
                    .frame(width: 44, height: 44).accessibilityHidden(true)
            }
            MediaShareButton(asset: asset, onPrepare: onShare)
        }
        .padding(.leading, 16).padding(.trailing, 4).padding(.vertical, 4)
        .background(Color.black)
    }
}

struct MediaMetadataView: View {
    let asset: PHAsset?

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                if let date = asset?.creationDate {
                    Text(date, format: .dateTime.day().month(.wide).year())
                        .font(.headline).foregroundStyle(.white)
                        .fixedSize(horizontal: false, vertical: true)
                } else {
                    Text("Aufnahmedatum unbekannt").font(.headline).foregroundStyle(.white)
                }
                Text(detailText).font(.caption).foregroundStyle(MediaStyle.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }.accessibilityElement(children: .combine)
    }

    private var detailText: String {
        var parts: [String] = []
        if let date = asset?.creationDate { parts.append(date.formatted(.dateTime.hour().minute())) }
        parts.append(asset?.mediaType == .video ? "Video" : "Foto")
        if let asset, asset.mediaType == .video { parts.append(PlaybackTime.label(asset.duration)) }
        return parts.joined(separator: " · ")
    }
}

struct MediaLoadStatus: View {
    @ObservedObject var model: MediaViewerModel
    let onRetry: () -> Void

    var body: some View {
        ZStack {
            if model.isLoading || model.isBuffering { loadingCard }
            if let message = model.errorMessage { errorCard(message) }
        }
        .allowsHitTesting(model.errorMessage != nil)
    }

    private var loadingCard: some View {
        VStack(spacing: 10) {
            ProgressView().tint(.white)
            Text(loadingMessage).font(.caption).foregroundStyle(.white)
        }
        .padding(16)
        .background(Color.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 16))
    }

    private var loadingMessage: String {
        if model.isLoading, model.downloadProgress > 0 {
            return "Aus iCloud laden: \(Int(model.downloadProgress * 100)) %"
        }
        return model.isVideo ? "Video wird geladen …" : "Foto wird geladen …"
    }

    private func errorCard(_ message: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: "icloud.slash").font(.title)
            Text(message).font(.caption).multilineTextAlignment(.center)
            Button("Erneut laden", action: onRetry)
                .buttonStyle(.borderedProminent).tint(.white).foregroundStyle(.black)
        }
        .foregroundStyle(.white).padding(16)
        .background(Color.black.opacity(0.95), in: RoundedRectangle(cornerRadius: 16))
        .padding(12)
    }
}

struct VideoPlaybackControls: View {
    @ObservedObject var model: MediaViewerModel

    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 6) {
                skipButton(seconds: -10, symbol: "gobackward.10", label: "Zehn Sekunden zurückspulen")
                playButton
                timeSlider
                skipButton(seconds: 10, symbol: "goforward.10", label: "Zehn Sekunden vorspulen")
            }
            positionLabels
        }.padding(.horizontal, 16).padding(.vertical, 6).background(MediaStyle.panel)
    }

    private var timeSlider: some View {
        Slider(value: Binding(get: { model.position }, set: { model.scrub(to: $0) }),
            in: 0...max(1, model.duration), onEditingChanged: { editing in
                if editing { model.beginScrubbing() } else { model.endScrubbing() }
            })
            .tint(.white).disabled(!model.isReady || model.duration <= 0)
            .accessibilityLabel("Wiedergabeposition")
            .accessibilityValue("\(PlaybackTime.label(model.position)) von \(PlaybackTime.label(model.duration))")
    }

    private var positionLabels: some View {
        HStack {
            Text(PlaybackTime.label(model.position))
            Spacer()
            Text(PlaybackTime.label(model.duration))
        }.font(.caption.monospacedDigit()).foregroundStyle(MediaStyle.secondary)
    }

    private var playButton: some View {
        Button { model.togglePlayback() } label: {
            Image(systemName: model.isPlaying ? "pause.fill" : "play.fill")
                .font(.title3).frame(width: 44, height: 44)
        }.foregroundStyle(.white).disabled(!model.isReady)
            .accessibilityLabel(model.isPlaying ? "Pause" : "Abspielen")
    }

    private func skipButton(seconds: Double, symbol: String, label: String) -> some View {
        Button { model.skip(by: seconds) } label: {
            Image(systemName: symbol).font(.title3).frame(width: 44, height: 44)
        }.foregroundStyle(.white).disabled(!model.isReady).accessibilityLabel(Text(label))
    }
}

@MainActor
final class MediaViewerModel: ObservableObject {
    let asset: PHAsset
    let player = AVPlayer()
    var isVideo: Bool { asset.mediaType == .video }
    @Published private(set) var image: UIImage?
    @Published private(set) var isLoading = true
    @Published private(set) var isBuffering = false
    @Published private(set) var isReady = false
    @Published private(set) var isPlaying = false
    @Published private(set) var duration: Double = 0
    @Published private(set) var position: Double = 0
    @Published private(set) var downloadProgress: Double = 0
    @Published private(set) var errorMessage: String?
    private let manager = PHImageManager.default()
    private var requestID: PHImageRequestID?
    private var loadID = UUID()
    private var timeObserver: Any?
    private var endObserver: NSObjectProtocol?
    private var failureObserver: NSObjectProtocol?
    private var observations: [NSKeyValueObservation] = []
    private var playback = VideoPlaybackState()

    init(asset: PHAsset) { self.asset = asset }

    deinit {
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        if let failureObserver { NotificationCenter.default.removeObserver(failureObserver) }
    }

    func load(autoplay: Bool = true) {
        stop()
        let token = loadID
        isLoading = true
        errorMessage = nil
        downloadProgress = 0
        if isVideo {
            duration = asset.duration.isFinite ? max(0, asset.duration) : 0
            if autoplay { playback.play() }
            let options = PHVideoRequestOptions()
            options.isNetworkAccessAllowed = true
            options.deliveryMode = .automatic
            options.progressHandler = { [weak self] progress, _, _, _ in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    self.downloadProgress = min(max(progress, 0), 1)
                }
            }
            requestID = manager.requestPlayerItem(forVideo: asset, options: options) { [weak self] item, info in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    guard let item else {
                        self.fail("Video nicht verfügbar. Prüfe deine Verbindung für iCloud-Videos.")
                        return
                    }
                    self.install(item, token: token)
                }
            }
        } else {
            let options = PHImageRequestOptions()
            options.isNetworkAccessAllowed = true
            options.deliveryMode = .opportunistic
            options.resizeMode = .exact
            options.progressHandler = { [weak self] progress, _, _, _ in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    self.downloadProgress = min(max(progress, 0), 1)
                }
            }
            // Bound memory while retaining substantially more detail than the swipe preview.
            let scale = min(1, 4096 / CGFloat(max(1, max(asset.pixelWidth, asset.pixelHeight))))
            let target = CGSize(width: CGFloat(asset.pixelWidth) * scale, height: CGFloat(asset.pixelHeight) * scale)
            requestID = manager.requestImage(for: asset, targetSize: target, contentMode: .aspectFit, options: options) { [weak self] image, info in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    if let image {
                        self.image = image
                        self.isLoading = false
                    } else if !(info?[PHImageResultIsDegradedKey] as? Bool ?? false), self.image == nil {
                        self.fail("Foto nicht verfügbar. Prüfe deine Verbindung für iCloud-Fotos.")
                    }
                }
            }
        }
    }

    func pause() {
        playback.pause()
        player.pause()
        isPlaying = false
    }

    func stop() {
        loadID = UUID()
        pause()
        playback.reset()
        if let requestID { manager.cancelImageRequest(requestID) }
        requestID = nil
        observations.removeAll()
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        if let failureObserver { NotificationCenter.default.removeObserver(failureObserver) }
        failureObserver = nil
        player.replaceCurrentItem(with: nil)
        isReady = false
        isBuffering = false
        position = 0
        image = nil
        if isVideo { try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation) }
    }

    func togglePlayback() {
        guard isReady else { return }
        if playback.wantsPlayback { pause() }
        else {
            playback.play()
            isPlaying = true
            if duration > 0, position >= duration - 0.1 { seek(to: 0) }
            else if playback.shouldPlay { play() }
        }
    }

    func beginScrubbing() {
        guard isReady else { return }
        playback.beginScrubbing()
        player.pause()
    }

    func scrub(to seconds: Double) {
        position = PlaybackTime.clamped(seconds, duration: duration)
        if !playback.isScrubbing { seek(to: position) }
    }

    func endScrubbing() {
        guard playback.isScrubbing else { return }
        playback.endScrubbing()
        seek(to: position)
    }

    func skip(by seconds: Double) { seek(to: position + seconds) }

    private func play() {
        guard playback.shouldPlay else { return }
        isPlaying = true
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
        try? AVAudioSession.sharedInstance().setActive(true)
        player.play()
    }

    private func seek(to seconds: Double) {
        guard isReady else { return }
        let target = PlaybackTime.clamped(seconds, duration: duration)
        let token = playback.beginSeek()
        position = target
        // Pause AVPlayer, retaining the user's playback intent across the seek.
        player.pause()
        player.currentItem?.cancelPendingSeeks()
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero,
            toleranceAfter: .zero) { [weak self] _ in
                DispatchQueue.main.async {
                    guard let self, self.playback.completeSeek(token) else { return }
                    if !self.playback.isScrubbing, self.duration > 0, target >= self.duration - 0.05 {
                        self.pause()
                    } else if self.playback.shouldPlay {
                        self.play()
                    }
                }
            }
    }

    private func install(_ item: AVPlayerItem, token: UUID) {
        observations.append(item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                guard let self, self.loadID == token else { return }
                switch item.status {
                case .readyToPlay:
                    self.isReady = true
                    self.isLoading = false
                    if self.playback.shouldPlay { self.play() }
                case .failed: self.fail(item.error?.localizedDescription ?? "Das Video konnte nicht geladen werden.")
                default: break
                }
            }
        })
        observations.append(item.observe(\.duration, options: [.initial, .new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                guard let self, self.loadID == token else { return }
                let seconds = item.duration.seconds
                if seconds.isFinite, seconds > 0 {
                    self.duration = seconds
                    self.position = PlaybackTime.clamped(self.position, duration: seconds)
                }
            }
        })
        observations.append(player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            DispatchQueue.main.async {
                guard let self, self.loadID == token else { return }
                // A seek can report .paused without the user having pressed Pause.
                self.isPlaying = self.playback.wantsPlayback
                self.isBuffering = player.timeControlStatus == .waitingToPlayAtSpecifiedRate
            }
        })
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.2, preferredTimescale: 600), queue: .main) { [weak self] time in
            Task { @MainActor [weak self] in
                guard let self, self.loadID == token, !self.playback.isScrubbing, !self.playback.isSeeking else { return }
                self.position = PlaybackTime.clamped(time.seconds, duration: self.duration)
            }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.loadID == token else { return }
                guard !self.playback.isSeeking, !self.playback.isScrubbing else { return }
                // Ignore a queued end notification from before a backward seek.
                let current = self.player.currentTime().seconds
                guard current.isFinite, self.duration > 0, current >= self.duration - 0.1 else { return }
                self.pause()
                self.position = self.duration
            }
        }
        failureObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.loadID == token else { return }
                self.fail("Die Wiedergabe wurde unterbrochen. Bitte lade das Video erneut.")
            }
        }
        player.replaceCurrentItem(with: item)
    }

    private func fail(_ message: String) {
        pause()
        isReady = false
        isLoading = false
        isBuffering = false
        errorMessage = message
    }
}
