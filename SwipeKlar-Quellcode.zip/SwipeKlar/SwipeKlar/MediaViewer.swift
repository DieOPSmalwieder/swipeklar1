import AVFAudio
import AVFoundation
import Photos
import SwiftUI
import UIKit

enum MediaStyle {
    static let background = Color(red: 0.055, green: 0.063, blue: 0.078)
    static let panel = Color(red: 0.10, green: 0.12, blue: 0.15)
    static let secondary = Color(red: 0.82, green: 0.85, blue: 0.90)
}

struct MediaPreviewItem: Identifiable {
    let asset: PHAsset
    var id: String { asset.localIdentifier }
}

struct MediaMetadataView: View {
    let asset: PHAsset?

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: asset?.mediaType == .video ? "video.fill" : "photo.fill")
                .font(.title3).foregroundStyle(.white).frame(width: 26).padding(.top, 2)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                if let date = asset?.creationDate {
                    Text(date, format: .dateTime.day().month(.wide).year())
                        .font(.headline).foregroundStyle(.white)
                        .fixedSize(horizontal: false, vertical: true)
                } else {
                    Text("Aufnahmedatum unbekannt").font(.headline).foregroundStyle(.white)
                }
                Text(detailText).font(.subheadline).foregroundStyle(MediaStyle.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }.accessibilityElement(children: .combine)
    }

    private var detailText: String {
        var parts: [String] = []
        if let date = asset?.creationDate { parts.append(date.formatted(.dateTime.hour().minute())) }
        parts.append(asset?.mediaType == .video ? "Video" : "Foto")
        if let asset, asset.mediaType == .video { parts.append(PlaybackTime.label(asset.duration)) }
        return parts.joined(separator: " · ")
    }
}

@MainActor
struct MediaViewer: View {
    let asset: PHAsset
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var model: MediaViewerModel
    @State private var resetID = UUID()

    init(asset: PHAsset) {
        self.asset = asset
        _model = StateObject(wrappedValue: MediaViewerModel(asset: asset))
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .top, spacing: 12) {
                MediaMetadataView(asset: asset)
                Button("Fertig") { dismiss() }
                    .font(.headline).foregroundStyle(.white)
                    .padding(.horizontal, 14).frame(minHeight: 44)
                    .background(Color.white.opacity(0.15), in: Capsule())
                    .accessibilityLabel("Detailansicht schließen")
            }.padding(16).background(MediaStyle.panel)

            ZoomableMedia(mediaID: asset.localIdentifier, image: model.image,
                player: model.isVideo ? model.player : nil,
                mediaSize: CGSize(width: CGFloat(asset.pixelWidth), height: CGFloat(asset.pixelHeight)), resetID: resetID)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .overlay {
                    if model.isLoading || model.isBuffering {
                        VStack(spacing: 12) {
                            ProgressView().tint(.white)
                            Text(model.isLoading && model.downloadProgress > 0
                                 ? "Aus iCloud laden: \(Int(model.downloadProgress * 100)) %"
                                 : "\(model.isVideo ? "Video" : "Foto") wird geladen …")
                                .font(.subheadline).foregroundStyle(.white)
                        }.padding(20).background(Color.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 16))
                            .allowsHitTesting(false)
                    }
                    if let error = model.errorMessage {
                        VStack(spacing: 16) {
                            Image(systemName: "icloud.slash").font(.largeTitle)
                            Text(error).font(.subheadline).multilineTextAlignment(.center)
                            Button("Erneut laden") { model.load() }
                                .buttonStyle(.borderedProminent).tint(.white).foregroundStyle(.black)
                        }.foregroundStyle(.white).padding(24)
                            .background(Color.black.opacity(0.95), in: RoundedRectangle(cornerRadius: 16))
                            .padding(16)
                    }
                }

            if model.isVideo { VideoPlaybackControls(model: model) }

            VStack(spacing: 6) {
                Button {
                    resetID = UUID()
                } label: {
                    Label("Zoom zurücksetzen", systemImage: "arrow.down.right.and.arrow.up.left")
                        .font(.subheadline.weight(.semibold)).frame(minHeight: 44)
                }.foregroundStyle(.white)
                Text("Mit zwei Fingern zoomen · Doppeltippen zum Vergrößern")
                    .font(.caption).foregroundStyle(MediaStyle.secondary).multilineTextAlignment(.center)
            }.frame(maxWidth: .infinity).padding(.horizontal, 16).padding(.bottom, 12)
                .background(MediaStyle.panel)
        }
        .background(Color.black.ignoresSafeArea()).foregroundStyle(.white)
        .environment(\.colorScheme, .dark).preferredColorScheme(.dark)
        .onAppear { model.load() }
        .onDisappear { model.stop() }
        .onChange(of: scenePhase) { _, phase in if phase != .active { model.pause() } }
        .onReceive(NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)) { _ in model.pause() }
    }
}

private struct VideoPlaybackControls: View {
    @ObservedObject var model: MediaViewerModel

    var body: some View {
        VStack(spacing: 4) {
            Slider(value: Binding(get: { model.position }, set: { model.scrub(to: $0) }),
                in: 0...max(1, model.duration), onEditingChanged: { editing in
                    if editing { model.beginScrubbing() } else { model.endScrubbing() }
                })
                .tint(.white).disabled(!model.isReady || model.duration <= 0)
                .accessibilityLabel("Wiedergabeposition")
                .accessibilityValue("\(PlaybackTime.label(model.position)) von \(PlaybackTime.label(model.duration))")
            HStack {
                Text(PlaybackTime.label(model.position))
                Spacer()
                Text(PlaybackTime.label(model.duration))
            }.font(.caption.monospacedDigit()).foregroundStyle(MediaStyle.secondary)
            HStack(spacing: 36) {
                Button { model.skip(by: -10) } label: {
                    Image(systemName: "gobackward.10").font(.title2).frame(width: 48, height: 48)
                }.accessibilityLabel("Zehn Sekunden zurückspulen")
                Button { model.togglePlayback() } label: {
                    Image(systemName: model.isPlaying ? "pause.fill" : "play.fill")
                        .font(.title).frame(width: 60, height: 52)
                }.accessibilityLabel(model.isPlaying ? "Pause" : "Abspielen")
                Button { model.skip(by: 10) } label: {
                    Image(systemName: "goforward.10").font(.title2).frame(width: 48, height: 48)
                }.accessibilityLabel("Zehn Sekunden vorspulen")
            }.foregroundStyle(.white).disabled(!model.isReady)
        }.padding(.horizontal, 20).padding(.top, 12).background(MediaStyle.panel)
    }
}

@MainActor
final class MediaViewerModel: ObservableObject {
    let asset: PHAsset
    let player = AVPlayer()
    var isVideo: Bool { asset.mediaType == .video }
    @Published private(set) var image: UIImage?
    @Published private(set) var isLoading = true
    @Published private(set) var isBuffering = false
    @Published private(set) var isReady = false
    @Published private(set) var isPlaying = false
    @Published private(set) var duration: Double = 0
    @Published private(set) var position: Double = 0
    @Published private(set) var downloadProgress: Double = 0
    @Published private(set) var errorMessage: String?
    private let manager = PHImageManager.default()
    private var requestID: PHImageRequestID?
    private var loadID = UUID()
    private var seekID = UUID()
    private var timeObserver: Any?
    private var endObserver: NSObjectProtocol?
    private var failureObserver: NSObjectProtocol?
    private var observations: [NSKeyValueObservation] = []
    private var isScrubbing = false
    private var isSeeking = false
    private var resumeAfterScrubbing = false
    private var wantsToPlay = false

    init(asset: PHAsset) { self.asset = asset }

    deinit {
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        if let failureObserver { NotificationCenter.default.removeObserver(failureObserver) }
    }

    func load() {
        stop()
        let token = loadID
        isLoading = true
        errorMessage = nil
        downloadProgress = 0
        if isVideo {
            duration = asset.duration.isFinite ? max(0, asset.duration) : 0
            wantsToPlay = true
            let options = PHVideoRequestOptions()
            options.isNetworkAccessAllowed = true
            options.deliveryMode = .automatic
            options.progressHandler = { [weak self] progress, _, _, _ in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    self.downloadProgress = min(max(progress, 0), 1)
                }
            }
            requestID = manager.requestPlayerItem(forVideo: asset, options: options) { [weak self] item, info in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    guard let item else {
                        self.fail("Video nicht verfügbar. Prüfe deine Verbindung für iCloud-Videos.")
                        return
                    }
                    self.install(item, token: token)
                }
            }
        } else {
            let options = PHImageRequestOptions()
            options.isNetworkAccessAllowed = true
            options.deliveryMode = .opportunistic
            options.resizeMode = .exact
            options.progressHandler = { [weak self] progress, _, _, _ in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    self.downloadProgress = min(max(progress, 0), 1)
                }
            }
            // Bound memory while retaining substantially more detail than the swipe preview.
            let scale = min(1, 4096 / CGFloat(max(1, max(asset.pixelWidth, asset.pixelHeight))))
            let target = CGSize(width: CGFloat(asset.pixelWidth) * scale, height: CGFloat(asset.pixelHeight) * scale)
            requestID = manager.requestImage(for: asset, targetSize: target, contentMode: .aspectFit, options: options) { [weak self] image, info in
                DispatchQueue.main.async {
                    guard let self, self.loadID == token else { return }
                    if let image {
                        self.image = image
                        self.isLoading = false
                    } else if !(info?[PHImageResultIsDegradedKey] as? Bool ?? false), self.image == nil {
                        self.fail("Foto nicht verfügbar. Prüfe deine Verbindung für iCloud-Fotos.")
                    }
                }
            }
        }
    }

    func pause() {
        wantsToPlay = false
        resumeAfterScrubbing = false
        player.pause()
        isPlaying = false
    }

    func stop() {
        loadID = UUID()
        seekID = UUID()
        pause()
        if let requestID { manager.cancelImageRequest(requestID) }
        requestID = nil
        observations.removeAll()
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        if let failureObserver { NotificationCenter.default.removeObserver(failureObserver) }
        failureObserver = nil
        player.replaceCurrentItem(with: nil)
        isReady = false
        isBuffering = false
        isScrubbing = false
        isSeeking = false
        position = 0
        image = nil
        if isVideo { try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation) }
    }

    func togglePlayback() {
        guard isReady else { return }
        if isPlaying { pause() }
        else if duration > 0, position >= duration - 0.1 { seek(to: 0, resume: true) }
        else { play() }
    }

    func beginScrubbing() {
        resumeAfterScrubbing = wantsToPlay
        isScrubbing = true
        wantsToPlay = false
        player.pause()
    }

    func scrub(to seconds: Double) {
        position = PlaybackTime.clamped(seconds, duration: duration)
        if !isScrubbing { seek(to: position, resume: wantsToPlay) }
    }

    func endScrubbing() {
        guard isScrubbing else { return }
        isScrubbing = false
        seek(to: position, resume: resumeAfterScrubbing)
        resumeAfterScrubbing = false
    }

    func skip(by seconds: Double) { seek(to: position + seconds, resume: wantsToPlay) }

    private func play() {
        wantsToPlay = true
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
        try? AVAudioSession.sharedInstance().setActive(true)
        player.play()
    }

    private func seek(to seconds: Double, resume: Bool) {
        guard isReady else { return }
        let target = PlaybackTime.clamped(seconds, duration: duration)
        let token = UUID()
        seekID = token
        isSeeking = true
        wantsToPlay = resume
        position = target
        player.currentItem?.cancelPendingSeeks()
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600), toleranceBefore: .zero,
            toleranceAfter: .zero) { [weak self] finished in
                DispatchQueue.main.async {
                    guard let self, self.seekID == token else { return }
                    self.isSeeking = false
                    if finished, self.wantsToPlay { self.play() }
                }
            }
    }

    private func install(_ item: AVPlayerItem, token: UUID) {
        observations.append(item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                guard let self, self.loadID == token else { return }
                switch item.status {
                case .readyToPlay:
                    self.isReady = true
                    self.isLoading = false
                    if self.wantsToPlay { self.play() }
                case .failed: self.fail(item.error?.localizedDescription ?? "Das Video konnte nicht geladen werden.")
                default: break
                }
            }
        })
        observations.append(item.observe(\.duration, options: [.initial, .new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                guard let self, self.loadID == token else { return }
                let seconds = item.duration.seconds
                if seconds.isFinite, seconds > 0 {
                    self.duration = seconds
                    self.position = PlaybackTime.clamped(self.position, duration: seconds)
                }
            }
        })
        observations.append(player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            DispatchQueue.main.async {
                guard let self, self.loadID == token else { return }
                self.isPlaying = player.timeControlStatus != .paused
                self.isBuffering = player.timeControlStatus == .waitingToPlayAtSpecifiedRate
            }
        })
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.2, preferredTimescale: 600), queue: .main) { [weak self] time in
            Task { @MainActor [weak self] in
                guard let self, self.loadID == token, !self.isScrubbing, !self.isSeeking else { return }
                self.position = PlaybackTime.clamped(time.seconds, duration: self.duration)
            }
        }
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.loadID == token else { return }
                self.pause()
                self.position = self.duration
            }
        }
        failureObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.loadID == token else { return }
                self.fail("Die Wiedergabe wurde unterbrochen. Bitte lade das Video erneut.")
            }
        }
        player.replaceCurrentItem(with: item)
    }

    private func fail(_ message: String) {
        pause()
        isReady = false
        isLoading = false
        isBuffering = false
        errorMessage = message
    }
}
