import AVFoundation
import ImageIO
import Photos
import SwiftUI
import UniformTypeIdentifiers
import UIKit

@MainActor
struct MediaShareButton: View {
    let asset: PHAsset
    let onPrepare: () -> Void
    @StateObject private var sharing = MediaShareModel()

    var body: some View {
        Button {
            if sharing.isPreparing { sharing.cancelPreparation() }
            else { onPrepare(); sharing.prepare(asset) }
        } label: {
            buttonLabel.frame(minWidth: 44, minHeight: 44)
        }
        .foregroundStyle(.white)
        .accessibilityLabel(sharing.isPreparing ? "Vorbereitung zum Teilen abbrechen" : "Aufnahme teilen")
        .accessibilityHint("Öffnet die iOS-Teilenansicht, zum Beispiel für WhatsApp.")
        .sheet(item: $sharing.item, onDismiss: sharing.finish) { item in
            MediaActivitySheet(url: item.url) { error in
                sharing.activityFinished(error, for: item.id)
            }
        }
        .alert("Teilen nicht möglich", isPresented: errorPresented) {
            Button("OK", role: .cancel) { sharing.errorMessage = nil }
        } message: { Text(sharing.errorMessage ?? "Bitte versuche es erneut.") }
        .onDisappear { sharing.cancelPreparation() }
    }

    @ViewBuilder private var buttonLabel: some View {
        if sharing.isPreparing {
            HStack(spacing: 6) {
                ProgressView().tint(.white)
                Image(systemName: "xmark").font(.caption.weight(.semibold))
            }
        } else {
            Image(systemName: "square.and.arrow.up").font(.body.weight(.medium))
        }
    }

    private var errorPresented: Binding<Bool> {
        Binding(get: { sharing.errorMessage != nil }, set: { if !$0 { sharing.errorMessage = nil } })
    }
}

private struct ShareMediaItem: Identifiable {
    let id = UUID()
    let url: URL
}

private struct MediaActivitySheet: UIViewControllerRepresentable {
    let url: URL
    let onFinished: (Error?) -> Void

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        controller.completionWithItemsHandler = { _, _, _, error in
            DispatchQueue.main.async { onFinished(error) }
        }
        return controller
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

@MainActor
private final class MediaShareModel: ObservableObject {
    @Published private(set) var isPreparing = false
    @Published var item: ShareMediaItem?
    @Published var errorMessage: String?
    private let manager = PHImageManager.default()
    private var requestID: PHImageRequestID?
    private var exportSession: AVAssetExportSession?
    private var generation = UUID()
    private var directory: URL?
    private var activityError: String?

    func prepare(_ asset: PHAsset) {
        guard !isPreparing, item == nil else { return }
        errorMessage = nil
        activityError = nil
        generation = UUID()
        let token = generation
        let folder = FileManager.default.temporaryDirectory
            .appendingPathComponent("SwipeKlar-Share-" + UUID().uuidString, isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        } catch {
            errorMessage = "Die Datei zum Teilen konnte nicht vorbereitet werden. " + error.localizedDescription
            return
        }
        directory = folder
        isPreparing = true
        if asset.mediaType == .video { prepareVideo(asset, folder: folder, token: token) }
        else { preparePhoto(asset, folder: folder, token: token) }
    }

    func cancelPreparation() {
        guard isPreparing else { return }
        generation = UUID()
        if let requestID { manager.cancelImageRequest(requestID) }
        requestID = nil
        exportSession?.cancelExport()
        exportSession = nil
        isPreparing = false
        removeTemporaryFiles()
    }

    func activityFinished(_ error: Error?, for id: UUID) {
        guard item?.id == id else { return }
        activityError = error?.localizedDescription
        item = nil
    }

    func finish() {
        // Keep the file until the receiving share extension has finished using it.
        item = nil
        removeTemporaryFiles()
        if let activityError { errorMessage = activityError }
        activityError = nil
    }

    private func preparePhoto(_ asset: PHAsset, folder: URL, token: UUID) {
        let options = PHImageRequestOptions()
        options.version = .current
        options.deliveryMode = .highQualityFormat
        options.isNetworkAccessAllowed = true
        requestID = manager.requestImageDataAndOrientation(for: asset, options: options) { [weak self] data, type, _, _ in
            Task { @MainActor [weak self] in
                guard let self, self.generation == token else { return }
                self.requestID = nil
                guard let data else {
                    self.fail("Das Foto konnte nicht geladen werden. Für iCloud-Fotos ist eine Internetverbindung nötig.", token: token)
                    return
                }
                do {
                    // Encoding and disk writes must not block the zoom/player UI.
                    let url = try await Task.detached(priority: .userInitiated) {
                        try Self.writePhoto(data, type: type, folder: folder)
                    }.value
                    guard self.generation == token else {
                        try? FileManager.default.removeItem(at: folder)
                        return
                    }
                    self.present(url, token: token)
                } catch {
                    self.fail("Das Foto konnte nicht zum Teilen vorbereitet werden. " + error.localizedDescription, token: token)
                }
            }
        }
    }

    private nonisolated static func writePhoto(_ data: Data, type: String?, folder: URL) throws -> URL {
        let contentType = type.flatMap { UTType($0) }
        if contentType?.conforms(to: .jpeg) == true || contentType?.conforms(to: .png) == true {
            let name = contentType?.conforms(to: .png) == true ? "Foto.png" : "Foto.jpg"
            let url = folder.appendingPathComponent(name)
            try data.write(to: url, options: .atomic)
            return url
        }
        // HEIC/RAW become full-resolution JPEGs for broad share-extension compatibility.
        // ImageIO copies image properties, including the source orientation.
        let url = folder.appendingPathComponent("Foto.jpg")
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil) else {
            throw SharePreparationError.photoEncoding
        }
        let properties = [kCGImageDestinationLossyCompressionQuality: 0.95] as CFDictionary
        CGImageDestinationAddImageFromSource(destination, source, 0, properties)
        guard CGImageDestinationFinalize(destination) else { throw SharePreparationError.photoEncoding }
        return url
    }

    private func prepareVideo(_ asset: PHAsset, folder: URL, token: UUID) {
        let options = PHVideoRequestOptions()
        options.version = .current
        options.deliveryMode = .highQualityFormat
        options.isNetworkAccessAllowed = true
        requestID = manager.requestExportSession(forVideo: asset, options: options,
            exportPreset: AVAssetExportPresetHighestQuality) { [weak self] session, _ in
                Task { @MainActor [weak self] in
                    guard let self, self.generation == token else { return }
                    self.requestID = nil
                    guard let session else {
                        self.fail("Das Video konnte nicht geladen werden. Für iCloud-Videos ist eine Internetverbindung nötig.", token: token)
                        return
                    }
                    self.exportVideo(session, folder: folder, token: token)
                }
            }
    }

    private func exportVideo(_ session: AVAssetExportSession, folder: URL, token: UUID) {
        let fileType: AVFileType
        if session.supportedFileTypes.contains(.mp4) { fileType = .mp4 }
        else if session.supportedFileTypes.contains(.mov) { fileType = .mov }
        else { fail("Dieses Video lässt sich nicht zum Teilen exportieren.", token: token); return }
        let url = folder.appendingPathComponent(fileType == .mp4 ? "Video.mp4" : "Video.mov")
        exportSession = session
        session.outputURL = url
        session.outputFileType = fileType
        session.shouldOptimizeForNetworkUse = true
        session.exportAsynchronously { [weak self] in
            Task { @MainActor [weak self] in
                guard let self, self.generation == token else {
                    try? FileManager.default.removeItem(at: folder)
                    return
                }
                self.exportSession = nil
                if session.status == .completed { self.present(url, token: token) }
                else {
                    self.fail(session.error?.localizedDescription ?? "Das Video konnte nicht zum Teilen vorbereitet werden.", token: token)
                }
            }
        }
    }

    private func present(_ url: URL, token: UUID) {
        guard generation == token else { return }
        isPreparing = false
        item = ShareMediaItem(url: url)
    }

    private func fail(_ message: String, token: UUID) {
        guard generation == token else { return }
        isPreparing = false
        errorMessage = message
        removeTemporaryFiles()
    }

    private func removeTemporaryFiles() {
        if let directory { try? FileManager.default.removeItem(at: directory) }
        directory = nil
    }
}

private enum SharePreparationError: LocalizedError {
    case photoEncoding
    var errorDescription: String? { "Das Bildformat konnte nicht für die Teilenansicht umgewandelt werden." }
}
