import Photos
import PhotosUI
import SwiftUI
import UIKit

@MainActor
final class PhotoLibrary: NSObject, ObservableObject, PHPhotoLibraryChangeObserver {
    @Published private(set) var authorization = PHPhotoLibrary.authorizationStatus(for: .readWrite)
    @Published private(set) var records: [PhotoRecord] = []
    @Published private(set) var isLoading = false
    @Published private(set) var reviewed: Set<String>
    private var assets: [String: PHAsset] = [:]
    private var refreshGeneration = 0
    private let progressKey = "SwipeKlar.reviewed.v1"

    var hasAccess: Bool { authorization == .authorized || authorization == .limited }

    override init() {
        reviewed = Set(UserDefaults.standard.stringArray(forKey: "SwipeKlar.reviewed.v1") ?? [])
        super.init()
        PHPhotoLibrary.shared().register(self)
    }

    deinit { PHPhotoLibrary.shared().unregisterChangeObserver(self) }

    func refreshAuthorization() async {
        authorization = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        await refresh()
    }

    func requestAccess() async {
        authorization = await PHPhotoLibrary.requestAuthorization(for: .readWrite)
        await refresh()
    }

    func refresh() async {
        refreshGeneration += 1
        let generation = refreshGeneration
        guard hasAccess else {
            assets = [:]
            records = []
            isLoading = false
            return
        }
        isLoading = true
        let fetched = await Task.detached(priority: .userInitiated) { () -> [PHAsset] in
            let options = PHFetchOptions()
            options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
            let result = PHAsset.fetchAssets(with: .image, options: options)
            var items: [PHAsset] = []
            items.reserveCapacity(result.count)
            result.enumerateObjects { asset, _, _ in items.append(asset) }
            return items
        }.value
        guard generation == refreshGeneration else { return }
        assets = Dictionary(uniqueKeysWithValues: fetched.map { ($0.localIdentifier, $0) })
        records = fetched.map { PhotoRecord(id: $0.localIdentifier, date: $0.creationDate) }
        isLoading = false
    }

    nonisolated func photoLibraryDidChange(_ changeInstance: PHChange) {
        Task { @MainActor [weak self] in await self?.refreshAuthorization() }
    }

    func asset(for id: String) -> PHAsset? { assets[id] }

    func queue(for mode: ReviewMode) -> [String] {
        PhotoSelection.queue(records, mode: mode, reviewed: reviewed)
    }

    func restart(_ mode: ReviewMode) {
        let ids = Set(PhotoSelection.matching(records, mode: mode).map(\.id))
        reviewed.subtract(ids)
        persistProgress()
    }

    func finish(_ decisions: [PhotoDecision], deleting selectedIDs: Set<String>) async throws {
        // Only IDs actually marked in this review may be passed to PhotoKit.
        let requested = Set(decisions.filter { $0.choice == .delete }.map(\.id))
            .intersection(selectedIDs)
        let targets = requested.compactMap { assets[$0] }
        if !targets.isEmpty {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.deleteAssets(targets as NSArray)
            }
        }
        // Save progress only after PhotoKit succeeds. Cancelled deletion is retryable.
        reviewed.formUnion(decisions.map(\.id))
        persistProgress()
        await refreshAuthorization()
    }

    private func persistProgress() {
        UserDefaults.standard.set(Array(reviewed), forKey: progressKey)
    }

    func showLimitedPicker() {
        guard let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene }).first(where: { $0.activationState == .foregroundActive }),
              var controller = scene.windows.first(where: \.isKeyWindow)?.rootViewController else { return }
        while let presented = controller.presentedViewController { controller = presented }
        PHPhotoLibrary.shared().presentLimitedLibraryPicker(from: controller)
    }
}

struct AssetPhoto: View {
    let asset: PHAsset?
    var thumbnail = false
    @State private var image: UIImage?
    @State private var requestID: PHImageRequestID?
    @State private var failed = false
    @State private var generation = UUID()
    private let manager = PHImageManager.default()

    var body: some View {
        ZStack {
            Color.white.opacity(0.07)
            if let image {
                if thumbnail {
                    Image(uiImage: image).resizable().scaledToFill()
                } else {
                    Image(uiImage: image).resizable().scaledToFit()
                }
            } else if failed {
                VStack(spacing: 12) {
                    Image(systemName: "icloud.slash").font(.largeTitle)
                    if !thumbnail {
                        Text("Foto nicht verfügbar").font(.headline)
                        Text("Prüfe deine Internetverbindung für iCloud-Fotos.")
                            .font(.caption).multilineTextAlignment(.center)
                        Button("Erneut laden", action: load)
                    }
                }.foregroundStyle(.white.opacity(0.85)).padding()
            } else {
                ProgressView().tint(.white)
            }
        }
        .clipped()
        .onAppear(perform: load)
        .onChange(of: asset?.localIdentifier) { _ in load() }
        .onDisappear {
            generation = UUID()
            if let requestID { manager.cancelImageRequest(requestID) }
        }
    }

    private func load() {
        generation = UUID()
        let token = generation
        if let requestID { manager.cancelImageRequest(requestID) }
        image = nil
        failed = false
        guard let asset else { failed = true; return }
        let options = PHImageRequestOptions()
        options.isNetworkAccessAllowed = true
        options.deliveryMode = .opportunistic
        options.resizeMode = .fast
        let size = thumbnail ? CGSize(width: 320, height: 320) : CGSize(width: 1600, height: 2200)
        requestID = manager.requestImage(for: asset, targetSize: size,
            contentMode: thumbnail ? .aspectFill : .aspectFit, options: options) { result, info in
            DispatchQueue.main.async {
                guard generation == token else { return }
                if let result { image = result }
                if info?[PHImageErrorKey] != nil || (result == nil && !(info?[PHImageResultIsDegradedKey] as? Bool ?? false)) {
                    failed = image == nil
                }
            }
        }
    }
}
