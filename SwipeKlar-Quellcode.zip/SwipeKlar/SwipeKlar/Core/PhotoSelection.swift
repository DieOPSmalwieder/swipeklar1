import Foundation

enum ReviewMode: String, CaseIterable, Identifiable, Hashable {
    case onThisDay, recent, random
    var id: String { rawValue }

    var title: String {
        switch self {
        case .onThisDay: return "an diesem tag"
        case .recent: return "aktuelles"
        case .random: return "zufällig"
        }
    }

    var symbol: String {
        switch self {
        case .onThisDay: return "calendar"
        case .recent: return "clock.fill"
        case .random: return "shuffle"
        }
    }
}

struct PhotoRecord: Equatable {
    let id: String
    let date: Date?
}

enum PhotoSelection {
    static func matching(_ records: [PhotoRecord], mode: ReviewMode,
                         now: Date = Date(), calendar: Calendar = .current) -> [PhotoRecord] {
        let today = calendar.dateComponents([.month, .day], from: now)
        let cutoff = calendar.date(byAdding: .day, value: -30, to: calendar.startOfDay(for: now))!
        return records.filter { record in
            switch mode {
            case .random: return true
            case .recent:
                guard let date = record.date else { return false }
                return date >= cutoff && date <= now
            case .onThisDay:
                guard let date = record.date, date <= now else { return false }
                let parts = calendar.dateComponents([.month, .day], from: date)
                return parts.month == today.month && parts.day == today.day
            }
        }
    }

    static func queue(_ records: [PhotoRecord], mode: ReviewMode, reviewed: Set<String>,
                      now: Date = Date(), calendar: Calendar = .current) -> [String] {
        let eligible = matching(records, mode: mode, now: now, calendar: calendar)
            .filter { !reviewed.contains($0.id) }
        if mode == .random { return eligible.map(\.id).shuffled() }
        return eligible.sorted {
            let lhs = $0.date ?? .distantPast
            let rhs = $1.date ?? .distantPast
            return lhs == rhs ? $0.id < $1.id : lhs > rhs
        }.map(\.id)
    }
}

enum PhotoChoice: Equatable { case keep, delete }

struct PhotoDecision {
    let id: String
    let choice: PhotoChoice
}

struct ReviewProgress {
    let ids: [String]
    private(set) var decisions: [PhotoDecision] = []
    var currentID: String? { decisions.count < ids.count ? ids[decisions.count] : nil }
    var isComplete: Bool { currentID == nil }
    var deleteIDs: [String] { decisions.filter { $0.choice == .delete }.map(\.id) }
    var keptCount: Int { decisions.count - deleteIDs.count }

    mutating func choose(_ choice: PhotoChoice) {
        guard let id = currentID else { return }
        decisions.append(PhotoDecision(id: id, choice: choice))
    }

    mutating func undo() {
        if !decisions.isEmpty { decisions.removeLast() }
    }
}
