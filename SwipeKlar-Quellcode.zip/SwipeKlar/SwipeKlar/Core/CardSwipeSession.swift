import Foundation

/// A gesture that has touched zoom or a second finger stays ineligible until it ends.
struct CardSwipeSession {
    private(set) var isEligible = false

    mutating func begin(zoomScale: Double, touchCount: Int, isPinching: Bool) {
        isEligible = canSort(zoomScale: zoomScale, touchCount: touchCount, isPinching: isPinching)
    }

    mutating func update(zoomScale: Double, touchCount: Int, isPinching: Bool) {
        if !canSort(zoomScale: zoomScale, touchCount: touchCount, isPinching: isPinching) {
            isEligible = false
        }
    }

    mutating func finish(horizontal: Double, vertical: Double, zoomScale: Double) -> PhotoChoice? {
        defer { isEligible = false }
        guard isEligible, zoomScale.isFinite, zoomScale > 0, zoomScale <= 1.01,
              horizontal.isFinite, vertical.isFinite,
              abs(horizontal) > 90, abs(horizontal) > abs(vertical) else { return nil }
        return horizontal > 0 ? .keep : .delete
    }

    mutating func cancel() { isEligible = false }

    private func canSort(zoomScale: Double, touchCount: Int, isPinching: Bool) -> Bool {
        zoomScale.isFinite && zoomScale > 0 && zoomScale <= 1.01 && touchCount == 1 && !isPinching
    }
}
