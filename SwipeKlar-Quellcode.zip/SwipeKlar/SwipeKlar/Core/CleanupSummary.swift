import Foundation

struct MediaSizeEstimate: Equatable {
    let bytes: Int64
    let isEstimated: Bool
}

struct CleanupSummary {
    let reviewedCount: Int
    let deletedCount: Int
    let bytes: Int64
    let isEstimated: Bool

    static func confirmed(reviewedIDs: Set<String>, deletedIDs: Set<String>,
                          sizes: [String: MediaSizeEstimate]) -> CleanupSummary {
        let deleted = deletedIDs.intersection(reviewedIDs)
        var total: Int64 = 0
        var estimated = false
        for id in deleted {
            guard let size = sizes[id] else { estimated = true; continue }
            let addition = total.addingReportingOverflow(max(0, size.bytes))
            total = addition.overflow ? Int64.max : addition.partialValue
            estimated = estimated || size.isEstimated
        }
        return CleanupSummary(reviewedCount: reviewedIDs.count, deletedCount: deleted.count,
            bytes: total, isEstimated: estimated)
    }
}

enum MediaSizeHeuristic {
    static func bytes(width: Int, height: Int, duration: Double, isVideo: Bool, isLivePhoto: Bool) -> Int64 {
        let pixels = Double(max(1, width)) * Double(max(1, height))
        let photoBytes = max(200_000, pixels * 0.32)
        // Only a fallback: actual compression, frame rate and edits vary by recording.
        let videoBitsPerSecond = min(100_000_000, max(500_000, pixels / 2_073_600 * 8_000_000))
        let value: Double
        if isVideo {
            let seconds = duration.isFinite ? max(0, duration) : 0
            value = seconds * videoBitsPerSecond / 8
        } else {
            value = photoBytes + (isLivePhoto ? 3_000_000 : 0)
        }
        guard value.isFinite, value < Double(Int64.max) else { return Int64.max }
        return Int64(max(0, value))
    }
}
