import Foundation

enum MediaTouchPolicy {
    static func canUseSingleTouch(zoomScale: Double, hadMultipleTouches: Bool, wasHeld: Bool) -> Bool {
        zoomScale.isFinite && zoomScale > 0 && zoomScale <= 1.01 && !hadMultipleTouches && !wasHeld
    }

    static func edgeChoice(x: Double, width: Double, zoomScale: Double,
                           hadMultipleTouches: Bool, wasHeld: Bool) -> PhotoChoice? {
        guard canUseSingleTouch(zoomScale: zoomScale, hadMultipleTouches: hadMultipleTouches, wasHeld: wasHeld),
              x.isFinite, width.isFinite, width >= 176, x >= 0, x <= width else { return nil }
        let edgeWidth = min(88, max(44, width * 0.20))
        if x <= edgeWidth { return .delete }
        if x >= width - edgeWidth { return .keep }
        return nil
    }
}
