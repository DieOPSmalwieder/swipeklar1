import Foundation

enum PlaybackTime {
    static func clamped(_ seconds: Double, duration: Double) -> Double {
        guard duration.isFinite, duration > 0 else { return 0 }
        if seconds == .infinity { return duration }
        guard seconds.isFinite else { return 0 }
        return min(max(0, seconds), duration)
    }

    static func label(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0, seconds < Double(Int.max) else { return "0:00" }
        let total = Int(seconds.rounded(.down))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let remainder = total % 60
        if hours > 0 { return "\(hours):" + String(format: "%02d:%02d", minutes, remainder) }
        return "\(minutes):" + String(format: "%02d", remainder)
    }
}
