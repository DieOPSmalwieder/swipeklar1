import Foundation

/// Playback intent survives the player's temporary pause while seeking or scrubbing.
struct VideoPlaybackState {
    private(set) var wantsPlayback = false
    private(set) var isScrubbing = false
    private(set) var pendingSeek: UUID?
    private(set) var isFastPlayback = false
    private var wasPlayingBeforeHold = false
    var rate: Double { isFastPlayback ? 2 : 1 }
    var isSeeking: Bool { pendingSeek != nil }
    var shouldPlay: Bool { wantsPlayback && !isScrubbing && !isSeeking }

    mutating func play() { wantsPlayback = true }
    mutating func pause() {
        wantsPlayback = false
        isFastPlayback = false
        wasPlayingBeforeHold = false
    }

    mutating func beginFastPlayback() {
        guard !isFastPlayback, !isScrubbing, !isSeeking else { return }
        wasPlayingBeforeHold = wantsPlayback
        isFastPlayback = true
        wantsPlayback = true
    }

    mutating func endFastPlayback() {
        guard isFastPlayback else { return }
        isFastPlayback = false
        wantsPlayback = wasPlayingBeforeHold
        wasPlayingBeforeHold = false
    }

    mutating func beginScrubbing() { endFastPlayback(); isScrubbing = true }
    mutating func endScrubbing() { isScrubbing = false }

    mutating func beginSeek() -> UUID {
        endFastPlayback()
        let token = UUID()
        pendingSeek = token
        return token
    }

    /// Only the most recent seek may resume playback.
    mutating func completeSeek(_ token: UUID) -> Bool {
        guard pendingSeek == token else { return false }
        pendingSeek = nil
        return true
    }

    mutating func reset() { self = VideoPlaybackState() }
}
